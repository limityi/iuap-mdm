 
/*
	取得角色对应的人员。
	与sp_getRole2Man不同，sp_getRole2Man仅于与数据权限有关的
*/
create proc [sp_getRole2Man_NotDataPower]
@roleName varchar(3000)
as
 select Sys_UserRole.EmpID,e.EmplName,CompID  from 
(select * from Sys_Role where RoleName in (select SingleString from dbo.Func_GetSplitStringTable2(@roleName)) and Sys_Role.Status='1100102') rolex
  join Sys_UserRole on Sys_UserRole.ROleID=rolex.ID
  join Org_Employee e on Sys_UserRole.EmpID=e.ID

GO
