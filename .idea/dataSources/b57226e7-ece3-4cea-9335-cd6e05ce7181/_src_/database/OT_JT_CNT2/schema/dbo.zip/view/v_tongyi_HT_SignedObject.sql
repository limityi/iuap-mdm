create view [dbo].[v_tongyi_HT_SignedObject] as 
select * from HT_SignedObject
GO
