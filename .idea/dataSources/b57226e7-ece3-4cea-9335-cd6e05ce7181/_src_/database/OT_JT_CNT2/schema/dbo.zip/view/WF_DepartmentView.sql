CREATE VIEW [dbo].[WF_DepartmentView]
AS
SELECT     ID, 
PID AS ParentID, 
Company_ID as CompanyID,
 Depa_Code AS DepartmentCode, 
 Depa_Name AS DepartmentName, 
 Depa_Desc AS Remark, 
 Depa_Serial AS Serial, 
 Manager as Depamanager,
  case when Status=1 then '1100102' else '1100101' end as Status
FROM         dbo.OPF_Org_Department
GO
