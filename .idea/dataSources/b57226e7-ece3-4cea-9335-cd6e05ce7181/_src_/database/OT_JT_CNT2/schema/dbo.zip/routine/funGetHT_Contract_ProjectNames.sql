/*取得指定合同的项目名称字串*/
create FUNCTION funGetHT_Contract_ProjectNames(@id varchar(36))
 RETURNS varchar(3000) 
AS 
begin
	declare @ret varchar(8000);
	set @ret = '';
	select  @ret = @ret+'，'+rtrim(Name) 
	  from HT_Project where ID in (select Project_Id from HT_Contract_Project  where Contract_Id=''+@id+''); 
	set @ret = case when len(@ret)>0 then stuff(@ret,1,1,'') else @ret end
	return @ret
end
GO
