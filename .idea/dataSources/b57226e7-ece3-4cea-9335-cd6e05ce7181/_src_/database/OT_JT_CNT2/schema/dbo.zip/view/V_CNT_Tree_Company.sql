
---公司查看权限
CREATE view [dbo].[V_CNT_Tree_Company]
AS
SELECT ID, Comp_Code AS OrgCode, Comp_Name AS OrgName, [Status], 1 AS OrgType, pid AS ParentID, Comp_Serial AS Serial, Tree_Code AS TreeCode, 
                      CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1)  THEN 1 ELSE 0 END AS HasChild
FROM         OPF_Org_Company c
WHERE     Status = 1


GO
