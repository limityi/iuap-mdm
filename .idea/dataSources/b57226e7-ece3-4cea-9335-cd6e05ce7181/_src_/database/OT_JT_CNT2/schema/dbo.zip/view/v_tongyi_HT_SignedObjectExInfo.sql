CREATE view v_tongyi_HT_SignedObjectExInfo as 
select * from HT_SignedObjectExInfo where orgid='N000128'
GO
