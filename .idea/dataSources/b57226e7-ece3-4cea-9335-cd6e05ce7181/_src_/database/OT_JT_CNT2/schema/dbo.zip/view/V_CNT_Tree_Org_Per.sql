--组织机构数据权限树
create view V_CNT_Tree_Org_Per AS
SELECT c.Comp_Code ID, c.Comp_Code AS OrgCode, c.Comp_Short_Name AS OrgName, c.[Status], 1 AS OrgType, cc.Comp_Code AS ParentID, c.Comp_Serial AS Serial, 
                      c.Tree_Code AS TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id AND Status = 1) THEN 1 ELSE 0 END AS HasChild
                            ,c.Comp_Code as CompId
FROM         OPF_Org_Company c left join OPF_Org_Company cc on c.pid=cc.id
WHERE     c.Status = 1
UNION ALL
/*部门*/ SELECT d.Depa_Code ID, d.Depa_Code, d.Depa_Name, d.[Status], 2, ISNULL(dd.Depa_Code, c.Comp_Code), d.Depa_Serial, d.Tree_Code, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      PID = d .id AND Status = 1) THEN 1 ELSE 0 END
                             ,c.Comp_Code as CompId
FROM         OPF_Org_Department d inner join OPF_Org_Company c on d.company_ID=c.id
left join OPF_Org_Department dd on d.PID=dd.id 
WHERE     d.Status = 1

GO
