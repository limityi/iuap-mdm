/*
	取得合同台账数据内容
*/
CREATE proc sp_getHT_ContractAccountData
  @EmplyeeCode varchar(100) --员工编号
  ,@roleid int ---1：普通员工，2：部门领导，3：公司领导 4：合同审计员
  ,@OrgCodes varchar(1000)--过滤公司
  ,@SubCompanyType int--0本部,1包括直接下级单位,2包括所有下级单位
  ,@advanceSearch  varchar(max)  --高级搜索
  
as 
declare @advanceSearch_AndOR  varchar(30)--高级搜索关系and or 
set @advanceSearch_AndOR='and' 

--1取得我可以查看的合同ID（包括自己经办、有权限的）
declare @ICanViewHT table(id varchar(36))
insert @ICanViewHT exec dbo.sp_get_HT_IDsOfUserCanViewIDs_Role @EmplyeeCode,@roleid,@OrgCodes,@SubCompanyType 

--2取得符合筛选过滤条件的合同ID
declare @AdvanceIDs table(id varchar(300)) --符件高级搜索条件的合同ID
declare @PageCanShowHTIDs table(id varchar(36))--@ICanViewHT 和@ICanViewHT 交集结果
if(@advanceSearch is not null and @advanceSearch<>'')
begin
	insert @AdvanceIDs
		exec sp_getHT_ContractIds_advanceSearchfilter @advanceSearch,@advanceSearch_AndOR	 
    insert @PageCanShowHTIDs
		select canviewHTIDs.id from @ICanViewHT canviewHTIDs join @AdvanceIDs whereHTIDs on canviewHTIDs.id=whereHTIDs.id
end 
else
	insert @PageCanShowHTIDs
		select id from @ICanViewHT
		


--3取得要显示的数据,按@PageCanShowHTIDs中合同ID过滤 
-- 注意: 如果更改了下面输出结果时，请同步更改中间缓存表([HT_ContractAccountQueryResultCache])结构
--insert [HT_ContractAccountQueryResultCache]
select @EmplyeeCode, ht.id,ht.name,ht.code,ht.Signed_Code,dbo.funGetHT_Contract_ProjectNames(ht.id) ProjectName
	,ht.Subordinate_Company_Name
	,dbo.funGetHT_Contract_SignatorieNames(ht.id) SignatoriesName
	,(select Name from HT_ContractType where ht.Contract_Type=id) ContractTypeName
	,(select Name from HT_ContractBussinessType where ht.Bussiness_Type=id) BussinessTypeName
	,(select Name from OPF_Sys_Dict_Item where ht.Registration_Currency=id) CurrencyName,ht.Registration_Exchange_rate
	,(select Name from OPF_Sys_Dict_Item where ht.Receive_Or_Payment=id) ReceiveOrPaymentName 
	,(select Name from OPF_Sys_Dict_Item where ht.Bidding_Type=id) BiddingTypeName 
	,ht.Signing_Time,ht.Effective_Time,ht.Contract_Period,ht.Contract_Period_Remark
	,ht.Contract_Amount,ht.Contract_Amount_Remark,ht.Change_Amount,ht.Settlement_Amount
	,ht.Complete_Amount,dbo.fun_getHT_ContractAmountOK(ht.id) ContractAmountOK
	,(select sum(CWFactPaymentAmount) from HT_Payment_Apply where Contract_Id= ht.Id and Is_Confirmed=1) CWFactPaymentAmount
	,ht.Describe,ht.Is_Affiliate_Transaction,ht.Is_Framework_Agreements
	,ht.Responsible_Department_Name,ht.Responsible_Person_Name
	,ht.Board
	,ht.[Status] HtStatus
	,(case ht.[Status] when '1056301' then '拟定中' when '1056302' then '审批中' when '1056303' then '履约中' when '1056304' then '履约完成' when '1056305' then '已终止' when '1056399' then '已作废' end) HtStatusName
	,ht.OrgID,(select BUDataName from Org_CompanyDeptSimpleView where ht.OrgID=BUDataCode) OrgName  
from ht_contract ht where ht.id in (select id from @PageCanShowHTIDs)


GO
