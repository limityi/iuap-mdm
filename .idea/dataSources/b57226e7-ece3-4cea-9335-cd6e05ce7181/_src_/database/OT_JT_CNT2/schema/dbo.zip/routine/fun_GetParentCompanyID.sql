 
/*
	取得公司的父公司ID 
	2010-9
*/
CREATE function [dbo].[fun_GetParentCompanyID]( @companyid varchar(300))
returns    varchar(300)
as
begin   
    declare @Parentcompanyid varchar(300)
	 select @Parentcompanyid=PID from  Org_CompanyDeptSimpleView where ID=@companyid
	if((select  BUDataName from  Org_CompanyDeptSimpleView where ID=@Parentcompanyid)='直属公司') 
	begin
		 select @Parentcompanyid=PID from  Org_CompanyDeptSimpleView where ID=@Parentcompanyid 		
	end
	 
	  
	--  select @Parentcompanyid=ID from  Org_CompanyDeptSimpleView where PID=@Parentcompanyid and BUDataName='本部'
	 return @Parentcompanyid
end


GO
