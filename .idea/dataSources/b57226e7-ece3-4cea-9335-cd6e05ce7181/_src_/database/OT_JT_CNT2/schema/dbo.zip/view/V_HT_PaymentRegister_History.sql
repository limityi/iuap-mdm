
CREATE view [dbo].[V_HT_PaymentRegister_History]
as 
select * from HT_PaymentRegister where Is_Active=0


GO
