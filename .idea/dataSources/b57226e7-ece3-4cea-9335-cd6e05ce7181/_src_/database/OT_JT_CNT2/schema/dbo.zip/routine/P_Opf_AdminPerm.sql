---2013-9-3

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_Opf_AdminPerm](@parentId Varchar(36),@currUserId Varchar(36),@permUserId varchar(36),@RigType varchar(5))
AS
BEGIN
	if @RigType = 'role'
		begin
			if @parentId = 'all' 
			begin
				SELECT ID,PID,Func_Name,nodeType,HasChild,isChecked,'' as [status]
				FROM(
					SELECT p.ID, NULL AS PID
						, p.Name Func_Name
						,1 as nodeType
						,CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID) THEN 1 ELSE 0 END AS HasChild
						,CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=P.ID And  c.Owner_Id = @permUserId ) THEN 1 ELSE 0 END AS isChecked
						,p.Serial
					 FROM OPF_SYS_PlatForm p WHERE p.Status = 1 				
					 UNION ALL
					 SELECT ID,ISNULL(PID,System_ID) AS PID
						,Func_Name
						,2
						, CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.PID = f.ID) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where  C.Module_Id=f.ID And  c.Owner_Id = @permUserId) THEN 1 ELSE 0 END AS isChecked
						,Func_Serial
					 FROM OPF_SYS_Functions f WHERE f.Status = 1 ) D
				 ORDER BY nodeType,Serial				
			end
			else if @parentId = '' 
			begin
				SELECT p.ID, NULL AS PID
					, p.Name Func_Name
					,1 as nodeType,
						CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=P.ID And  c.Owner_Id = @permUserId ) THEN 1 ELSE 0 END AS isChecked
					 ,'' as [status]
				 FROM OPF_SYS_PlatForm p 
				 WHERE p.Status = 1 
				 order by p.Serial
			end
		else
			begin
				SELECT ID
					,ISNULL(PID,System_ID) AS PID
					,Func_Name
					,2 as nodeType
					, CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.PID = f.ID) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where  C.Module_Id=f.ID And  c.Owner_Id = @permUserId) THEN 1 ELSE 0 END AS isChecked
					,'' as status
				FROM OPF_SYS_Functions f 
				WHERE Status = 1 and ISNULL(PID,System_ID)= @parentId order by Func_Serial
			end 
		end
	else if @RigType = 'user'
		begin
			if @parentId = 'all' 
			begin
				SELECT ID,PID,Func_Name,nodeType,HasChild,isChecked,'' as [status],[disabled]
				FROM(
				    SELECT p.ID, NULL as PID
						, p.Name as Func_Name
						,1 As nodeType	
						,CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID) THEN 1 ELSE 0 END AS HasChild
						,CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId) B Where A.ID = B.Module_Id) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS isChecked						
						,CASE WHEN EXISTS (Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId)	and o.Module_Id=p.ID ) THEN 1 ELSE 0 END  as [disabled]
						,Serial
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1 
					UNION ALL
					SELECT ID
						,ISNULL(PID,System_ID) AS PID
						, Func_Name
						,2 as nodeType
						,CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.PID = f.ID) THEN 1 ELSE 0 END AS HasChild
						,CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId) B Where A.ID = B.Module_Id) C where  C.ID=f.ID ) THEN 1 ELSE 0 END AS isChecked						
						,CASE WHEN EXISTS (Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) and o.Module_Id=f.ID ) THEN 1 ELSE 0 END  as [disabled]
						,Func_Serial
					FROM OPF_SYS_Functions f WHERE Status = 1  
				) D
				ORDER BY nodeType,Serial				
			end
			else if @parentId = '' 
			begin					
					SELECT p.ID
						, NULL as PID
						, p.Name as Func_Name
						,1 As nodeType,	
						CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId) B Where A.ID = B.Module_Id) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS isChecked
						,'' Status
						,CASE WHEN EXISTS (Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId)	and o.Module_Id=p.ID ) THEN 1 ELSE 0 END  as [disabled]
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1  order by p.Serial
			end
			else
			begin
					SELECT ID
						,ISNULL(PID,System_ID) AS PID
						, Func_Name
						,2 as nodeType
						, CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.PID = f.ID) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId) B Where A.ID = B.Module_Id) C where  C.ID=f.ID ) THEN 1 ELSE 0 END AS isChecked
						,'' as status
						,CASE WHEN EXISTS (Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) and o.Module_Id=f.ID ) THEN 1 ELSE 0 END  as [disabled]
					FROM OPF_SYS_Functions f WHERE Status = 1 and ISNULL(PID,System_ID)= @parentId order by Func_Serial
				end 
			end
END
GO
