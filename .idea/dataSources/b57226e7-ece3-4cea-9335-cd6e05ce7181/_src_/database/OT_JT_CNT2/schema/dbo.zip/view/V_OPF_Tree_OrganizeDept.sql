/*==============================================================*/
/* View: V_OPF_Organize                                         */
/*==============================================================*/
--create view V_OPF_Organize as
--/*公司*/ SELECT ID, Comp_Code AS OrgCode, Comp_Name AS OrgName, [Status], 1 AS OrgType, pid AS ParentID, Comp_Serial AS Serial, 
--                      Tree_Code AS TreeCode, CASE WHEN HasChildComp = 1 OR
--                      HasDepartment = 1 THEN 1 ELSE 0 END AS HasEnabled, CASE WHEN HasChildComp = 1 OR
--                      HasDepartment = 1 OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Company
--                            WHERE      PID = c.id) OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Department
--                            WHERE      Company_ID = c.id) THEN 1 ELSE 0 END AS HasAll
--FROM         OPF_Org_Company c
--UNION ALL
--/*部门*/ SELECT ID, Depa_Code, Depa_Name, [Status], 2, ISNULL(pid, Company_ID), Depa_Serial, Tree_Code, CASE WHEN HasChildDept = 1 OR
--                      HasPosition = 1 OR
--                      HasEmployee = 1 THEN 1 ELSE 0 END, CASE WHEN HasChildDept = 1 OR
--                      HasPosition = 1 OR
--                      HasEmployee = 1 OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Department
--                            WHERE      PID = d .id) OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Dep_Position
--                            WHERE      Department_ID = d .id) OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Employee
--                            WHERE      Department_ID = d .id) OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Employee e INNER JOIN
--                                                   OPF_Org_Dep_Posi_Empl r ON e.ID = r.Employee_ID
--                            WHERE      r.Dep_ID = d .id) THEN 1 ELSE 0 END
--FROM         OPF_Org_Department d
--UNION ALL
--/*岗位*/ SELECT ID, Posi_Code, Posi_Name, [Status], 3, Department_ID, Posi_Serial, '', CASE WHEN HasEmployee = 1 THEN 1 ELSE 0 END, 
--                      CASE WHEN HasEmployee = 1 OR
--                      EXISTS
--                          (SELECT     *
--                            FROM          OPF_Org_Employee e INNER JOIN
--                                                   OPF_Org_Dep_Posi_Empl r ON e.ID = r.Employee_ID
--                            WHERE      r.Dep_Position_ID = p.id) THEN 1 ELSE 0 END
--FROM         OPF_Org_Dep_Position p
--UNION ALL
--/*主要部门人员*/ SELECT ID, Empl_Code, Empl_Name, [Status], 4, Department_ID, Empl_Serial, '', 0, 0
--FROM         OPF_Org_Employee
--UNION ALL
--/*-岗位人员,6主要岗位，7兼任岗位*/ SELECT r.ID, e.Empl_Code, e.Empl_Name, r.[Status], CASE WHEN Is_Primary = 1 THEN 431 ELSE 432 END, p.ID, r.Serial, 
--                      '', 0, 0
--FROM         OPF_Org_Employee e INNER JOIN
--                      OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.ID INNER JOIN
--                      OPF_Org_Dep_Position p ON r.Dep_Position_ID = p.ID
--UNION ALL
--/*-兼任部门人员,22兼任部门*/ SELECT r.ID, e.Empl_Code, e.Empl_Name, r.[Status], 42, d .ID, r.Serial, '', 0, 0
--FROM         OPF_Org_Employee e INNER JOIN
--                      OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.ID INNER JOIN
--                      OPF_Org_Department d ON r.Dep_ID = d .ID
--go

/*==============================================================*/
/* View: V_OPF_Tree_OrganizeDept                                */
/*==============================================================*/
CREATE view [dbo].[V_OPF_Tree_OrganizeDept] as
/*公司*/ SELECT ID, Comp_Code AS OrgCode, Comp_Short_Name AS OrgName, [Status], 1 AS OrgType, pid AS ParentID, Comp_Serial AS Serial, 
                      Tree_Code AS TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id AND Status = 1) THEN 1 ELSE 0 END AS HasChild
FROM         OPF_Org_Company c
WHERE     Status = 1
UNION ALL
/*部门*/ SELECT ID, Depa_Code, Depa_Name, [Status], 2, ISNULL(pid, Company_ID), Depa_Serial, Tree_Code, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      PID = d .id AND Status = 1) THEN 1 ELSE 0 END
FROM         OPF_Org_Department d
WHERE     Status = 1
GO
