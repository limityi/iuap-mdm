-- =============================================
-- Author:lvyanghui		
-- Create date:2014-12-18 
-- Description:	插入下载队列表
-- =============================================
create trigger tgr_HT_SignedObject
on HT_SignedObject
after insert, update, delete
as
    if ((exists (select 1 from inserted)) and (exists (select 1 from deleted)))--修改
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			inserted.SignObjectID,'HT_SignedObject',1,getdate(),0,0
		  FROM
			inserted;
    end
    else if (exists (select 1 from inserted) and not exists (select 1 from deleted))--插入
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			inserted.SignObjectID,'HT_SignedObject',0,getdate(),0,0
		  FROM
			inserted;
    end
    else if (not exists (select 1 from inserted) and exists (select 1 from deleted))--删除
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			deleted.SignObjectID,'HT_SignedObject',-1,getdate(),0,0
		  FROM
			deleted;
    end
GO
