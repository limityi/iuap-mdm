create view V_HT_Payment_Plan_Active
as 
select * from HT_Payment_Plan where Is_Active=1

GO
