

CREATE view [dbo].[V_CNT_Tree_ContractAllTypebz] as

select cast(ID as nvarchar(36)) ID,isnull(cast(PID as nvarchar(36)),'z') PID,Name,Code,Serial,
1 as HasChild,case when orgid='' then 3 else  1 end AS nodeType ,OrgID
FROM HT_ContractType a
union all
select cast(ID as nvarchar(36)) ID,isnull(cast(PID as nvarchar(36)),'y')  PID,Name,Code,Serial,
1 as HasChild,case when orgid='' then 4 else  2 end AS nodeType ,OrgID
FROM HT_ContractBussinessType a


GO
