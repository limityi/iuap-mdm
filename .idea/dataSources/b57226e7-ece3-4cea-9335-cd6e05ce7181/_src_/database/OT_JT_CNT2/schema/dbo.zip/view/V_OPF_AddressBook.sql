



CREATE VIEW [dbo].[V_OPF_AddressBook]
AS
SELECT     cast(Id AS varchar(36)) AS Id, Comp_Code AS OrgCode, Comp_Name AS OrgName, 
	Comp_Short_Name AS ShortName,
	1 AS OrgType,
     cast(pid AS varchar(36)) AS ParentId, 
                          (SELECT     COUNT(*)
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id) +
                          (SELECT     COUNT(*)
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id) AS Childs, 
                          (SELECT COUNT(*) 
							FROM V_OPF_Employee e JOIN OPF_Org_Department p ON e.DepartmentId = p.ID
							WHERE p.Company_ID = c.ID) as EmpCount, c.Comp_Serial Serial
FROM         OPF_Org_Company c
WHERE     c.Status = 1
UNION ALL
SELECT     cast(ID AS varchar(36)), Depa_Code, Depa_Name, Depa_Name, 2, cast(ISNULL(pid, Company_ID) AS varchar(36)), 
                          (SELECT    COUNT(*)
                            FROM          OPF_Org_Department
                            WHERE      PID = d .id) AS Childs, 
                            (SELECT    COUNT(*)
                            FROM          V_OPF_Employee
                            WHERE     DepartmentId = d .id) AS EmpCount , d .Depa_Serial
FROM         OPF_Org_Department d
WHERE     d .Status = 1


GO
