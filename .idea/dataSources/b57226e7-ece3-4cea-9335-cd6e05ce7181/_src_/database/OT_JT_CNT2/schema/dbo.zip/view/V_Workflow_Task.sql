CREATE VIEW dbo.V_Workflow_Task
AS
SELECT  w.Id, w.TaskType, p.Title, p.DataIdArr AS BuDataId, a.ActTemplateId, a.Name AS ActivityName, 
                   a.CreatedTime AS ActivityCreatedTime, CAST(CASE w.IsPress WHEN '101301' THEN 1 ELSE 0 END AS bit) AS IsPress, 
                   w.UrgentLevel, w.SenderId, w.SenderName, w.ReceiverId, w.ReceiverName, w.AlarmTime, w.OverTime, w.ReceiverDeptId, 
                   w.ReceiverDeptName, b.ID AS BillCode, b.Name AS BillName, b.IsMobile, w.Status, w.SendTime, w.CompletedTime, 
                   p.Status AS ProcessInstanceStatus, a.Id AS ActivityId, w. LEVEL AS TaskLevel, w.ParentId, j.CompanyId, p.RawBudataId, 
                   p.CreatorId, p.CreateName, p.CreatedTime, p.DeptName
/*, j.Url                */ FROM WF_ProcessInstance p INNER JOIN
                   WF_ActivityInstance a ON p.Id = a.ProcessInstanceId INNER JOIN
                   WF_WorkItems w ON a.Id = w.ActId INNER JOIN
                   WF_BuInterface i ON p.BuInterfaceId = i.ID INNER JOIN
                   WF_Bill b ON b.ID = i.BillID INNER JOIN
                   WF_JobTemplate j ON p.JobTemplateID = j.ID
WHERE   (p.Status = '100901' AND a.Status = '101101' AND w.Status = '0') /*待办*/ OR
                   (p.Status = '100901' AND w.Status = '0' AND w.TaskType = '3') /*抄送 */ OR
                   w.Status IN ('1', '4', '5', '7', '9', '10') /*已办、等待、人工挂起、子流程审批中、已批复*/ OR
                   (p.Status = '100904' AND w.Status IN ('6', '8'))
GO
