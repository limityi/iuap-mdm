
create view V_HT_Changes_Item_History
as 
select * from HT_Changes_Item where Is_Active=0

GO
