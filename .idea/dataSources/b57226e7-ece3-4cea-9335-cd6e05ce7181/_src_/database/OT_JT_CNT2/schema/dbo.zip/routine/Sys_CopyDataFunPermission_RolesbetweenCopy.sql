 
/*
	根据提供源、目标角色，进行交叉权限COPY，方式将已经COPY好的源角色的权限COPY目标角色上
	黙认不删除原来的目标角色的权限
	要求源、目标角色均不可以为空,且不能相同
*/
create proc [dbo].[Sys_CopyDataFunPermission_RolesbetweenCopy] 
	@soruceRoleID varchar(300) --源角色ID
	,@airmRoleID varchar(300)  --目标角色ID
    ,@isDelAirmRoleDataFunPermission bit=0 --是否删原来的目标角色的权限,黙认删除
as
if(@soruceRoleID<>'' and @airmRoleID<>'' and @soruceRoleID<>@airmRoleID)
begin
	if(@isDelAirmRoleDataFunPermission=1)	 
		delete [Sys_DataFunPermission]	where  [RoleID]=@airmRoleID  
	 
	declare @DataFunID varchar(300)		
	declare myx cursor for select [DataFunID] from [Sys_DataFunPermission] where [RoleID]=@soruceRoleID
	set @DataFunID=''		 
	open myx 
	fetch next from myx into @DataFunID
	while @@fetch_status=0
	begin
		if(not exists(select * from Sys_DataFunPermission where RoleID=@airmRoleID and DataFunID=@DataFunID))
			INSERT INTO [Sys_DataFunPermission] ([ID], [DataFunID], [EmployeeID], [RoleID], [PermMode], [PermType])	
		 select   newid(),[DataFunID],NULL,@airmRoleID,[PermMode], [PermType] from [Sys_DataFunPermission] where  [RoleID]=@soruceRoleID  and DataFunID=@DataFunID
		fetch next from myx into @DataFunID
	end
	close myx
	deallocate myx 
end


GO
