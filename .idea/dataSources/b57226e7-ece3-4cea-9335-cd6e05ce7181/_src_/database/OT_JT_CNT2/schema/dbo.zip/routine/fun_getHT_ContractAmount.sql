
/*取得合同总金额函数
  原则：如有变更金额，则取变更金额，否则直接取签约金额
*/
CREATE function [dbo].[fun_getHT_ContractAmount](@CntId varchar(36),@IsActive int =1)
  returns decimal
as 
begin 
   declare @Contract_Amount decimal,@Change_Amount decimal,@Settlement_Amount decimal
   select @Contract_Amount=Contract_Amount, @Change_Amount=Change_Amount,@Settlement_Amount=Settlement_Amount from HT_Contract where id=@CntId and Is_Active=@IsActive
   --if(@Settlement_Amount is not null) return @Settlement_Amount 
   if(@Change_Amount is not null) return @Change_Amount 
   return isnull(@Contract_Amount,0)
end
GO
