

CREATE proc [dbo].[sp_Tree_ContractTypeSelect]  
    @parentId nvarchar(50),
    @OrgID nvarchar(36)

as 
--Id、ParentId、NodeName、NodeType、HasChild、IsChecked、Status、Disabled
select ID, PID, Name, NodeType, isnull((select top 1 1 from V_CNT_Tree_ContractTypeSelect  b  where a.id=b.pid and  (OrgID=@OrgID or OrgID='')),0) as HasChild ,
'' IsChecked,'' Status,'' Disabled, RID , board, Code, Serial,  nodeType, OrgID from dbo.V_CNT_Tree_ContractTypeSelect a
where (OrgID=@OrgID or OrgID='') and PID=@parentId  and Status=1 order by Serial asc
GO
