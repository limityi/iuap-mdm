CREATE VIEW [V_CNT_Tree_ContractItemSelect]
AS
SELECT     ID, Contract_ID, Item_Code, Item_Name, PID, CASE WHEN Is_Child = 1 THEN 0 ELSE 1 END AS Is_Child, Item_Type_ID, Level_Code, Sort_Number
FROM         dbo.HT_Contract_Item
GO
