 create proc [dbo].[Common_WarningLogInsert]
 @LogID uniqueidentifier,
 @IsError bit,
 @Content text, 
 @CreateDate datetime 
as
insert Common_WarningLog(LogID,
IsError,Content,CreateDate) values(@LogID,
@IsError,@Content,@CreateDate)

 GO
