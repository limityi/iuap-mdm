CREATE VIEW [dbo].[V_Workflow_Tree_BillUrl]
AS
	--子系统
	Select CAST(ID AS VARCHAR(36)) AS Id,Name,NULL AS ParentId,0 AS nodeType, CASE WHEN EXISTS (SELECT * FROM WF_Bill WHERE SYSTEMID = p.id ) THEN 1 ELSE 0 END AS HasChild ,Serial,'' AS [STATUS]
	FROM OPF_Sys_PlatForm p
	WHERE Status=1 and IsBusiness=1
	--业务单据
	UNION ALL
	SELECT ID,NAME+'('+Id+')',SYSTEMID,1,CASE WHEN EXISTS (SELECT * FROM WF_BillUrl WHERE BillID=b.ID ) THEN 1 ELSE 0 END ,sortserial,'' 
	FROM WF_Bill b
	--业务驱动页面
	UNION ALL
	SELECT ID,NAME,BillID,2,0,0,''
	FROM WF_BillUrl
GO
