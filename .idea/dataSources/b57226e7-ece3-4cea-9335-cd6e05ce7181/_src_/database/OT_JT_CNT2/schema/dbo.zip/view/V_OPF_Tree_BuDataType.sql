---
CREATE view [dbo].[V_OPF_Tree_BuDataType] as
--系统
Select p.ID,NULL as parentId,p.Name
,'' as nodeType,
1 as hasChild,Serial
from dbo.OPF_Sys_PlatForm p
inner join OPF_Rig_BuData_Type t on t.System_Id=p.id
where p.Status=1 and t.Status=1
UNION
---模板
Select ID,ISNULL(PBuId,System_Id),Bu_Name
,case when Self_Link_Filed IS NULL then 'list' else 'tree' end,
case when exists(Select * from OPF_Rig_BuData_Type where PBuId=id and Status=1)
then 1 else 0 end,-1
from dbo.OPF_Rig_BuData_Type
where Status=1
GO
