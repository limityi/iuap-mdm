-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
--@currUserId 当前用户Id
--@PermUserId 要授权的用户Id
--@RigType 权限类型是角色还是用户
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_Opf_RigPerm](@parentId Varchar(36),@currUserId Varchar(36),@permUserId varchar(36),@RigType varchar(5))
AS
BEGIN
	begin	
		if @RigType = 'user'
		begin
			if @parentId = 'all' 
			begin
			Select ID
				,PID
				,Func_Name
				,nodeType
				,HasChild,
				CASE WHEN EXISTS (
				SELECT * FROM 
					(
					Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 
					union all 
					Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId
					) B 
					where  B.Module_Id=D.ID ) THEN 1 ELSE 0 END AS isChecked
				,'' as [status] 
				,CASE WHEN EXISTS (
					Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 						
					and o.Module_Id=D.ID ) THEN 1 ELSE 0 END  as [disabled]
				FROM (
					SELECT p.ID, NULL PID, p.Name Func_Name,1 AS nodeType,p.Serial,	
					CASE WHEN EXISTS (
						SELECT * FROM (
							Select distinct A.* 
							from OPF_SYS_Functions A ,
								(Select * from OPF_Rig_OPPermission O 
									where o.Owner_Id in (
										select Role_ID from  OPF_Rig_User_Role 
										where Emp_ID = @currUserId) 
								union all 
								Select * from OPF_Rig_OPPermission O 
									where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id
								) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (
						SELECT * FROM 
						(Select * from OPF_Rig_OPPermission O 
						where o.Owner_Id in 
							(select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) 
						union all 
						Select * from OPF_Rig_OPPermission O where o.Owner_Id =@currUserId
						) B where  B.Module_Id=P.ID ) THEN 1 ELSE 0 END AS HasPermission
					
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1 
					UNION ALL
					SELECT ID,ISNULL(PID,System_ID) AS PID, Func_Name,2,Func_Serial,
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.PID=f.ID ) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B where  B.Module_Id=f.ID ) THEN 1 ELSE 0 END AS HasPermission
					FROM OPF_SYS_Functions f WHERE Status = 1 ) D 
					Where HasPermission =1 order by  nodeType,Serial
			end 
			else if @parentId = '' 
			begin
				Select d.ID
				,D.PID
				,D.Func_Name
				,1 as nodeType
				,D.HasChild,
				CASE WHEN EXISTS (
				SELECT * FROM 
					(
					Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 
					union all 
					Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId
					) B 
					where  B.Module_Id=D.ID ) THEN 1 ELSE 0 END AS isChecked
				,'' as [status] 
				,CASE WHEN EXISTS (
					Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 						
					and o.Module_Id=D.ID ) THEN 1 ELSE 0 END  as [disabled]
				FROM (
					SELECT p.ID, NULL PID, p.Name Func_Name,	
					CASE WHEN EXISTS (
						SELECT * FROM (
							Select distinct A.* 
							from OPF_SYS_Functions A ,
								(Select * from OPF_Rig_OPPermission O 
									where o.Owner_Id in (
										select Role_ID from  OPF_Rig_User_Role 
										where Emp_ID = @currUserId) 
								union all 
								Select * from OPF_Rig_OPPermission O 
									where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id
								) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (
						SELECT * FROM 
						(Select * from OPF_Rig_OPPermission O 
						where o.Owner_Id in 
							(select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) 
						union all 
						Select * from OPF_Rig_OPPermission O where o.Owner_Id =@currUserId
						) B where  B.Module_Id=P.ID ) THEN 1 ELSE 0 END AS HasPermission
					,p.Serial
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1 ) D Where D.HasPermission=1 order by D.Serial
			end
			else 			
			begin
				Select A.ID
				,A.PID
				,A.Func_Name
				,2 as nodeType
				,A.HasChild
				,CASE WHEN EXISTS (
					SELECT * FROM 
					(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 
					union all 
					Select * from OPF_Rig_OPPermission O where o.Owner_Id = @permUserId
					) B where  B.Module_Id=A.ID ) THEN 1 ELSE 0 END AS isChecked
				,'' as [status] 
				,CASE WHEN EXISTS (
					Select * from OPF_Rig_OPPermission o where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @permUserId) 						
					and o.Module_Id=A.ID ) THEN 1 ELSE 0 END  as [disabled]
				FROM 
					(SELECT ID
					,ISNULL(PID,System_ID) AS PID, Func_Name,Func_Serial,
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.PID=f.ID ) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B where  B.Module_Id=f.ID ) THEN 1 ELSE 0 END AS HasPermission
					FROM OPF_SYS_Functions f WHERE Status = 1 ) A 
					Where A.HasPermission =1 and A.PID= @parentId order by A.Func_Serial
			end 
		end
		else if @RigType = 'role'
		begin
			if @parentId = 'all' 
			begin
				Select ID,PID,Func_Name,nodeType,HasChild,
				CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=D.ID And  c.Owner_Id = @permUserId ) THEN 1 ELSE 0 END AS isChecked
				,'' as [status] 
				from (SELECT p.ID, NULL PID, p.Name Func_Name,1 AS nodeType,p.Serial,	
					CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id =@currUserId) B where  B.Module_Id=P.ID ) THEN 1 ELSE 0 END AS HasPermission
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1 
					UNION ALL
					SELECT ID,ISNULL(PID,System_ID) AS PID, Func_Name,2,Func_Serial,
					CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.PID=f.ID ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B where  B.Module_Id=f.ID ) THEN 1 ELSE 0 END AS HasPermission
					FROM OPF_SYS_Functions f WHERE Status = 1 ) D 
				Where HasPermission =1 
				order by nodeType,Serial
			end
			else if @parentId = '' 
			begin
				Select d.ID,D.PID,D.Func_Name,1 as nodeType,D.HasChild,
				CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=D.ID And  c.Owner_Id = @permUserId ) THEN 1 ELSE 0 END AS isChecked
				,'' as [status] 
				from (SELECT p.ID, NULL PID, p.Name Func_Name,'' As Func_Serial,	
					CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id =@currUserId) B where  B.Module_Id=P.ID ) THEN 1 ELSE 0 END AS HasPermission,p.Serial,'' Status
					FROM OPF_SYS_PlatForm p WHERE p.Status = 1 ) D Where D.HasPermission=1 order by D.Serial
			end
			else
			begin
				Select A.ID,A.PID,A.Func_Name,2 as nodeType,A.HasChild,
					CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=A.ID And  c.Owner_Id = @permUserId ) THEN 1 ELSE 0 END AS isChecked
					,'' as [status]
					from 
						(SELECT ID
						,ISNULL(PID,System_ID) AS PID, Func_Name,Func_Serial,
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B Where A.ID = B.Module_Id) C where  C.PID=f.ID ) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @currUserId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @currUserId) B where  B.Module_Id=f.ID ) THEN 1 ELSE 0 END AS HasPermission,'' as status
					FROM OPF_SYS_Functions f WHERE Status = 1 ) A 
					Where A.HasPermission =1 and A.PID= @parentId order by A.Func_Serial
			end 
		end
	end
	
END
GO
