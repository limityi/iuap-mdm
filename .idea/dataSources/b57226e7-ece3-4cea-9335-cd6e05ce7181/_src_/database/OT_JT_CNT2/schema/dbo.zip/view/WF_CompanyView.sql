CREATE VIEW [dbo].[WF_CompanyView]
AS
SELECT     ID, 
PID AS ParentID, 
Comp_Code AS CompanyCode, 
Comp_Name AS CompanyName,
  Comp_Type as  CompType, 
  '' ProjectID, 
  Remark, 
  case when Status=1 then '1100102' else '1100101' end as Status, 
  Comp_Serial AS Serial, 
  '' CompStyle, 
         '' IsComp
FROM         dbo.OPF_Org_Company
GO
