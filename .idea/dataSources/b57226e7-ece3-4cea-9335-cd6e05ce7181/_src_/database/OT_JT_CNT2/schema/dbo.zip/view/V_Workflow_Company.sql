---新增公司视图
CREATE VIEW [dbo].[V_Workflow_Company]
AS
SELECT ID, 
PID,
Comp_Code,
Comp_Short_Name,
Comp_Name,
Comp_Serial   
FROM OPF_Org_Company
WHERE Status=1

GO
