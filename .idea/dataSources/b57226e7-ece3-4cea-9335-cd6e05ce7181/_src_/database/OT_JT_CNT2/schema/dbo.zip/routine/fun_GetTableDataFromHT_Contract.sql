create function fun_GetTableDataFromHT_Contract( @IsActive bit = 1)
returns  table  
as  
return (select * from  HT_Contract where ( @IsActive=0  and  Is_Active=0) or (@IsActive=1 and (Is_Active=1 or Is_Active is null)))


GO
