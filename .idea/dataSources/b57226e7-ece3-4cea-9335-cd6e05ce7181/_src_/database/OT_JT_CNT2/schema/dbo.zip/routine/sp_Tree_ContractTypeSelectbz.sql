

CREATE proc [dbo].[sp_Tree_ContractTypeSelectbz]  
    @parentId nvarchar(50)
as  
select ID, PID, Name, NodeType, isnull((select top 1 1 from V_CNT_Tree_ContractTypeSelect  b  where a.id=b.pid and  OrgID='' ),0) as HasChild ,
'' IsChecked,'' Status,'' Disabled, RID , board, Code, Serial,  nodeType, OrgID from dbo.V_CNT_Tree_ContractTypeSelect a
where  OrgID='' and PID=@parentId order by Serial asc


GO
