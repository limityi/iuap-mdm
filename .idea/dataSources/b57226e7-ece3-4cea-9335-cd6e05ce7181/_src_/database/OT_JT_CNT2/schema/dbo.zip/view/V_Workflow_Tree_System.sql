
CREATE VIEW [dbo].[V_Workflow_Tree_System]
AS
	Select ID,Name,NULL AS ParentId,0 as nodeType,Serial
	FROM dbo.OPF_Sys_PlatForm
	WHERE Status=1 and IsBusiness=1

GO
