CREATE VIEW [dbo].[WF_EmpRoleView]
AS
SELECT     ID, Emp_ID AS EmployeeID, Role_ID as RoleID
FROM         dbo.OPF_Rig_User_Role
GO
