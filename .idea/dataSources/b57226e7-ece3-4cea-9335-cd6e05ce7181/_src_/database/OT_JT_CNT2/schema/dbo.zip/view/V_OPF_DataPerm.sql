
---2013-9-12
---过滤掉emplId is null
CREATE VIEW [dbo].[V_OPF_DataPerm]
AS
SELECT     NEWID() AS ID, Emp_Id, Bu_Data_Id, Data_Type_Code, Data_Type_Id,Is_ReadOnly
FROM  (
SELECT DISTINCT 
CASE WHEN Owner_Type = 0 THEN dbo.OPF_Rig_DataPermission.Owner_Id ELSE dbo.OPF_Rig_User_Role.Emp_ID END AS Emp_Id, 
dbo.OPF_Rig_DataPermission.Bu_Data_Id,
dbo.OPF_Rig_DataPermission.Data_Type_Code,
dbo.OPF_Rig_DataPermission.Data_Type_Id,
dbo.OPF_Rig_DataPermission.Is_ReadOnly
FROM  dbo.OPF_Rig_DataPermission LEFT OUTER JOIN
dbo.OPF_Rig_User_Role ON dbo.OPF_Rig_User_Role.Role_ID = dbo.OPF_Rig_DataPermission.Owner_Id
) AS a
where Emp_Id IS NOT NULL


GO
