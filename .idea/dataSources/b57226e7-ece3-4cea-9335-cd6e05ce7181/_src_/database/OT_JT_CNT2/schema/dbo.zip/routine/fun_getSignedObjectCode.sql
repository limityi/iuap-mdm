/*
	得到签约对方编号,若编号无法通过现有数据直接取得时通过@IsAutoBuildNewCode 可以决定是否可以在本系统中生成一个新编号
	返回对应签约方编号。可能为NULL值
	韦永军
	2014.7.2
*/
 
CREATE function [dbo].[fun_getSignedObjectCode](@signObjectID varchar(64),@signObjectName varchar(256),@Type smallint,@IsAutoBuildNewCode bit)
returns  varchar(64)
as
begin
    declare @code varchar(64)
	--1.如果签约方列表已经存在则直接取出编号
	select @code=code from HT_SignedObject where SignObjectID=@signObjectID and [Type]=@Type
	--2.如果编号不存在则再次尝试看组织机构表中是否存在，若存在则直接取出编号
	if(@code is null or @code='')
	    select @code=[BUDataCode] from [Org_CompanyDeptSimpleView] where [BUDataName]=@signObjectName
	--3.如果编号不存在则从主数据平台中取得。
	--暂未没有主数据平台
	--4.如果编号不存在则在本系统内进行统一生成。生成规则按主数据规则外部单位W+6位顺序号，个人则P+8位顺序号
	if((@code is null or @code='') and @IsAutoBuildNewCode=1)
	begin	   
	    declare @MaxNumber varchar(10)
		if(@Type=0)
		begin
	        select @MaxNumber=max(code) from HT_SignedObject where [Type]=0 and code like 'W%' 
			 if ( @MaxNumber is null) set @MaxNumber=''
			select @code='W'+right('000000'+  convert(varchar(6),a),6) from (select  Convert(int,replace(@MaxNumber,'W',''))+1 a) x
		end
        else
		begin
		    select @MaxNumber=max(code) from HT_SignedObject where [Type]=1 and code like 'P%'
			 if ( @MaxNumber is null) set @MaxNumber=''
			select @code='P'+right('00000000'+ convert(varchar(8),a),8) from (select  Convert(int,replace(@MaxNumber,'P',''))+1 a) x
	    end
	end
	return @code
end

GO
