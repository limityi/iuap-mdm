create proc sp_UpOrg as 
with aa as(
select * from HT_UpdateOrgTemp where pcode=''
union all
select b.* from HT_UpdateOrgTemp b inner join aa a on b.PCode=a.Code where b.code<>'N000001'
)
delete  from HT_UpdateOrgTemp where code in (select code from aa)
update HT_UpdateOrgTemp set pcode='' where code='N000001'
;
update a set a.id=b.id,a.TreePath=b.Tree_Code from HT_UpdateOrgTemp a inner join OPF_Org_Company b on a.Code=b.Comp_Code where a.OrgType=1
update a set a.id=b.id,a.TreePath=b.Tree_Code from HT_UpdateOrgTemp a inner join OPF_Org_Department b on a.Code=b.Depa_Code where a.OrgType=0
update HT_UpdateOrgTemp set id=newid() where id is null
update a set a.PId=b.id from HT_UpdateOrgTemp a inner join HT_UpdateOrgTemp b on a.PCode=b.Code where a.OrgType=1  
update a set a.compcode=b.code,a.compid=b.id from HT_UpdateOrgTemp a inner join HT_UpdateOrgTemp b on a.PCode=b.Code where a.OrgType=0 and b.OrgType=1
update a set a.compcode=c.code,a.compid=c.id,a.PId=b.Id from HT_UpdateOrgTemp a inner join HT_UpdateOrgTemp b on a.PCode=b.Code inner join  HT_UpdateOrgTemp c on b.PCode=c.Code where a.OrgType=0 and b.OrgType=0 and c.OrgType=1 
update a set a.compcode=d.code,a.compid=d.id,a.pid=b.id from HT_UpdateOrgTemp a inner join HT_UpdateOrgTemp b on a.PCode=b.Code inner join  HT_UpdateOrgTemp c on b.PCode=c.Code inner join  HT_UpdateOrgTemp d on c.PCode=d.Code where a.OrgType=0 and b.OrgType=0 and c.OrgType=0 and  d.OrgType=1
update a set a.compcode=e.code,a.compid=e.id,a.PId=b.Id from HT_UpdateOrgTemp a inner join HT_UpdateOrgTemp b on a.PCode=b.Code inner join  HT_UpdateOrgTemp c on b.PCode=c.Code inner join  HT_UpdateOrgTemp d on c.PCode=d.Code inner join  HT_UpdateOrgTemp e on d.PCode=e.Code where a.OrgType=0 and b.OrgType=0 and c.OrgType=0 and  d.OrgType=0 and e.OrgType=1
update HT_UpdateOrgTemp set TreePath=null
;
with torg as (
select *,cast(right(100000000+(ROW_NUMBER() OVER(order by serial)),6) as nvarchar(200))+'.' ordercol  from HT_UpdateOrgTemp where  pcode is null or PCode=''
union all 
select a.*, cast((b.ordercol+right(100000000+(ROW_NUMBER() OVER(order by a.serial)),6)) as nvarchar(200))+'.' ordercol from HT_UpdateOrgTemp a inner join torg b on a.PCode=b.code  where a.OrgType=1
) 
update a set a.treepath=b.ordercol from  HT_UpdateOrgTemp a inner join torg b on a.Code=b.code where a.OrgType=1
;
with torg2 as (
select *,cast(right(100000000+(ROW_NUMBER() OVER(order by serial)),6) as nvarchar(200))+'.' ordercol  from HT_UpdateOrgTemp   where OrgType=0 and PId is null
union all 
select a.*, cast((b.ordercol+right(100000000+(ROW_NUMBER() OVER(order by a.serial)),6)) as nvarchar(200))+'.' ordercol from HT_UpdateOrgTemp a inner join torg2 b on a.PCode=b.code  where a.OrgType=0
) 
update a set a.treepath=b.ordercol from  HT_UpdateOrgTemp a inner join torg2 b on a.Code=b.code where a.OrgType=0
--增加公司
insert into OPF_Org_Company(ID, PID, Comp_Code, Comp_Short_Name, Comp_Name, Status, Comp_Serial, Tree_Code, CreateTime, UpdateTime)
select Id,PId,Code,ShortName,Name,1 status,serial,TreePath,getdate(),getdate() from HT_UpdateOrgTemp where OrgType=1 and id not in (select id from OPF_Org_Company) and (ActType=1 or ActType=0) and IsUpdate=0
--修改公司
update  a set a.Comp_Name=b.Name,a.Comp_Short_Name=b.ShortName,a.Comp_Serial=b.Serial,a.Tree_Code=b.TreePath,a.PID=b.PId
from OPF_Org_Company a inner join HT_UpdateOrgTemp b on a.id=b.Id where b.OrgType=1 and (b.ActType=1 or b.ActType=0) and b.IsUpdate=0
--删除公司
update a set a.Status=0
from OPF_Org_Company a inner join HT_UpdateOrgTemp b on a.id=b.Id where b.OrgType=1 and b.ActType=-1  and b.IsUpdate=0
--增加部门
insert into OPF_Org_Department(ID, PID, Company_ID, Depa_Code, Depa_Name,   Depa_Serial, Status, Tree_Code, CreateTime, UpdateTime)
select Id,PId,CompId, Code,Name,serial,1 status,TreePath,getdate(),getdate() from HT_UpdateOrgTemp where OrgType=0 and id not in (select id from OPF_Org_Department) and (ActType=1 or ActType=0) and IsUpdate=0 and CompId is not null
--修改部门
update  a set a.Depa_Name=b.Name,a.Depa_Serial=b.Serial,a.Tree_Code=b.TreePath,a.Company_ID=CompId,a.PID=b.PId
from OPF_Org_Department a inner join HT_UpdateOrgTemp b on a.id=b.Id where b.OrgType=0 and (b.ActType=1 or b.ActType=0) and b.IsUpdate=0 and b.CompId is not null
--删除部门
update a set a.Status=0
from OPF_Org_Department a inner join HT_UpdateOrgTemp b on a.id=b.Id where b.OrgType=0 and b.ActType=-1  and b.IsUpdate=0
--设置临时表状态
update HT_UpdateOrgTemp set IsUpdate=1
GO
