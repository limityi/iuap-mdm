create view V_HT_Contract_Project_History
as 
select * from HT_Contract_Project where Is_Active=0

GO
