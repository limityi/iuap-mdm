create view [dbo].[v_tongyi_HT_ReceivingVoucherRegister] 
as
select * from  OT_JT_CNT2.DBO.HT_ReceivingVoucherRegister
where Contract_Id in (select id from v_tongyi_HT_Contract)
GO
