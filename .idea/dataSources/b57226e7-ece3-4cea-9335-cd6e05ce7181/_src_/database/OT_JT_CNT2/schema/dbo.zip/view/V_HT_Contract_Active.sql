



CREATE view [dbo].[V_HT_Contract_Active]
as 
select * from dbo.HT_Contract where Is_Active=1


GO
