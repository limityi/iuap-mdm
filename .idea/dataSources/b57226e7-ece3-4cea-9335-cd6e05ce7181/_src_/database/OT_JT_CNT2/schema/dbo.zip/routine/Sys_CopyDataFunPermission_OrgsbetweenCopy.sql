 
 


/*
	根据提供源、目标组织ID、源、目标角色ID，进行交叉权限COPY，方式将已经COPY好的源组织的源角色的权限COPY目标组织的目标角色上
	黙认不删除原来的目标组织的权限
	要求源、目标组织均不可以为空,且不能相同

 --select * from  SYS_PermBUData --取得所有交叉组织信息
 --select * from sys_role --取得系统角色信息
*/
CREATE proc [dbo].[Sys_CopyDataFunPermission_OrgsbetweenCopy] 
	@soruceOrgID varchar(300) --源组织ID	
	,@airmOrgID varchar(300)  --目标组织ID
	,@soruceRoleID varchar(300) --源角色ID
	,@arimRoleID varchar(300)  --目标角色ID
    ,@isDelAirmOrgDataFunPermission bit=0 --是否删原来的目标组织的权限,黙认不删除
as
if(@soruceOrgID<>'' and @airmOrgID<>'' and @soruceOrgID<>@airmOrgID)
begin
	if(@isDelAirmOrgDataFunPermission=1)
	begin	 
		delete [Sys_DataFunPermission]	where  [RoleID]=@arimRoleID  
		--delete Sys_DataFunPermission where DataFunID in (select Sys_DataFun.ID from Sys_DataFun where  DataID=@airmOrgID  and @arimRoleID=@soruceRoleID)		 
	end 
	declare @FunID varchar(300),@SourceDataFunID varchar(300)
	declare myx cursor for select ID,FunID from Sys_DataFun where  DataID=@soruceOrgID
	set @FunID=''
	set @SourceDataFunID=''	 
	open myx 
	fetch next from myx into @SourceDataFunID,@FunID
	while @@fetch_status=0
	begin
		declare @DataFunID varchar(300) 
		set @DataFunID=null
		select @DataFunID=id from  Sys_DataFun where FunID=@FunID and DataID=@airmOrgID
		if(@DataFunID is null)
		begin
			set @DataFunID=newid()
			insert Sys_DataFun(ID,FunID,DataID) values (@DataFunID,@FunID,@airmOrgID)		
		end 
		if(not exists(select * from Sys_DataFunPermission where DataFunID=@DataFunID and RoleID=@arimRoleID))
			INSERT INTO [Sys_DataFunPermission] ([ID], [DataFunID], [EmployeeID], [RoleID], [PermMode], [PermType])	
		 select   newid(),@DataFunID,NULL,@arimRoleID,[PermMode], [PermType] from [Sys_DataFunPermission] where  DataFunID=@SourceDataFunID and RoleID=@soruceRoleID
		fetch next from myx into @SourceDataFunID,@FunID
	end
	close myx
	deallocate myx 
end


GO
