CREATE VIEW [dbo].[V_OPF_Employee]
AS
/*-岗位人员,431主要岗位，432兼任岗位*/ 
SELECT r.ID AS Id, e.Emp_Id AS EmplId, e.[Empl_Code] AS EmplCode, e.[User_Code] AS UserCode, e.[Empl_Name] AS EmplName, 
                      e.[Sex], e.[Phone], e.[Mobile],e.[EMail], e.[Status], r.Serial, p.id AS ParentId, CASE WHEN r.Is_Primary = 1 THEN 431 ELSE 432 END AS OrgType, 
                      r.Dep_ID AS DepartmentId,d.Depa_Serial  as DepaSerial 
FROM         OPF_Org_Employee e INNER JOIN
                      OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.Emp_Id INNER JOIN
                      OPF_Org_Dep_Position p ON r.Dep_Position_ID = p.ID
                     LEFT JOIN  OPF_Org_Department d ON r.Dep_ID = d .ID
                       
UNION ALL
/*-部门人员,421主要部门人员,422兼任部门*/ 
SELECT r.ID, e.Emp_Id, e.[Empl_Code], e.[User_Code], e.[Empl_Name], e.[Sex], e.[Phone], e.[Mobile],e.[EMail], e.[Status], r.Serial, 
                      d .id AS parentId, CASE WHEN r.Is_Primary = 1 THEN 421 ELSE 422 END
                      , r.Dep_ID,d.Depa_Serial
FROM         OPF_Org_Employee e INNER JOIN
                      OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.Emp_Id INNER JOIN
                      OPF_Org_Department d ON r.Dep_ID = d .ID
WHERE     r.Dep_Position_ID IS NULL

GO
