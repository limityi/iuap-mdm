CREATE VIEW dbo.V_HT_Contract_Belong
AS
SELECT     a.ID, b.ID AS PayId, c.ID AS ChangId, d.ID AS SettleId
FROM         dbo.HT_Contract_Belong AS a LEFT OUTER JOIN
                      dbo.HT_Payment AS b ON a.Contract_ID = b.ContractID LEFT OUTER JOIN
                      dbo.HT_Changes AS c ON a.Contract_ID = c.Contract_ID LEFT OUTER JOIN
                      dbo.HT_Settlement AS d ON a.Contract_ID = d.Contract_ID
GO
