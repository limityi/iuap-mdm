 
--網站全文搜索關关
 
CREATE proc [dbo].[sp_searchContent] 
@searchText varchar(300)
,@typeid int
,@page int
,@everypagenum int
,@Systemid varchar(50)=''
,@orgid varchar(5000)=''
as
if(@page<=0)
	set @page=1
if(@Systemid is null)
	set @Systemid=''
if(@orgid is null)
	set @orgid=''
else
	set @orgid=replace(@orgid,',',''',''') 
declare @beginrow int,@endrow int
set @beginrow=(@page-1)*@everypagenum
set @endrow=@beginrow+@everypagenum
DECLARE @SQLString nvarchar(max); 
declare @tabl table(id varchar(36))
----方案1 全文索引
if(@typeid=1)
begin   --可以用多個關鍵，以or分開
	if( charindex(' ',@searchText)>0)
		set @searchText=replace(@searchText,' ','" or "')
	set @searchText=replace(@searchText,',','" or "')
	set @searchText='"'+@searchText+'"'
    insert @tabl(id) select ID  from Common_Search_MainIndex 
    where 
    --( @Systemid<>'' and Systemid=@Systemid )     and
      ( @orgid<>'' and orgid in(@orgid) or @orgid='' )
    and Operation=0
    and   contains ([content1],@searchText)
     set @searchText= '%'+@searchText+'%'
	 select * from (select row_number() over (order by lastdate desc) rownum,
	 substring([content1],case when PATINDEX( @searchText ,[content1])<20 then 0 else PATINDEX( @searchText ,[content1])-20 end ,300) BODY
	, url, HEAD, ModelName,lastdate  from Common_Search_MainIndex c join @tabl t on c.ID=t.id and c.Operation=0 )x 
	 where rownum between @beginrow  and  @endrow
	 select count(*) rownum from @tabl    
end
else
if (@typeid=2)
begin
	----方案2 like
	if( charindex(' ',@searchText)>0)
		set @searchText=replace(@searchText,' ','%'' or [content1] like ''%')
	set @searchText= '%'+@searchText+'%'
    insert @tabl(id) select ID  from Common_Search_MainIndex 
    where 
    --( @Systemid<>'' and Systemid=@Systemid ) and
    ( @orgid<>'' and orgid in(@orgid) or @orgid='' )
    and Operation=0 
    and  [content1] like  @searchText
	select * from (
		select row_number() over (order by lastdate desc) rownum,
		 substring([content1],0,300)BODY
		,url,HEAD,ModelName,lastdate    from Common_Search_MainIndex c join @tabl t on t.id=c.ID and c.Operation=0 
	 ) x 
	 where rownum between @beginrow  and  @endrow
     select count(*) rownum from @tabl 
 end
else
if (@typeid=3)
begin
	----方案3  xml index 
	--if( charindex(' ',@searchText)>0)
	--	set @searchText=replace(@searchText,' ','")'',''bit'')  = 1 or [content].value(''contains( (//*)[1],"')
	--set @SQLString='select * from (select row_number() over (order by lastdate desc) rownum,
	--[content1].query(''//*/text()'') BODY
	--,url,HEAD,ModelName,lastdate  from Search_MainIndex '
	--set @SQLString=@SQLString+' where '+(case when  @Systemid<>'' then ' Systemid='''+@Systemid+''' and ' else '' end )+(case when  @orgid<>'' then ' (orgid is null or orgid=''''  or orgid in('''+@orgid+''') )  and ' else '' end )+' [content1].value(''contains( (//*)[1],"'+@searchText+'")'',''bit'')  = 1 '
	--set  @SQLString=@SQLString+') x where rownum between '+convert(varchar(30),@beginrow) +' and '+convert(varchar(30),@beginrow+@everypagenum)
	--set  @SQLString=@SQLString+';select count(*) rownum from Search_MainIndex  where '+(case when  @Systemid<>'' then ' Systemid='''+@Systemid+''' and ' else '' end )+(case when  @orgid<>'' then ' (orgid is null  or orgid='''' or orgid in('''+@orgid+''') )  and ' else '' end )+' [content1].value(''contains( (//*)[1],"'+@searchText+'")'',''bit'')  = 1 '
	--print @SQLString
	--execute sp_executesql @SQLString
		if( charindex(' ',@searchText)>0)	
		set @searchText=replace(@searchText,' ','")'',''bit'')  = 1 or [content1].value(''contains( (//*)[1],"')
		set @searchText=replace(@searchText,',','")'',''bit'')  = 1 or [content1].value(''contains( (//*)[1],"')
		set @searchText='"'+@searchText+'"'
		insert @tabl(id) select ID  from Common_Search_MainIndex 
    where 
    --( @Systemid<>'' and Systemid=@Systemid )     and 
     ( @orgid<>'' and orgid in(@orgid) or @orgid='' )
    and Operation=0
    and  [content1].value('contains( (//*)[1],'+@searchText+')','bit')  = 1 
    select * from (select row_number() over (order by lastdate desc) rownum,
	[content1].query('//*/text()') BODY
	,url,HEAD,ModelName,lastdate  from Common_Search_MainIndex c join @tabl t on t.id=c.ID and c.Operation=0 
	 ) x 
	 where rownum between @beginrow  and  @endrow
	 select count(*) rownum from @tabl   
 
 
end


GO
