CREATE VIEW [dbo].[WF_DepPosiEmplView]
AS
SELECT    r.ID,
 r.Dep_Position_ID as DepPositionID, 
r.Employee_ID as EmployeeID, 
  case when p.Status=1 then '1100102' else '1100101' end as Status
FROM    OPF_Org_Dep_Posi_Empl r
inner join dbo.OPF_Org_Dep_Position p on p.ID=r.Dep_Position_ID
GO
