/*
	取得某个公司的数据授权用户，含角色用户和直接授权用户
	2012-11-12
	韦永军
*/

CREATE function [dbo].[get_DataPowerUserIDs](@companyid varchar(300))
  returns  @userids table(id varchar(300),companyid varchar(40))
as
begin
	declare @table table (RoleID varchar(300),EmployeeID varchar(300))
	insert @table
	select distinct RoleID,  EmployeeID from Sys_DataPermission a join SYS_PermBUData b on a.PermBUDataID=b.id join Org_Company c on b.BUDataID=c.ID
	where c.ID=@companyid

	insert @userids
	select id,compid from  dbo.Org_Employee e join (
		select empid from dbo.Sys_UserRole a join @table x on a.roleid=x.roleid and a.roleid is not null
		union 
		select EmployeeID empid from @table where employeeid is not null) poweruser on poweruser.empid=e.id and e.status='1100102'
	
	
	return 
end


GO
