 
CREATE proc [dbo].[sp_SaveHT_SignedObjectReName]
@Id varchar(36),
@SignedObjectExInfoID  varchar(36),
@NameBefore  nvarchar(128),
@NameAter nvarchar(128),
@ShortNameAter nvarchar(128),
@ReNameDate datetime
as

--delete HT_SignedObjectReNameHistory where SignedObjectExInfoID='{1}';
update HT_SignedObjectExInfo set Name=@NameAter,Short_Name=@ShortNameAter where  id=@SignedObjectExInfoID;
INSERT HT_SignedObjectReNameHistory([Id],[SignedObjectExInfoID],[NameBefore],[NameAter],ShortNameAter,[ReNameDate])
    VALUES(@Id,@SignedObjectExInfoID,@NameBefore,@NameAter,@ShortNameAter,@ReNameDate);
GO
