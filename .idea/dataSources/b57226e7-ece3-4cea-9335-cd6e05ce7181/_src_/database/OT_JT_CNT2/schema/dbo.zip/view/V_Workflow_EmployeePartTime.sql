CREATE VIEW dbo.V_Workflow_EmployeePartTime
AS
SELECT     dbo.OPF_Org_Department.Company_ID AS CompId, dbo.OPF_Org_Dep_Posi_Empl.Dep_ID AS DepaId, 
                      dbo.OPF_Org_Dep_Posi_Empl.Employee_ID AS EmplId, dbo.OPF_Org_Dep_Posi_Empl.Is_Primary, dbo.OPF_Org_Dep_Posi_Empl.ID
FROM         dbo.OPF_Org_Dep_Posi_Empl INNER JOIN
                      dbo.OPF_Org_Department ON dbo.OPF_Org_Dep_Posi_Empl.Dep_ID = dbo.OPF_Org_Department.ID
WHERE     (dbo.OPF_Org_Dep_Posi_Empl.Is_Primary = 0) OR
                      (dbo.OPF_Org_Dep_Posi_Empl.Is_Primary IS NULL)
GO
