 
/*
	取得公司的所有子公司ID（含当前所在的公司ID）
	本方法是代替fun_GetAllSubCompanyIDsOfCompanyid_core调用
	，fun_GetAllSubCompanyIDsOfCompanyid_core函数效率不高，改用查询后用临时表Org_AllDirectSubCompanyIDsOfCompanyid存储
	2014.3.6 weiyj
 
*/
CREATE function [dbo].[fun_GetAllSubCompanyIDsOfCompanyid]( @pcompanyCodes varchar(max))
returns  @companyids table(CompCode varchar(300))
as
begin  	
	insert @companyids select * from dbo.Func_GetSplitStringTable2(@pcompanyCodes)
	insert @companyids select SubCompanyID from Org_AllSubCompanyIDsOfCompanyid_Cache where pid in (select * from @companyids)
	 return 
end

GO
