/*
	签约方的银行帐号信息保存
*/

CREATE proc  [dbo].[sp_SaveHT_SignedObjectBankAccountInfo]
 @Id uniqueidentifier,
 @SignedObjectExInfoID uniqueidentifier,
 @OpeningBank nvarchar(256),
 @OpeningAccount nvarchar(64),
 @AccountName nvarchar(64),
 @createdDeptId nvarchar(50)
as
if(exists(select * from HT_SignedObjectBankAccountInfo where Id=@Id ))                    
	update HT_SignedObjectBankAccountInfo set OpeningBank=@OpeningBank,OpeningAccount=@OpeningAccount,AccountName=@AccountName where Id=@Id 
else
    insert HT_SignedObjectBankAccountInfo(Id,SignedObjectExInfoID,OpeningBank,OpeningAccount,AccountName,createdDeptId)
    values(@Id,@SignedObjectExInfoID,@OpeningBank,@OpeningAccount,@AccountName,@createdDeptId)
GO
