
/*取得合同总金额函数
  原则：如有结算金额，先取结算金额，无结算有变更金额，则取变更金额，否则直接取签约金额
*/
CREATE function [dbo].[fun_getHT_ContractAmountOK](@CntId varchar(36))
  returns decimal
as 
begin 
   declare @Contract_Amount decimal,@Change_Amount decimal,@Settlement_Amount decimal
   select @Contract_Amount=Contract_Amount, @Change_Amount=Change_Amount,@Settlement_Amount=Settlement_Amount from HT_Contract where id=@CntId
   if(@Settlement_Amount is not null) return @Settlement_Amount 
   if(@Change_Amount is not null) return @Change_Amount 
   return isnull(@Contract_Amount,0)
end
GO
