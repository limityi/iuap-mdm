

CREATE proc [dbo].[sp_ht_getProject]
  @orgid varchar(36)
 ,@ProjectYear int=null
 ,@name varchar(36)=null --名称
 ,@IsBudget bit=1
 ,@ProjectCode varchar(64)=null --项目编号
 ,@BudgetCode varchar(64)=null --预算编号
as
if(@name='') set @name=null else set @name = '%'+@name+'%';
if(@ProjectCode='') set @ProjectCode=null else set @ProjectCode = '%'+@ProjectCode+'%';
if(@BudgetCode='') set @BudgetCode=null else set @BudgetCode = '%'+@BudgetCode+'%';

if(@name is not null or @ProjectCode is not null or @BudgetCode is not null)--有特别过滤条件时 
begin 
 with filtersubqry([Id],[PId],[Name],[ShortName],[ProjectCode],[ProjectYear],[BudgetMoney],[BudgetCode],[IsBudget],[Note],[OrgID],[DataLevel],[LevelOrder],[Status])
 as ( 
  select [Id],[PId],[Name],[ShortName],[ProjectCode],[ProjectYear],[BudgetMoney],[BudgetCode],[IsBudget],[Note],[OrgID],[DataLevel],[LevelOrder],[Status]

    from HT_Project
	where  orgid=@orgid and ([ProjectYear]=@ProjectYear or [ProjectYear] is null) and  [IsBudget]=@IsBudget and [status] in(1,0)
	       and (@name is null or(@name is not null and (Name like @name or ShortName like @name)))
		   and (@ProjectCode is null or(@ProjectCode is not null and ProjectCode like @ProjectCode))
		   and (@BudgetCode is null or(@BudgetCode is not null and BudgetCode like @BudgetCode))
  union all
  select  test1.[Id],test1.[PId],test1.[Name],test1.[ShortName],test1.[ProjectCode],test1.[ProjectYear],test1.[BudgetMoney],test1.[BudgetCode],test1.[IsBudget],test1.[Note],test1.[OrgID],test1.[DataLevel],test1.[LevelOrder],test1.[Status]
    from HT_Project test1,filtersubqry
    where test1.id = filtersubqry.PId and  test1.OrgID=@orgid and (test1.[ProjectYear]=@ProjectYear or test1.[ProjectYear] is null)  and  test1.[IsBudget]=@IsBudget and test1.[status] in(1,0)
   )   
 select ROW_NUMBER()over (order by projectcode,datalevel,levelorder) rownum,* ,(select COUNT(1) from filtersubqry  where PId=x.Id) ChilrenCount from (select distinct * from  filtersubqry) x order by rownum ;
end
else
begin
with --没有特别过滤条件时 
	subqry([Id],[PId],[Name],[ShortName],[ProjectCode],[ProjectYear],[BudgetMoney],[BudgetCode],[IsBudget],[Note],[OrgID],[DataLevel],[LevelOrder],[Status])
	 as (
	  select [Id],[PId],[Name],[ShortName],[ProjectCode],[ProjectYear],[BudgetMoney],[BudgetCode],[IsBudget],[Note],[OrgID],[DataLevel],[LevelOrder],[Status]

		from HT_Project
		where  pid is null          and  orgid=@orgid and ([ProjectYear]=@ProjectYear or [ProjectYear] is null) and  [IsBudget]=@IsBudget and [status] in(1,0)
	  union all
	  select  test1.[Id],test1.[PId],test1.[Name],test1.[ShortName],test1.[ProjectCode],test1.[ProjectYear],test1.[BudgetMoney],test1.[BudgetCode],test1.[IsBudget],test1.[Note],test1.[OrgID],test1.[DataLevel],test1.[LevelOrder],test1.[Status]
		from HT_Project test1,subqry
		where test1.pid = subqry.id and  test1.OrgID=@orgid and (test1.[ProjectYear]=@ProjectYear or test1.[ProjectYear] is null)  and  test1.[IsBudget]=@IsBudget and test1.[status] in(1,0)
	  )
 select ROW_NUMBER()over (order by projectcode,datalevel,levelorder) rownum,* ,(select COUNT(1) from subqry  where PId=x.Id) ChilrenCount from subqry x order by rownum ;
 end
GO
