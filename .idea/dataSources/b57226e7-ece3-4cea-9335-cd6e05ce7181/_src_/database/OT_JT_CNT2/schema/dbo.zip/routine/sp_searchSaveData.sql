 
create procedure [dbo].[sp_searchSaveData]
@ViewThisPageURL varchar(8000)
,@SaveDataInfo text
,@modelname  nvarchar(100)
,@head  nvarchar(100)
,@thispageid varchar(36)
,@SystemID varchar(50)=''
,@Orgid varchar(36)=''
as
if(@thispageid<>'' and @thispageid is not null and exists(select * from Common_Search_MainIndex where thispageid=@thispageid and SystemID=@SystemID))
	update Common_Search_MainIndex set Content1=@SaveDataInfo
	,url=@ViewThisPageURL
	,modelname=@modelname
	,head=@head
	,lastdate=getdate()
	,orgid=@orgid where thispageid=@thispageid and SystemID=@SystemID
else
begin
	if(@thispageid='')
		set @thispageid=newid()
	insert Common_Search_MainIndex(id,Content1,url,modelname,head,lastdate,thisPageID,SystemID,orgid,Operation)
		values(newid(),@SaveDataInfo,@ViewThisPageURL,@modelname,@head,getdate(),@thisPageID,@SystemID,@orgid,0)
end

GO
