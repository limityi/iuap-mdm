 


CREATE proc [dbo].[Common_WarningInstanceInsert]
 @WarningInstanceID uniqueidentifier,
 @WarningSettingID uniqueidentifier,
 @WarningOrgID varchar(36),
 @WarningManID varchar(36),
 @LinkFileID varchar(36),
 @LinkFileName nvarchar(500),
 @PeriodDefined int,
 @PeriodInValue varchar(1000),
 @Period_End datetime,
 @Period_Begin datetime,
 @WarningCount_Fact int,
 @PeriodLessNum int,
 @Vaild_End datetime,
 @vaild_Begin datetime,
 @Vaild_LastBegin datetime,
 @VaildTo datetime,
 @Status int=1,
 @CreateDate datetime 
as
--将同周期同一模板号的已经存在的实例设为停止，永远不用的为无效
--update Common_WarningHistory set Status=4 where WarningInstanceID 
--	in(select WarningInstanceID from Common_WarningInstance where WarningSettingID=@WarningSettingID and (WarningOrgID is null or WarningOrgID=@WarningOrgID) and PeriodDefined=@PeriodDefined
--			 and Period_Begin=@Period_Begin and Period_End=@Period_End and status in (1,2))  

update Common_WarningInstance set Status=3 where WarningSettingID=@WarningSettingID and (WarningOrgID is null or WarningOrgID=@WarningOrgID) and (WarningManID is null or WarningManID=@WarningManID) and (linkFileID is null or linkFileID=@linkFileID)and PeriodDefined=@PeriodDefined
			 and Period_Begin=@Period_Begin and Period_End=@Period_End and status in (1,2)
insert Common_WarningInstance(WarningInstanceID,
WarningSettingID,WarningOrgID,WarningManID,LinkFileID,LinkFileName,PeriodDefined,PeriodInValue,Period_Begin,Period_End,
WarningCount_Fact,PeriodLessNum,Vaild_End,VaildTo,Vaild_LastBegin,
vaild_Begin,Status,CreateDate) values(@WarningInstanceID,
@WarningSettingID,@WarningOrgID,@WarningManID,@LinkFileID,@LinkFileName,@PeriodDefined,@PeriodInValue,@Period_Begin,@Period_End,
@WarningCount_Fact,@PeriodLessNum,@Vaild_End,@VaildTo,@Vaild_LastBegin,
@vaild_Begin,@Status,@CreateDate)


GO
