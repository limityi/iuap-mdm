CREATE view [V_CNT_Tree_ContractItemModel] as
/*合同清单范本*/
 SELECT 
 Convert(nvarchar(36),ID) AS ID, 
 Item_Code AS ItemCode, 
 Item_Name AS ItemName,
  '1' AS [Status], 
  '1' as nodeType,  
  Convert(nvarchar(36),ISNULL(PID,'D664FE6B-15D4-4956-B836-81B9E41F086B')) AS ParentID, 
  Is_Child as IsChild,
CASE WHEN EXISTS
                          (SELECT     *
                            FROM          HT_Item_Model
                            WHERE      PID = c.ID) 
                      THEN 1 ELSE 0 END AS HasChild,
Company_ID as CompanyID
FROM         HT_Item_Model c
union
Select 
'D664FE6B-15D4-4956-B836-81B9E41F086B' as ID,
'' as ItemCode,
'集团合同清单范本' AS ItemName,
'1' AS [Status], 
 '0' as nodeType, 
NULL AS ParentID, 
0 as IsChild, 
case when exists(select * from HT_Item_Model where PID is null)  then 1 else 0 end AS HasChild,
'D664FE6B-15D4-4956-B836-81B9E41F086B' as CompanyID
GO
