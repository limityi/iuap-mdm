/*
	将高级搜索的过滤条件解析一个SQL字符串。本方法可以共用
	如过滤条件为：'ht.name:like:合同',@andor='and'
	解析为：ht.name like '合同%' and...
*/ 
 
 
CREATE function  [dbo].[fun_getAdvanceSearchfilter] 
	(
	@keyvalues varchar(max)
	,@andor varchar(30)
	)
returns  varchar(max)
as 
begin
	--select @keyvalues='ht.name:like:合同`ht.name:like:合同2`ht.ClearingMoney:>=:23320000
	declare @table table(keys varchar(300),rel varchar(30),valuex varchar(300))
	insert @table
		select * from dbo.Func_GetSplitStringTable_searchkeyvalue(@keyvalues,'`',':')
	declare @wherex varchar(max)
	set @wherex=''
	declare mycur cursor for select * from @table 
	open mycur
	declare @keys varchar(300),@rel varchar(30),@valuex varchar(300)
	fetch next from  mycur into @keys,@rel,@valuex
	while(@@FETCH_STATUS=0)
	begin	
		if(@wherex<>'')
			SET @wherex=@wherex+@andor
		SET @wherex=@wherex+' ( '+	@keys 
		if(@rel='like')
			SET @wherex=@wherex+' '+ @rel+' ''%'+	@valuex +'%'' '
		else
			SET @wherex=@wherex+' '+@rel+' '''+	@valuex +''' '
		SET @wherex=@wherex+' ) '
		fetch next from  mycur into @keys,@rel,@valuex
	end
	return @wherex
 end

GO
