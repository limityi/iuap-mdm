
CREATE view [dbo].[V_HT_Payment_Item_Active]
as 
select * from HT_Payment_Item where Is_Active=1


GO
