
  
/*
	oss预警服务自动在新一年的时候创建新的模板，以上一年的年、月、月组合，季,跨年为准
*/
create proc [dbo].[Common_AutoCreateNewYearWarningSettingModel]
@year int,
@airmYear int
as
begin try
	if(not exists(select 1 from Common_WarningWindowService where [currentyear]=@airmYear))
		insert Common_WarningWindowService(currentyear,isok) values(@airmYear,0)
	 
   if(exists(select 1 from Common_WarningWindowService where [currentyear]=@airmYear))
    begin
		declare mycursor cursor for
		select  WarningSettingModelID  from Common_WarningSettingModel where isnull([Copy_Year],[year])=@year and (Status<>4 and PeriodDefined in(1,2,3,30,6))
		open mycursor
		declare @WarningSettingModelID varchar(36) 
		fetch next from mycursor into @WarningSettingModelID 
		while @@fetch_status=0
		begin
			if(not exists(select * from Common_WarningWindowServiceYearCopyLog where CurrentYear=@airmYear and sourceModelID=@WarningSettingModelID and isok=1 ))
			begin
				declare @warningname nvarchar(200),@yearsource int,@copy_year int,@copy_yearsource int
				declare @periodDefinedValue varchar(1000)
				select @warningname=warningname,@copy_year=isnull(Copy_year,[year])-[Year]+@airmYear,@copy_yearsource=isnull(Copy_year,[year]),@yearsource=[year] from Common_WarningSettingModel where WarningSettingModelID=@WarningSettingModelID
				set @warningname=replace(@warningname,Convert(varchar(30),@yearsource)+'-1-1至',Convert(varchar(30),@airmYear)+'-1-1至')
				set @warningname=replace(@warningname,'至'+Convert(varchar(30),@copy_yearsource)+'-12-31','至'+Convert(varchar(30),@copy_year)+'-12-31')
				set @warningname=replace(@warningname,Convert(varchar(30),@yearsource)+'年至',Convert(varchar(30),@airmYear)+'年至')
				set @warningname=replace(@warningname,'至'+Convert(varchar(30),@copy_yearsource)+'年','至'+Convert(varchar(30),@copy_year)+'年')
				
				set @periodDefinedValue=Convert(varchar(30),@airmYear)+'-1-1,'+Convert(varchar(30),@copy_year)+'-12-31'
				declare @airmModelID varchar(36) 
				set @airmModelID=newid()
				insert Common_WarningSettingModel(WarningSettingModelID,
				WarningType,WarningName,Copy_year,[Year],ModuleCode,OrgID,PeriodDefined,
				ChildOrgID,ChildOrgNames,jsManIDs,jsManNames,PeriodDefinedValue,Type_NumInPeriod,
				NumInPeriod,Title,[Content],Period,Setting,SettingDescription,
				WarningModel,Receiver,Status,isAutoInvaild,
				CreateMan,CreateDate,WarningStyle)
				select @airmModelID,WarningType,@warningname,@copy_year,@airmYear,ModuleCode,OrgID,PeriodDefined,
				ChildOrgID,ChildOrgNames,jsManIDs,jsManNames,case when PeriodDefined in(1,6) then @periodDefinedValue else PeriodDefinedValue end ,Type_NumInPeriod,
				NumInPeriod,Title,[Content],Period,Setting,SettingDescription,
				WarningModel,Receiver,1,isAutoInvaild,
				CreateMan,getdate(),WarningStyle from Common_WarningSettingModel where  WarningSettingModelID=@WarningSettingModelID	
				--update 	 Common_WarningSettingModel set Copy_year=-1 where  WarningSettingModelID=@WarningSettingModelID
				insert Common_WarningWindowServiceYearCopyLog(CurrentYear,isok,sourceModelID,airmModelID)
					select @airmYear,1,@WarningSettingModelID,@airmModelID
			end
			fetch next from mycursor into @WarningSettingModelID 
		end
		close mycursor
		deallocate mycursor
		if((select count(1) from Common_WarningSettingModel where [Copy_Year]=@year and Status<>4 and PeriodDefined in(1,2,3))<=(select count(1) from Common_WarningWindowServiceYearCopyLog where CurrentYear=@airmyear and isok=1))
		begin
			update Common_WarningWindowService set isOK=1 where [currentyear]=@airmYear	
			delete Common_WarningWindowServiceYearCopyLog where CurrentYear=(@year-1)
			delete Common_WarningWindowService where CurrentYear=(@year-1)
		end
	end 
end try
begin catch		
		update Common_WarningWindowService set isOK=0 where [currentyear]=@airmYear	
end catch


GO
