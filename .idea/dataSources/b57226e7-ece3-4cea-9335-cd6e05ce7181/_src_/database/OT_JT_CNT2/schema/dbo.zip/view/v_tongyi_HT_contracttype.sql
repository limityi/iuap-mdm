create view [dbo].[v_tongyi_HT_contracttype] as 
select * from OT_JT_CNT2.DBO.HT_contracttype
GO
