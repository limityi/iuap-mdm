 create proc [dbo].[getCommon_WarningSettingModel]
@createManID varchar(300),
@ModelCode varchar(300),
@reciver varchar(300),
@status int,
@WarningType int
as
select WarningSettingModelID,b.ModelName,linkFileName,
case Period when 1 then '每年指定月份' when 2 then '每月指定时段' when 3 then '限定具体日期' end PeriodName,
SettingDescription,Title,CreateDate,case WarningType when 1 then '业务定义' when 0 then '其它' end WarningTypeName
from
Common_WarningSettingModel a join Common_WarningModelCode b on a.ModuleCode=b.modelcode
where [year]=year(getdate()) and createMan=@createManID and WarningType=@WarningType and a.ModuleCode=@ModelCode and 
Receiver like '%'+@reciver+'%'


 GO
