---部门查看权限
Create view [dbo].[V_CNT_Tree_Department_Per]
AS
SELECT d.Depa_Code ID, d.Depa_Code as OrgCode, d.Depa_Name as OrgName, d.[Status], 2 AS OrgType, dd.Depa_Code  AS ParentID, d.Depa_Serial  AS Serial,  d.Tree_Code as TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      PID = d .id AND Status = 1) THEN 1 ELSE 0 END as HasChild
                             ,d.company_ID as CompId
FROM         OPF_Org_Department d   
left join OPF_Org_Department dd on d.PID=dd.id 
WHERE     d.Status = 1

GO
