CREATE VIEW [dbo].[WF_PositionView]
AS
SELECT     P.ID, 
p.Posi_Code AS PositionCode, 
p.Posi_Name AS PositionName, 
p.Remark,
case when p.Status=1 then '1100102' else '1100101' end as Status,
p.Posi_Serial AS Serial,
'' AdminID,
d.Company_ID as  CompanyID
FROM         dbo.OPF_Org_Dep_Position p
inner join dbo.OPF_Org_Department d on d.ID=p.Department_ID
GO
