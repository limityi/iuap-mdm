
CREATE proc [dbo].[sp_Tree_ContractAllTypebz]  
    @parentId nvarchar(50),
    @OrgID nvarchar(36)

as 
--Id、ParentId、NodeName、NodeType、HasChild、IsChecked、Status、Disabled
select ID, PID, Name,nodeType,isnull((select top 1 1 from V_CNT_Tree_ContractAllTypebz  b  where a.id=b.pid and  (OrgID=@OrgID or OrgID='')),0) as HasChild,
 '' IsChecked,'' Status,'' Disabled,Code, Serial, OrgID from V_CNT_Tree_ContractAllTypebz a
where (OrgID=@OrgID or OrgID='') and PID=@parentId order by Serial asc


GO
