 


CREATE TRIGGER  [dbo].[trigger_Execsp_Org_AllDirectAndSubCompanyIDsOfCompanyidFill]
   ON  [dbo].[OPF_Org_Company]
   AFTER INSERT,DELETE,UPDATE 
AS 
BEGIN 
	SET NOCOUNT ON;
    
    declare @companyid varchar(300),@deletecompanyid varchar(300),@isneed bit
    if(EXISTS (SELECT 1 FROM INSERTED) and EXISTS (SELECT 1 FROM deleted) and EXISTS (SELECT 1 FROM deleted a inner join INSERTED b on a.PID<>b.PID ))--Update(HR_Organization_PID) 
	begin
		select @isneed=1 ,@companyid=ID  from INSERTED --update
		select @isneed=1 ,@deletecompanyid=PID  from deleted --update
	end
	else if(EXISTS (SELECT 1 FROM INSERTED) and not EXISTS (SELECT 1 FROM deleted))
		select  @isneed=1 ,@companyid= ID   from INSERTED --insert
	else if(not EXISTS (SELECT 1 FROM INSERTED) and EXISTS (SELECT 1 FROM deleted))
		select  @isneed=1 ,@companyid= ID   from deleted --delete
	if( @isneed=1)
	begin
		exec sp_Org_AllDirectAndSubCompanyIDsOfCompanyidFill @companyid --更改目前单位相关单位信息
		if( @deletecompanyid is not null)--更改原父的相关子单位信息
			exec sp_Org_AllDirectAndSubCompanyIDsOfCompanyidFill @deletecompanyid
	end
END

GO
