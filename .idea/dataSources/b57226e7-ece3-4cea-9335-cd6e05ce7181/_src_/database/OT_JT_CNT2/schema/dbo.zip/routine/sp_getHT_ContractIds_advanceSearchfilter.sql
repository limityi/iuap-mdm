/*
取得合同的高级条件过滤取得的合同ID
*/
 
CREATE proc  [dbo].[sp_getHT_ContractIds_advanceSearchfilter] 
	@keyvalues varchar(max),@andor varchar(30)
as  
declare @wherex varchar(max)
select @wherex=(select dbo.fun_getAdvanceSearchfilter(@keyvalues,@andor))
--select @wherex
exec (' select ht.id from HT_Contract HT where '+@wherex)
GO
