create view V_HT_Settlement_History
as 
select * from HT_Settlement where Is_Active=0

GO
