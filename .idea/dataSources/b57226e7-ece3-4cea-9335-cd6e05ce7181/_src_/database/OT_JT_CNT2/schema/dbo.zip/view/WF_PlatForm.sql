CREATE VIEW dbo.WF_PlatForm
AS
SELECT     TOP (100) PERCENT ID, Name
FROM         dbo.OPF_Sys_PlatForm
WHERE     (Status = 1)
ORDER BY Serial
GO
