-- =============================================
-- Author:lvyanghui		
-- Create date:2014-12-18 
-- Description:	插入下载队列表
-- =============================================
CREATE trigger tgr_OPF_Org_Dep_Posi_Empl
on OPF_Org_Dep_Posi_Empl
after insert, update, delete
as
set nocount on
    if ((exists (select 1 from inserted)) and (exists (select 1 from deleted)))--修改
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			inserted.ID,'OPF_Org_Dep_Posi_Empl',1,getdate(),0,0
		  FROM
			inserted;
    end
    else if (exists (select 1 from inserted) and not exists (select 1 from deleted))--插入
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			inserted.ID,'OPF_Org_Dep_Posi_Empl',0,getdate(),0,0
		  FROM
			inserted;
    end
    else if (not exists (select 1 from inserted) and exists (select 1 from deleted))--删除
    begin
          INSERT INTO HT_DownLoad_Queue
		  SELECT
			deleted.ID,'OPF_Org_Dep_Posi_Empl',-1,getdate(),0,0
		  FROM
			deleted;
    end
set nocount off
GO
