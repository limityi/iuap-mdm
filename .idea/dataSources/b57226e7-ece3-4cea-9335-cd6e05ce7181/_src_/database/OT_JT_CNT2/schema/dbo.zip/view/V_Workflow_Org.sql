CREATE VIEW [dbo].[V_Workflow_Org]
AS
/*公司*/ 
SELECT 
cast(Id  as varchar(36)) as Id, 
Comp_Code AS OrgCode, Comp_Name AS OrgName, 1 AS OrgType, 
cast(pid as varchar(36)) AS ParentId,
c.Comp_Serial Serial
FROM         OPF_Org_Company c
WHERE     c.Status = 1
UNION ALL
/*部门*/ 
SELECT 
cast(ID  as varchar(36)), 
Depa_Code, Depa_Name, 2, 
cast(ISNULL(pid, Company_ID)  as varchar(36)),
d.Depa_Serial
FROM         OPF_Org_Department d
WHERE     d .Status = 1
UNION ALL
/*岗位*/ 
SELECT 
cast(ID  as varchar(36)),
 Posi_Code, Posi_Name, 3, 
cast(Department_ID  as varchar(36)),
p.Posi_Serial
FROM      
   OPF_Org_Dep_Position p
WHERE     p.Status = 1
GO
