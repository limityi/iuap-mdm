create view V_HT_Contract_Budget_History
as 
select * from HT_Contract_Budget where Is_Active=0

GO
