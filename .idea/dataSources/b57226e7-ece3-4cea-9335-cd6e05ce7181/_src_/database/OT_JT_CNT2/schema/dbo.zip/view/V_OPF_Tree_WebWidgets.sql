
CREATE VIEW [dbo].[V_OPF_Tree_WebWidgets]
AS
SELECT b.Widget_Id AS ID, 
      CASE WHEN b.Parent_Id IS NULL THEN '00000000-0000-0000-0000-000000000000' ELSE b.Parent_Id END AS ParentId, 
      b.Title AS NodeName, 
      CASE WHEN b.WidgetType = 0 THEN 1 ELSE 0 END AS NodeType, 
      CASE WHEN EXISTS (SELECT * FROM  OPF_Sys_WebWidgets a WHERE a.Parent_Id = b.Widget_Id) THEN 1 
           ELSE 0 END AS HasChild,
      null AS IsChecked,
      null AS Status,
      b.Title AS title 
FROM  OPF_Sys_WebWidgets b
UNION
SELECT '00000000-0000-0000-0000-000000000000', NULL,'所有Web部件', 1, 
	CASE WHEN EXISTS (SELECT * FROM OPF_Sys_WebWidgets a WHERE a.Parent_Id IS NULL) THEN 1 
		 ELSE 0 END,
	null,null,'根级'

GO
