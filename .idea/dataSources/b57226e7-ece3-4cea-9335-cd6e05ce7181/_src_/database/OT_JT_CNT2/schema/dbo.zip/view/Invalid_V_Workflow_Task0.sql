
CREATE VIEW [dbo].[V_Workflow_Task0]
AS
SELECT     TOP (100) PERCENT dbo.WF_WorkItems.Id, dbo.WF_WorkItems.TaskType, dbo.WF_ProcessInstance.Title, dbo.WF_ProcessInstance.DataIdArr AS BuDataId, 
                      dbo.WF_ActTemplate.ID AS ActivityId, dbo.WF_ActivityInstance.Name AS ActivityName, dbo.WF_ActivityInstance.CreatedTime AS ActivityCreatedTime, 
                      CAST(CASE dbo.WF_WorkItems.IsPress WHEN '101301' THEN 1 ELSE 0 END AS bit) AS IsPress, dbo.WF_WorkItems.UrgentLevel, dbo.WF_WorkItems.SenderId, 
                      dbo.WF_WorkItems.SenderName, dbo.WF_WorkItems.ReceiverId, dbo.WF_WorkItems.ReceiverName, dbo.WF_WorkItems.AlarmTime, dbo.WF_WorkItems.OverTime, 
                      dbo.WF_WorkItems.ReceiverDeptId, dbo.WF_WorkItems.ReceiverDeptName, dbo.WF_BuInterface.BillID AS BillCode, dbo.WF_Bill.Name AS BillName, 
                      dbo.WF_WorkItems.Status, dbo.WF_WorkItems.SendTime, CASE WHEN (dbo.WF_ActTemplate.ExecFunction IS NULL OR
                      dbo.WF_ActTemplate.ExecFunction = '') THEN dbo.WF_JobTemplate.Url ELSE dbo.WF_ActTemplate.ExecFunction END AS Url, dbo.WF_WorkItems.CompletedTime, 
                      dbo.WF_ProcessInstance.Status AS ProcessInstanceStatus
FROM         dbo.WF_Bill INNER JOIN
                      dbo.WF_ProcessInstance INNER JOIN
                      dbo.WF_ActivityInstance ON dbo.WF_ProcessInstance.Id = dbo.WF_ActivityInstance.ProcessInstanceId INNER JOIN
                      dbo.WF_WorkItems ON dbo.WF_ActivityInstance.Id = dbo.WF_WorkItems.ActId INNER JOIN
                      dbo.WF_BuInterface ON dbo.WF_ProcessInstance.BuInterfaceId = dbo.WF_BuInterface.ID INNER JOIN
                      dbo.WF_ActTemplate ON dbo.WF_ActivityInstance.ActTemplateId = dbo.WF_ActTemplate.ID ON dbo.WF_Bill.ID = dbo.WF_BuInterface.BillID INNER JOIN
                      dbo.WF_JobTemplate ON dbo.WF_ActTemplate.JobTemplateID = dbo.WF_JobTemplate.ID
WHERE     (dbo.WF_ProcessInstance.Status = '100901') AND (dbo.WF_ActivityInstance.Status = '101101') AND (dbo.WF_WorkItems.Status = '0' OR
                      dbo.WF_WorkItems.Status = '2' OR
                      dbo.WF_WorkItems.Status = '4') OR
                      (dbo.WF_ProcessInstance.Status = '100901') AND (dbo.WF_WorkItems.Status = '0') AND (dbo.WF_WorkItems.TaskType = 3) OR
                      (dbo.WF_WorkItems.Status = '1')
ORDER BY dbo.WF_WorkItems.SendTime DESC

GO
