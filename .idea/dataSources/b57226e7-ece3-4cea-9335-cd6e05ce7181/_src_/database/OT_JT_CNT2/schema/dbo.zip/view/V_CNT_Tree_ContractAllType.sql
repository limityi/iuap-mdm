CREATE view [dbo].[V_CNT_Tree_ContractAllType] as
select * FROM V_CNT_Tree_ContractTypeSelect
union all
select * FROM V_CNT_Tree_ContractBussinessTypeSelect

GO
