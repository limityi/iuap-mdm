CREATE VIEW sysproperties AS 
SELECT A.name As TableName, A.id As TableID,B.Name As ColName,B.colid As ColID, B.xtype As ColType,C.name As PropName,C.Value As PropValue FROM sysobjects As A INNER JOIN syscolumns As B ON A.id = B.id INNER JOIN sys.extended_properties As C ON C.major_id = A.id AND ( minor_id = B.colid)
GO
