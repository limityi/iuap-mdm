CREATE VIEW [dbo].[WF_RoleView]
AS
SELECT     ID, 
Role_Name as RoleName, 
Remark, 
Comp_ID AS CompanyID, 
case when Status=1 then '1100102' else '1100101' end as Status
FROM         dbo.OPF_Rig_Role
GO
