




CREATE VIEW [dbo].[V_OPF_Tactic_SchemaTree]
AS
---策略类型
Select Tactic_Type_Id as TacticId,[Type_Name] as TacticName,NULL as ParentID,'Type' as TacticType
,CASE WHEN EXISTS (SELECT * FROM  OPF_Tactic_Type_Bill WHERE Tactic_Type_Id = t.Tactic_Type_Id) THEN 1 ELSE 0 END AS HasChild
FROM OPF_Tactic_Type t
UNION ALL
---业务单据
SELECT TacticType_Bill_Id,Bill_Name,Tactic_Type_Id,'Bill'
,CASE WHEN EXISTS (SELECT * FROM  OPF_Tactic_Schema WHERE TacticType_Bill_Id = b.TacticType_Bill_Id) THEN 1 ELSE 0 END
FROM  OPF_Tactic_Type_Bill b
UNION ALL
---策略方案
SELECT [Schema_Id],[Schema_Name],TacticType_Bill_Id,'Schema',0
FROM  OPF_Tactic_Schema s
where s.Is_Active=1
GO
