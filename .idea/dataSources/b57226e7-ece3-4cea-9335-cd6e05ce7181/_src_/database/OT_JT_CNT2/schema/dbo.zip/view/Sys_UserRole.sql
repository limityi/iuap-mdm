CREATE VIEW dbo.Sys_UserRole
AS
SELECT     dbo.OPF_Rig_User_Role.ID, dbo.OPF_Rig_User_Role.Role_ID AS RoleID, dbo.OPF_Org_Employee.Emp_ID, dbo.OPF_Org_Employee.Empl_Code AS empID
FROM         dbo.OPF_Rig_User_Role INNER JOIN
                      dbo.OPF_Org_Employee ON dbo.OPF_Rig_User_Role.Emp_ID = dbo.OPF_Org_Employee.Emp_ID

GO
