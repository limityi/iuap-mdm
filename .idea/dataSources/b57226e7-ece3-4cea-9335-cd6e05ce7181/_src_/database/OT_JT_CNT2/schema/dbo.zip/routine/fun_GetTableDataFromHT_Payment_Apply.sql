 
 create function fun_GetTableDataFromHT_Payment_Apply( @IsActive bit = 1)
returns  table  
as  
return (select * from  HT_Payment_Apply where ( @IsActive=0) or (@IsActive=1 and (Is_Active=1 or Is_Active is null)))

 GO
