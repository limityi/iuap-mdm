-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<权限查看－根据RigType类型查看角色或用户所拥有的权限>
-- =============================================
CREATE PROCEDURE [dbo].[P_Opf_RigView](@parentId Varchar(36),@ownerId Varchar(36),@RigType varchar(5))
AS
BEGIN
	if @RigType = 'user'
		begin
			if @parentId = '' 
				begin
					Select d.ID,D.PID,D.Func_Name,D.Func_Serial,D.HasChild,D.HasPermission,D.Status  From  (SELECT p.ID, NULL PID, p.Name Func_Name,'' As Func_Serial,	
						CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @ownerId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @ownerId) B Where A.ID = B.Module_Id) C where  C.System_ID=p.ID  ) THEN 1 ELSE 0 END AS HasChild,
						CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @ownerId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id =@ownerId) B where  B.Module_Id=P.ID ) THEN 1 ELSE 0 END AS HasPermission,p.Serial,'' Status
						FROM OPF_SYS_PlatForm p ) D Where D.HasPermission=1 order by D.Serial
				end
			else
				begin
					Select A.ID,A.PID,A.Func_Name,A.Func_Serial,A.HasChild,A.HasPermission,A.status from 
					(SELECT ID,CASE WHEN PID IS NULL THEN System_ID ELSE PID END AS PID, Func_Name,Func_Serial,
					CASE WHEN EXISTS (SELECT * FROM (Select distinct A.* from OPF_SYS_Functions A ,(Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @ownerId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @ownerId) B Where A.ID = B.Module_Id) C where  C.PID=f.ID ) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM (Select * from OPF_Rig_OPPermission O where o.Owner_Id in (select Role_ID from  OPF_Rig_User_Role where Emp_ID = @ownerId) union all Select * from OPF_Rig_OPPermission O where o.Owner_Id = @ownerId) B where  B.Module_Id=f.ID ) THEN 1 ELSE 0 END AS HasPermission,'' as status
						FROM OPF_SYS_Functions f WHERE Status = '1' ) A Where A.HasPermission =1 and A.PID= @parentId order by A.Func_Serial
				end 
		end
	else if @RigType = 'role'
		begin
			if @parentId = '' 
			begin
				Select D.* From (
				SELECT p.ID, NULL PID, p.Name Func_Name,p.Serial,
					CASE WHEN EXISTS (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID) THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where C.Module_Id=P.ID And  c.Owner_Id = @ownerId ) THEN 1 ELSE 0 END AS HasPermission,'' status
				 FROM OPF_SYS_PlatForm p ) D where D.HasPermission =1 order by d.Serial
			end
		else
			begin
				Select D.*  From (
				Select * From (SELECT ID,CASE WHEN PID IS NULL THEN System_ID ELSE PID END AS PID, Func_Name,Func_Serial,
					CASE WHEN EXISTS ( Select * from (SELECT F.* FROM OPF_Rig_OPPermission C,OPF_SYS_Functions F where C.Module_Id = F.ID and  c.Owner_Id = @ownerId) E where e.PID =F.ID)  THEN 1 ELSE 0 END AS HasChild,
					CASE WHEN EXISTS (SELECT * FROM OPF_Rig_OPPermission C where  C.Module_Id=f.ID And  c.Owner_Id = @ownerId ) THEN 1 ELSE 0 END AS HasPermission,'' as status
					FROM OPF_SYS_Functions f WHERE Status = '1' ) A   Where A.PID= @parentId )D Where D.HasPermission =1 order by d.Func_Serial
			end 
		end
	
END
GO
