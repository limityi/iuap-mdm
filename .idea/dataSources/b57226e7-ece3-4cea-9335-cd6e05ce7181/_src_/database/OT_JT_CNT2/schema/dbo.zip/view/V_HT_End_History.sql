create view V_HT_End_History
as 
select * from HT_End where Is_Active=0

GO
