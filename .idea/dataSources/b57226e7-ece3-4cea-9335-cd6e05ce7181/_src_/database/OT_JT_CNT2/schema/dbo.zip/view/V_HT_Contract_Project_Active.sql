create view V_HT_Contract_Project_Active
as 
select * from HT_Contract_Project where Is_Active=1

GO
