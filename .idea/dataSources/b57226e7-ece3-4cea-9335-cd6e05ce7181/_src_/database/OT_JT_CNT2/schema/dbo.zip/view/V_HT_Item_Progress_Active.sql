create view V_HT_Item_Progress_Active
as 
select * from HT_Item_Progress where Is_Active=1

GO
