CREATE proc fc_test @tablename varchar(10)
as begin
declare @sql varchar(max)
if object_id(@tablename) is  null
return 
else
begin
set @sql='
create trigger tr_test
on ' +@tablename+'
after insert
as begin 
select 1
end'
return @sql
end
end
GO
