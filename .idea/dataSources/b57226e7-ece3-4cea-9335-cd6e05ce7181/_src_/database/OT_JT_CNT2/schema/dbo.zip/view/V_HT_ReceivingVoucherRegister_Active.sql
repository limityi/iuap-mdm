
CREATE view [dbo].[V_HT_ReceivingVoucherRegister_Active]
as 
select * from HT_ReceivingVoucherRegister where Is_Active=1


GO
