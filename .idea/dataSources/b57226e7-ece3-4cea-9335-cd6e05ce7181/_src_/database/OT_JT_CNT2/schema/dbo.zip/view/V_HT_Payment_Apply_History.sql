


CREATE view [dbo].[V_HT_Payment_Apply_History]
as 
select * from HT_Payment_Apply where Is_Active=0


GO
