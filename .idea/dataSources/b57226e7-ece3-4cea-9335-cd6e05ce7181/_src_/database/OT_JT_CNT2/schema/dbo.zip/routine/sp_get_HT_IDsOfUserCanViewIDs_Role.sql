
/*
取得用户可以查看的合同记录ID。包括数据权限、审批权限等等
2014-10
 
*/
CREATE proc [dbo].[sp_get_HT_IDsOfUserCanViewIDs_Role] 
  @EmplyeeCode varchar(100) --员工编号
  ,@roleid int=1 ---1：普通员工，2：部门领导，3：公司领导 4：合同审计员
  ,@OrgCodes varchar(1000)--过滤公司
  ,@SubCompanyType int--0本部,1包括直接下级单位,2包括所有下级单位
as 
declare @EmplyeeID varchar(100) --员工ID
select @EmplyeeID=EmplId from V_OPF_Employee where EmplCode=@EmplyeeCode
--可以查看的组织信息
declare @PowerOrgCode table(OrgCode varchar(36))
if(@SubCompanyType=0)--本部
  insert @PowerOrgCode select * from dbo.Func_GetSplitStringTable2(@OrgCodes)
if(@SubCompanyType=2)--包括直接下级单位
  insert @PowerOrgCode select * from dbo.fun_GetAllDirectSubCompanyIDsOfCompanyid(@OrgCodes)
if(@SubCompanyType=3)--包括所有下级单位
  insert @PowerOrgCode select * from dbo.fun_GetAllSubCompanyIDsOfCompanyid(@OrgCodes)
  
--1取得可以查看所有合同
declare @dtMyHTID table (htid varchar(100))
if(@roleid=1)	--1.1如果当前用户是普通员工
begin
	insert @dtMyHTID(htid)
		select id htid from HT_Contract where  Registration_Person=@EmplyeeCode or Orgid in (select * from @PowerOrgCode)
		union
		select Contract_Id htid from HT_Contract_Belong where Belong_Employee=@EmplyeeCode and [status]=1
		union
		Select distinct [BuDataId] htid  From  V_Workflow_Task_All where [ReceiverId]=@EmplyeeID and [BillCode] like 'CNT_SIGN%' and [IsPress]=1
 
	 
end	 
--else
--if(@roleid=2)	--1.2如果当前用户是部门领导
--begin
--	declare @dtDepartmentEmplyees table(EmplyeeID varchar(100))
--	declare @departmentID varchar(100)
--	select  @departmentID=DepartmentID from Org_Employee where ID=@EmplyeeID
--	insert @dtDepartmentEmplyees select ID from Org_Employee where DepartmentID=@departmentID union select @EmplyeeID
	 
--	insert @dtMyHTID(htid)
--		select id htid from HT_Contract where   @isContract=1 and  BookerDepartment is  null and Booker in(select EmplyeeID from @dtDepartmentEmplyees) 
--		union 
--		select id htid from HT_Contract where   @isContract=1 and  BookerDepartment=@departmentID 
--		union
--		select BelongContract htid from HT_ContractLinkman where  @isContract=1 and ( BelongDepartment=@departmentID or BelongEmployee=@EmplyeeID)
--		union
--		select BelongContract htid from HT_ContractLinkman where  @isContract=1 and  BelongDepartment is null and BelongEmployee in(select EmplyeeID from @dtDepartmentEmplyees)
--		union
--		Select distinct A.DataIDArr htid  From WF_Job A Join WF_BuInterface B On A.BuInterfaceID=B.ID
--			  Where A.ID in  (Select distinct JobID From WF_Activity Where Granter in(select EmplyeeID from @dtDepartmentEmplyees))  and b.BuCode like @flowtype
--		union --增加合同查看授权 added by liuhl 2012-04-28 15:37
--	    select distinct ContractID htid from HT_ContractReadPower where UserID=@EmplyeeID
--end
--else
--if(@roleid=3)	--1.3如果当前用户是公司领导
--begin
--	insert @dtMyHTID(htid)
--		select id htid from HT_Contract where  @isContract=1 and  Booker=@EmplyeeID 
--		union
--		select BelongContract htid from HT_ContractLinkman where  @isContract=1 and  BelongEmployee=@EmplyeeID
--		union
--		Select distinct A.DataIDArr htid  From WF_Job A Join WF_BuInterface B On A.BuInterfaceID=B.ID
--			  Where A.ID in  (Select distinct JobID From WF_Activity Where Granter=@EmplyeeID) and b.BuCode like @flowtype
			  	
--		union
--		select id htid from HT_Contract where @isContract=1 and  BelongCompany in ( select Compid from dbo.fun_GetAllSubCompanyIDsOfUser(@EmplyeeID))  --不包括未生效、未启动的
--		union
--		select id htid from HT_Contract where @isContract=1 and  SubmitCompany in ( select Compid from dbo.fun_GetAllSubCompanyIDsOfUser(@EmplyeeID)) 
--		union --增加合同查看授权 added by liuhl 2012-04-28 15:37
--	    select distinct ContractID htid from HT_ContractReadPower where UserID=@EmplyeeID
		
--end
--else
--if(@roleid=4)	--1.4如果当前用户是审计员
--begin
--	declare @Companyidtable table(compid varCHAR(300))
--	insert @Companyidtable
--		 select SYS_PermBUData.BUDataID
--		 from (
--				select PermBUDataID from Sys_DataPermission 
--				left join Sys_UserRole on Sys_UserRole.ROleID=Sys_DataPermission.RoleID
--				where ((Sys_DataPermission.EmployeeID=@EmplyeeID and Sys_DataPermission.ROleID is null)
--					 or ( Sys_UserRole.EmpID=@EmplyeeID  and Sys_DataPermission.EmployeeID is null))
--			  ) as a 
--			join SYS_PermBUData on a.PermBUDataID=SYS_PermBUData.ID
			
--	insert @dtMyHTID(htid)
--   		select id htid from HT_Contract where  @isContract=1 and  BelongCompany in ( select Compid from @Companyidtable) 
--		union
--		select id htid from HT_Contract where  @isContract=1 and  SubmitCompany in ( select Compid from @Companyidtable) 
--		union --增加合同查看授权 added by liuhl 2012-04-28 15:37
--	    select distinct ContractID htid from HT_ContractReadPower where UserID=@EmplyeeID
--end

select distinct * from @dtMyHTID

GO
