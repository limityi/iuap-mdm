
CREATE VIEW [dbo].[V_Workflow_Employee]
AS
/*-岗位人员,431主要岗位，432兼任岗位*/ SELECT cast(r.ID AS varchar(36)) AS Id, cast(e.Emp_Id AS varchar(36)) AS EmplId, 
                   e.User_Code AS EmplCode, e.[Empl_Name] AS EmplName, r.Serial, cast(d .id AS varchar(36)) AS DeptId, 
                   d .Depa_Name AS DeptName, cast(p.ID AS varchar(36)) AS ParentId, r.Is_Primary, e.Mobile, d .Company_ID AS CompanyId, 
                   e.eMail, d .Depa_Serial AS DepaSerial,e.Status
FROM      OPF_Org_Employee e INNER JOIN
                   OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.Emp_Id INNER JOIN
                   OPF_Org_Dep_Position p ON r.Dep_Position_ID = p.ID INNER JOIN
                   OPF_Org_Department d ON p.Department_ID = d .ID
  UNION ALL
/*-部门人员,421主要部门人员,422兼任部门*/ SELECT cast(r.ID AS varchar(36)), cast(e.Emp_Id AS varchar(36)), e.User_Code, 
                   e.[Empl_Name], r.Serial, cast(d .id AS varchar(36)), d .Depa_Name, cast(d .ID AS varchar(36)), r.Is_Primary, e.Mobile, 
                   d .Company_ID, e.eMail, d .Depa_Serial,e.Status
FROM      OPF_Org_Employee e INNER JOIN
                   OPF_Org_Dep_Posi_Empl r ON r.Employee_ID = e.Emp_Id INNER JOIN
                   OPF_Org_Department d ON r.Dep_ID = d .ID
WHERE   r.Dep_Position_ID IS NULL

GO
