
 
 

CREATE VIEW [dbo].[Org_CompanyDeptSimpleView]
AS
SELECT     org.ID, org.PID, org.Comp_Code BUDataCode, org.Comp_Name BUDataName, org.Comp_Serial orderby, org.Status,org.ID companyID
FROM         OPF_Org_Company org
UNION
SELECT     org.ID, isnull(org.PID, org.Company_ID) pid, org.Depa_Code BUDataCode,comp.Comp_Name+' '+ org.Depa_Name BUDataName, org.Depa_Serial orderby, org.Status,org.Company_ID companyID
FROM         OPF_Org_Department org join OPF_Org_Company comp on org.Company_ID=comp.id


GO
