CREATE view [dbo].[V_HT_Contract_Perm]
as 
select id,  isnull(name,'')+'('+isnull(code,'')+')' as name,code,cnt_code,orgid from ht_contract
GO
