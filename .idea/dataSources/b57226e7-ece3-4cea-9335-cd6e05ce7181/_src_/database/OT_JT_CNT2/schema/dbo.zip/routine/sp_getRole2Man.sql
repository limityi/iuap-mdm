
CREATE proc [dbo].[sp_getRole2Man]
  @AQOrgID varchar(40)--安全组织ID，角色数据权限使用的
  ,@RoleName  varchar(400)--角色名
as 

--角色数据权限  
 --数据权限挂在组织结构下的角色
 select Sys_UserRole.EmpID,e.EmplName  from (select * from Sys_Role where RoleName in (select SingleString from dbo.Func_GetSplitStringTable2(@RoleName)) and Sys_Role.Status='1100102') rolex
  join Sys_UserRole on Sys_UserRole.ROleID=rolex.ID
  join Sys_DataPermission on Sys_DataPermission.RoleID=rolex.ID and Sys_DataPermission.EmployeeID is null
   and Sys_DataPermission.PermBUDataID 
   in ( select ID from SYS_PermBUData where BUDataTypeID in(select id from  SYS_BUDataType where SystemID=(select top 1 id from  SYS_PlatForm where Status='1100102') and Status='1100102' ))
  join SYS_PermBUData on Sys_DataPermission.PermBUDataID=SYS_PermBUData.ID and SYS_PermBUData.BUDataID=@AQOrgID
  join Org_Employee e on Sys_UserRole.EmpID=e.ID
  
  
/****** Object:  StoredProcedure [dbo].[sp_getGreatHazardWarning2Man]    Script Date: 04/03/2012 20:37:10 ******/
SET ANSI_NULLS ON


GO
