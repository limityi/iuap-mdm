create view [dbo].[v_tongyi_HT_Item_progress] as 
select * from OT_JT_CNT2.DBO.HT_Item_progress

GO
