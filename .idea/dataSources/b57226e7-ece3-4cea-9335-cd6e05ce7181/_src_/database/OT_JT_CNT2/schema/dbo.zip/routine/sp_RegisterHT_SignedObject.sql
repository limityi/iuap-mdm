
/*
	在集团的签约方基本信息中，进行签约方基本信息注册保存	
	选程调用
*/ 
CREATE proc  [dbo].[sp_RegisterHT_SignedObject]
 @SignObjectID nvarchar(64),
 @signObjectName nvarchar(256),
 @Type  smallint
as  
    --注册时先生成编号
    declare  @Code nvarchar(64)
	select @Code=[dbo].[fun_getSignedObjectCode](@signObjectID ,@signObjectName,@Type,1 ) 

	--不存时则注册对应签约方
     --[Status]0：初始、1：启用、2作废
    if(not exists(select * from HT_SignedObject where SignObjectID=@SignObjectID))
	    insert [HT_SignedObject](SignObjectID,Name,[Type],[Status],Code)values (@SignObjectID,@signObjectName,@Type,1,@Code)
    --返回编号
    select @Code


GO
