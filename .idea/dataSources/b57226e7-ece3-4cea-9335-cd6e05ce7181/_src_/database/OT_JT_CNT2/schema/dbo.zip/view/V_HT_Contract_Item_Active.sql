create view V_HT_Contract_Item_Active
as 
select * from HT_Contract_Item where Is_Active=1

GO
