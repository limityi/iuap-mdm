/*
更新指定公司所有上级单位的直属单位及其下级单位、指定公司直属单位及其下级单位
在公司表上可以作为触发器
2014.3.5
weiyj
*/
CREATE proc [dbo].[sp_Org_AllDirectAndSubCompanyIDsOfCompanyidFill]
@companyid varchar(300)=null --如果为null,则重新初始化所 (传入WF_CompanyView 的ID）
as
--1.取得指定单位的所有上级单位ID（含自已）
declare @needchangeOrgids table(id varchar(300))
if(@companyid!='' and @companyid is not null)
begin
	--取得指定单位的所有上级单位ID
	insert @needchangeOrgids select * from [dbo].[fun_GetAllParentCompanyID](@companyid,null)
	--含@companyid
	insert @needchangeOrgids select @companyid
end
else
begin
    declare @top1orgcompanyid varchar(300)
	select top 1 @top1orgcompanyid=id from WF_CompanyView where companycode='N000001'
    insert @needchangeOrgids select * from dbo.fun_GetAllSubCompanyIDsOfCompanyid_core(@top1orgcompanyid)
end
--2.更新对应组织的直属单位表及其下级单位
declare @orgid_temp varchar(300)
declare mycursor_orgid cursor for select id from @needchangeOrgids

open mycursor_orgid
fetch next from mycursor_orgid into @orgid_temp
while @@fetch_status=0
begin
    declare @orgid_tempCode varchar(300)
	select top 1 @orgid_tempCode=companycode from WF_CompanyView where id=@orgid_temp

	delete Org_AllDirectSubCompanyIDsOfCompanyid_Cache where pid=@orgid_tempCode
	delete Org_AllSubCompanyIDsOfCompanyid_Cache where pid=@orgid_tempCode
	insert Org_AllDirectSubCompanyIDsOfCompanyid_Cache(DirectSubCompanyID,pid)
	 select *,@orgid_tempCode from dbo.fun_GetAllDirectSubCompanyIDsOfCompanyid_core(@orgid_temp)
	
	insert Org_AllSubCompanyIDsOfCompanyid_Cache(SubCompanyID,pid)
	 select *,@orgid_tempCode from dbo.fun_GetAllSubCompanyIDsOfCompanyid_core(@orgid_temp)
	 
	fetch next from mycursor_orgid into @orgid_temp
	
end
close mycursor_orgid
deallocate mycursor_orgid

select 'ok'

GO
