CREATE VIEW [dbo].[WF_TaskSurrogateView]
AS
SELECT  distinct   Granter AS ReceiverId ---任务接收人
, BillID AS BillCode ---业务单据编码
, Surrogate  ---任务代理人
FROM         dbo.WF_TaskSurrogate
WHERE     (BeginTime <= GETDATE()) AND (EndTime >= GETDATE() ) and Status='101902'
GO
