 
/*
	取得指定组级所有父组织ID，至到指定的父组织ID
	本方法利用了：[fun_GetParentCompanyID]
	韦永军
	2013.12.6	
*/
CREATE function  [dbo].[fun_GetAllParentCompanyID](@orgid varchar(300),@limitTopParnetId varchar(300))
 returns  @companyids table(Compid varchar(300))
as
begin  
	if(@limitTopParnetId is null) set @limitTopParnetId=''
	declare @parentid varchar(300)
	select @parentid=dbo.[fun_GetParentCompanyID](@orgid)	
	while (@parentid is not null)
	begin
		insert @companyids select @parentid
		if(@parentid<>@limitTopParnetId)
			select @parentid=dbo.[fun_GetParentCompanyID](@parentid) 		
		else
		    set @parentid=null
	    
	end 
	return 
end

GO
