 

-- =============================================
 
-- Create date: 2008-04-30
-- Description:	拆分传入的字符串到表中
-- =============================================
CREATE   function   [dbo].[Func_GetSplitStringTable2]
(@MergeString varchar(max))   
  returns @SplitStringTable table(SingleString nvarchar(100))
as
BEGIN  
  declare @DocumentID nvarchar(max)
  declare @ConditionValue nvarchar(max)	
  declare @valuei  int 
  select @ConditionValue=ltrim(rtrim(@MergeString))
  set   @valuei=charindex(',',@ConditionValue)  
  while   @valuei>=1   
  begin   
    set @DocumentID=left(@ConditionValue,@valuei-1)
	set @ConditionValue=substring(@ConditionValue,@valuei+1,len(@ConditionValue)-@valuei)   
	set @valuei=charindex(',',@ConditionValue)  
    insert @SplitStringTable values(@DocumentID)
  end   
  if  @ConditionValue<>''     
  begin  
    set @DocumentID=@ConditionValue 
    insert @SplitStringTable values(@DocumentID)
  end
  return
end


GO
