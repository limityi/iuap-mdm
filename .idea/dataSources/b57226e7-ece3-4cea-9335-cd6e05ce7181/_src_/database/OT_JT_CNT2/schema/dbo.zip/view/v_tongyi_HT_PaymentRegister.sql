create view [dbo].[v_tongyi_HT_PaymentRegister] 
as
select * from  OT_JT_CNT2.DBO.HT_PaymentRegister
where Contract_Id in (select id from v_tongyi_HT_Contract)
GO
