---2014/6/3
---批量设置环节事件的树视图
CREATE VIEW [V_Workflow_Tree_EventBatch]
AS
	--事件
	Select EventID AS Id,EventName AS Name
	,BillCode+''+EventType AS ParentId
	,1 AS nodeType,0 AS HasChild
	FROM WF_Event


GO
