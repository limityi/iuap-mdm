create view V_HT_Payment_Plan_History
as 
select * from HT_Payment_Plan where Is_Active=0

GO
