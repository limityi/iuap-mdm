/*==============================================================
 View: V_OPF_Tree_OrganizeDept                                
==============================================================*/
CREATE VIEW dbo.V_OPF_Tree_Test
AS
SELECT     ID, Comp_Code AS OrgCode, Comp_Short_Name AS OrgName, Status, 1 AS OrgType, PID AS ParentID, Comp_Serial AS Serial, Tree_Code AS TreeCode, 
                      CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id AND Status = 1) THEN 1 ELSE 0 END AS HasChild, 'Ext1阿里巴巴' AS Ext1, 'Ext2 冬冬是个胆小鬼' AS Ext2, 'Ext3ccc' AS Ext3, 
                      'Ext4ddd' AS Ext4
FROM         dbo.OPF_Org_Company AS c
WHERE     (Status = 1)
GO
