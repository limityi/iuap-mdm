 
/*
	在指定角色的条件下，根据提供源、目标菜单，进行交叉权限COPY，方式将已经COPY好的源菜单的权限COPY目标菜单ID上
	黙认不删除原来的目标菜单的权限
	要求源、目标菜单ID均不可以为空,且不能相同
	weiyongjun
*/
create proc [dbo].[Common_CopyDataFunPermission]
  @souceFunID  varchar(300) --源菜单ID
  ,@FunID  varchar(300)--目标菜单ID
  ,@roleid varchar(300) --目标角色ID
  ,@isdelSourceFunIDDataFunPermission bit=0--是否删原来的目标菜单的权限,黙认不删除
as
if(@isdelSourceFunIDDataFunPermission=1)
	delete Sys_DataFunPermission where RoleID=@roleid and DataFunID in (select Sys_DataFun.ID from Sys_DataFun where  FunID=@FunID)
declare my cursor for select dataID from Sys_DataFun where FunID=@souceFunID  
declare @dataID varchar(300)
open my 
fetch next from my into @dataID
while @@fetch_status=0
begin
	declare @DataFunID varchar(300),@SourceDataFunID varchar(300)
	set @DataFunID=null
	select @DataFunID=id from  Sys_DataFun where FunID=@FunID and DataID=@dataID
	if(@DataFunID is null)
	begin
		set @DataFunID=newid()
		insert Sys_DataFun(ID,FunID,DataID) values (@DataFunID,@funid,@dataID)		
	end 
    select @SourceDataFunID=id from Sys_DataFun where FunID=@souceFunID and DataID=@dataID
	if(not exists(select 1 from [Sys_DataFunPermission] where [DataFunID]=@DataFunID and [RoleID]=@roleid ))
	  INSERT INTO [Sys_DataFunPermission] ([ID], [DataFunID], [EmployeeID], [RoleID], [PermMode], [PermType])	
		 select   newid(),@DataFunID,NULL,@roleid,[PermMode], [PermType] from [Sys_DataFunPermission] where [DataFunID]=@SourceDataFunID and [RoleID]=@roleid 

	fetch next from my into @dataID
end

close my
deallocate my


GO
