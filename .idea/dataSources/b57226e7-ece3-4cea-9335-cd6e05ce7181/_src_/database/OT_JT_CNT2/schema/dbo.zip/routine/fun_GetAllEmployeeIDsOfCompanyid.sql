
CREATE function [dbo].[fun_GetAllEmployeeIDsOfCompanyid]( @companyid varchar(300),@isonlylocalcompany bit=0)
returns  @employeeids table(EmployeeID varchar(300))
as
begin  
	begin
		insert @employeeids
			select HR_Employee_ID from HR_Employee where (CompCode in (select * from [dbo].[fun_GetAllSubCompanyIDsOfCompanyid](@companyid)) and   @isonlylocalcompany=0 ) or (@isonlylocalcompany=1 and CompCode=@companyid)
	end
	return 
end


GO
