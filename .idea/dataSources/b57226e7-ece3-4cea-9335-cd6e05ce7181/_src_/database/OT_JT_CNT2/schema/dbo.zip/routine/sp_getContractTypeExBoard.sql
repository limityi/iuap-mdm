--获取合同类型板块是否有扩展属性
CREATE proc [dbo].[sp_getContractTypeExBoard]
 @ContractTypeid uniqueidentifier 
 ,@BussinessTypeid uniqueidentifier 
as  
declare @id uniqueidentifier 
declare @pid uniqueidentifier
declare @orgid nvarchar(36)='xx'
declare @ExBoard nvarchar (100)
declare @ReBoard nvarchar (100)
if(@ContractTypeid is not null)
begin
	set @pid=@ContractTypeid
	while(isnull(@orgid,'')<>'' and @pid is not null)
	begin 
		select top 1 @id=id,@pid=pid,@orgid=orgid,@ExBoard=ExBoard from dbo.HT_ContractType where id=@pid
	end 
end 

set @ReBoard=isnull(@ExBoard,'')
set @ExBoard=''
set @orgid='xx'

if(@BussinessTypeid is not null)
begin
	set @pid=@BussinessTypeid
	while(isnull(@orgid,'')<>'' and @pid is not null)
	begin 
		select top 1 @id=id,@pid=pid,@orgid=orgid,@ExBoard=ExBoard from dbo.HT_ContractBussinessType where id=@pid
	end 
end

set @ReBoard=@ReBoard+','+isnull(@ExBoard,'')
select @ReBoard

GO
