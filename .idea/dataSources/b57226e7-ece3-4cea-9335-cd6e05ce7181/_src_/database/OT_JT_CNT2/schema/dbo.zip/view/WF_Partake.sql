CREATE VIEW dbo.WF_Partake
AS
SELECT     b.DataIDArr AS BuDataId, c.BillID AS BuCode, a.Granter AS EmpID
FROM         dbo.WF_Activity AS a INNER JOIN
                      dbo.WF_Job AS b ON a.JobID = b.ID INNER JOIN
                      dbo.WF_BuInterface AS c ON b.BuInterfaceID = c.ID
GO
