-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION funGetHT_Contract_ContractBudgets 
(@id varchar(36))
RETURNS varchar(8000)
AS
begin
	declare @ret varchar(8000);
	set @ret = '';
	select  @ret = @ret+'，'+rtrim(b.Name)+'('+CONVERT(VARCHAR(15),CAST(CONVERT(DECIMAL(12,2),LTRIM(a.Share_Amount)) AS MONEY),1)+'/'+ CONVERT(VARCHAR(15),CAST(CONVERT(DECIMAL(12,2),LTRIM(b.BudgetMoney)) AS MONEY),1)+')'
	   from dbo.HT_Contract_Budget a inner join  HT_Project b on a.budget_id=b.id where a.Contract_Id=''+@id+''; 
	set @ret = case when len(@ret)>0 then stuff(@ret,1,1,'') else @ret end
	return @ret
end

GO
