
/*
  将搜索条件字符串转换成可以关系表。可以用 dbo.fun_getAdvanceSearchfilter转成条件字符串。
*/
-- ============================================= 
-- Create date: 2010-10
-- Description:	拆分传入的字符串到表中
--使用例子: [dbo].[Func_GetSplitStringTable_searchkeyvalue]('ht.name:like:南粤物流`ht.name:like:实业交通`ht.ClearingMoney:>=:23320000','`',':')
--
-- =============================================
CREATE   function   [dbo].[Func_GetSplitStringTable_searchkeyvalue]
(
	@MergeString varchar(max) 
	,@fristkeysplit varchar(1)
	,@secondkeysplit varchar(1)
)   
 returns @SplitStringTable table(keystr nvarchar(300),relation nvarchar(30),valuestr nvarchar(1000))
as
BEGIN
  declare @keyvaluegroup nvarchar(max),@key nvarchar(100),@relation nvarchar(30),@value nvarchar(600)
  declare @ConditionValue nvarchar(max)	
  declare @valuei  int 
  select @ConditionValue=ltrim(rtrim(@MergeString))
  set   @valuei=charindex(@fristkeysplit,@ConditionValue)  
 while   @ConditionValue<>''
  begin
	set   @valuei=charindex(@fristkeysplit,@ConditionValue)     
    if(@valuei>0)
		set @keyvaluegroup=left(@ConditionValue,@valuei-1)
	else
		set @keyvaluegroup=@ConditionValue
    declare @keyvaluegroup_temp nvarchar(max),@i int    
    set @keyvaluegroup_temp=@keyvaluegroup
    
    set @i=charindex(@secondkeysplit,@keyvaluegroup_temp)
    if(@i>0)
    begin  
		set @key=left(@keyvaluegroup_temp,@i-1)    
		set @keyvaluegroup_temp=substring(@keyvaluegroup_temp,@i+1,len(@keyvaluegroup_temp)-@i)
    end
    set @i=charindex(@secondkeysplit,@keyvaluegroup_temp) 
    if(@i>0)
    begin  
		set @relation=left(@keyvaluegroup_temp,@i-1)
		set @keyvaluegroup_temp=substring(@keyvaluegroup_temp,@i+1,len(@keyvaluegroup_temp)-@i)
    end     
    set @value=@keyvaluegroup_temp
    if(@valuei>0)  
    begin
		set @ConditionValue=substring(@ConditionValue,@valuei+1,len(@ConditionValue)-@valuei)   
		set @valuei=charindex(@fristkeysplit,@ConditionValue)  
	end
	else
	begin
		set @ConditionValue=''
		set @valuei=0
	end
	select @key=ltrim(rtrim(@key)),@relation=ltrim(rtrim(@relation)),@value=ltrim(rtrim(@value))
    insert @SplitStringTable values(@key,@relation,@value)
  end  
  
  return
end


GO
