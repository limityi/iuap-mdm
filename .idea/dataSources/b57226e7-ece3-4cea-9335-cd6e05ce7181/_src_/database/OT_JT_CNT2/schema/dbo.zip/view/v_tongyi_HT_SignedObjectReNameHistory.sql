

create view [dbo].[v_tongyi_HT_SignedObjectReNameHistory] as 
select * from HT_SignedObjectReNameHistory
GO
