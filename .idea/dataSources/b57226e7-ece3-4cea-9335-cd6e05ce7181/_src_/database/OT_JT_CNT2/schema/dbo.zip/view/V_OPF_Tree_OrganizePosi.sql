/*==============================================================*/
/* View: V_OPF_Tree_OrganizePosi                                */
/*==============================================================*/
CREATE view [dbo].[V_OPF_Tree_OrganizePosi] as
/*公司*/ SELECT ID, Comp_Code AS OrgCode, Comp_Short_Name AS OrgName, [Status], 1 AS OrgType, pid AS ParentID, Comp_Serial AS Serial, 
                      Tree_Code AS TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id AND Status = 1) THEN 1 ELSE 0 END AS HasChild
FROM         OPF_Org_Company c
WHERE     Status = 1
UNION ALL
/*部门*/ SELECT ID, Depa_Code, Depa_Name, [Status], 2, ISNULL(pid, Company_ID), Depa_Serial, Tree_Code, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      PID = d .id AND Status = 1) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Dep_Position
                            WHERE      Department_ID = d .id AND Status = 1) THEN 1 ELSE 0 END
FROM         OPF_Org_Department d
WHERE     Status = 1
UNION ALL
/*岗位*/ SELECT ID, Posi_Code, Posi_Name, [Status], 3, Department_ID, Posi_Serial, '', 0
FROM         OPF_Org_Dep_Position p
WHERE     Status = 1
GO
