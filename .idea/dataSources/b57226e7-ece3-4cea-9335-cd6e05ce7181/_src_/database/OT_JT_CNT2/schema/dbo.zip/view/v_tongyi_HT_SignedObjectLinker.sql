

create view [dbo].[v_tongyi_HT_SignedObjectLinker] as 
select * from HT_SignedObjectLinker
GO
