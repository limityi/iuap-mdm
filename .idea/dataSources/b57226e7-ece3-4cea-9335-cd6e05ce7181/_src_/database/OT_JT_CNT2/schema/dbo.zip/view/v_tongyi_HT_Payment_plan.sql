create view [dbo].[v_tongyi_HT_Payment_plan] 
as
select *　from  OT_JT_CNT2.DBO.HT_Payment_plan where contract_id
in (select id from v_tongyi_HT_Contract)
GO
