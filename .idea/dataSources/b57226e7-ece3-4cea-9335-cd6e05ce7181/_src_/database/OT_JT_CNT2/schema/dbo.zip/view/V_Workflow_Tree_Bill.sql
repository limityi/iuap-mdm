
CREATE VIEW [dbo].[V_Workflow_Tree_Bill]
AS
	--子系统
	Select CAST(ID AS VARCHAR(36)) AS Id,Name,NULL AS ParentId,0 AS nodeType, CASE WHEN EXISTS
                          (SELECT * FROM WF_Bill WHERE SYSTEMID = p.id ) THEN 1 ELSE 0 END AS HasChild
                           ,Serial
	FROM OPF_Sys_PlatForm p
	WHERE Status=1 and IsBusiness=1
	--业务单据
	UNION ALL
	SELECT ID,NAME+'('+Id+')',SYSTEMID,1,0,sortserial 
	FROM WF_Bill b

GO
