create view [dbo].[v_tongyi_HT_Contract_Signatories] as 
select  * from  OT_JT_CNT2.DBO.HT_Contract_Signatories
GO
