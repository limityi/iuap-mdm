
CREATE VIEW [dbo].[V_CNT_Tree_ContractBussinessTypeSelect]
AS
SELECT 'y0_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('y0_' + cast(PID AS nvarchar(36)), 'y0')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 4 ELSE 2 END AS nodeType, OrgID, 
      '0' board, ID AS RID,status
FROM HT_ContractBussinessType a
WHERE isnull(board, '0') LIKE '%0%'
UNION ALL
SELECT 'y1_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('y1_' + cast(PID AS nvarchar(36)), 'y1')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 4 ELSE 2 END AS nodeType, OrgID, 
      '1' board, ID AS RID,status
FROM HT_ContractBussinessType a
WHERE isnull(board, '0') LIKE '%1%'
UNION ALL
SELECT 'y2_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('y2_' + cast(PID AS nvarchar(36)), 'y2')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 4 ELSE 2 END AS nodeType, OrgID, 
      '2' board, ID AS RID,status
FROM HT_ContractBussinessType a
WHERE isnull(board, '0') LIKE '%2%'
UNION ALL
SELECT 'y3_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('y3_' + cast(PID AS nvarchar(36)), 'y3')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 4 ELSE 2 END AS nodeType, OrgID, 
      '3' board, ID AS RID,status
FROM HT_ContractBussinessType a
WHERE isnull(board, '0') LIKE '%3%'
UNION ALL
SELECT 'y4_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('y4_' + cast(PID AS nvarchar(36)), 'y4')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 4 ELSE 2 END AS nodeType, OrgID, 
      '4' board, ID AS RID,status
FROM HT_ContractBussinessType a
WHERE isnull(board, '0') LIKE '%4%'

GO
