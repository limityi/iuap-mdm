CREATE VIEW dbo.V_OPF_Tactic_Schema_Values
AS
SELECT     NEWID() AS Id, Type_Code, Bill_Code, Priority_Level, Element_Code, Element_Value, Assign_Value
FROM         (SELECT DISTINCT k.Type_Code, k.Bill_Code, s.Priority_Level, j.Element_Code, j.Element_Value, i.Assign_Value
                       FROM          dbo.OPF_Tactic_Schema_Items AS t INNER JOIN
                                              dbo.OPF_Tactic_Schema_Instance AS i ON t.Schema_Id = i.Schema_Id INNER JOIN
                                              dbo.OPF_Tactic_Schema AS s ON i.Schema_Id = s.Schema_Id INNER JOIN
                                              dbo.OPF_Tactic_Instance_Items AS j ON i.Schema_Instance_Id = j.Schema_Instance_Id CROSS JOIN
                                              dbo.OPF_Tactic_Type_Bill AS k
                       WHERE      (s.Priority_Level IN
                                                  (SELECT     MAX(Priority_Level) AS Expr1
                                                    FROM          dbo.OPF_Tactic_Schema AS _t1
                                                    WHERE      (Schema_Id = s.Schema_Id) AND (Is_Active = 1) AND EXISTS
                                                                               (SELECT     Schema_Instance_Id, Schema_Id, Assign_Value
                                                                                 FROM          dbo.OPF_Tactic_Schema_Instance AS _t2
                                                                                 WHERE      (_t1.Schema_Id = Schema_Id))))) AS derivedtbl_1
GO
