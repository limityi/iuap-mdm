CREATE VIEW [dbo].[WF_OpinionsView]
AS
SELECT DISTINCT 
                      TOP (100) PERCENT BillCode, ActCode, EmpID, DispSignatory, surrogate, SurrogateName, JobTemplateOID, DataIDArr, ActTemplateID, ActTempSerial, TransactSerial, 
                      Name, CreatedTime, TranTime, Result, Opinion
FROM         (SELECT     b.BillID AS BillCode, m.Code AS ActCode, a.Granter AS EmpID, ee.EmployeeName AS DispSignatory, t.EmpID AS surrogate, 
                                              t.DispSignatory AS SurrogateName, j.JobTemplateOID, j.DataIDArr, a.ActTemplateID, m.ActTempSerial, a.TransactSerial, t.Name, t.CreatedTime, t.TranTime, 
                                              t.Result, CAST(t.Opinion AS varchar(2000)) AS Opinion, p.DepartmentName AS DprName
                       FROM          dbo.WF_ActTransact AS t INNER JOIN
                                              dbo.WF_Activity AS a ON t.ActID = a.ID INNER JOIN
                                              dbo.WF_Job AS j ON a.JobID = j.ID INNER JOIN
                                              dbo.WF_ActTemplate AS m ON m.ID = a.ActTemplateID INNER JOIN
                                              dbo.WF_BuInterface AS b ON b.ID = j.BuInterfaceID LEFT OUTER JOIN
                                              dbo.WF_EmployeeView AS ee ON ee.ID = a.Granter LEFT OUTER JOIN
                                              dbo.WF_DepartmentView AS p ON p.ID = ee.DepartmentID
                       UNION ALL
                       SELECT     b.BillID AS BillCode, m.Code, a.Granter AS EmpID, ee.EmployeeName AS DispSignatory, t.DistributorID AS surrogate, e.EmployeeName AS SurrogateName, 
                                             j.JobTemplateOID, j.DataIDArr, a.ActTemplateID, m.ActTempSerial, a.TransactSerial, a.Name, NULL AS Expr1, t.DistributionDateTime AS TranTime, NULL 
                                             AS Expr2, t.DistributionReason AS Opinion, p.DepartmentName
                       FROM         dbo.WF_Distribution AS t INNER JOIN
                                             dbo.WF_Activity AS a ON t.ActID = a.ID INNER JOIN
                                             dbo.WF_Job AS j ON a.JobID = j.ID INNER JOIN
                                             dbo.WF_ActTemplate AS m ON m.ID = a.ActTemplateID INNER JOIN
                                             dbo.WF_BuInterface AS b ON b.ID = j.BuInterfaceID LEFT OUTER JOIN
                                             dbo.WF_EmployeeView AS e ON e.ID = t.DistributorID LEFT OUTER JOIN
                                             dbo.WF_DepartmentView AS p ON p.ID = e.DepartmentID LEFT OUTER JOIN
                                             dbo.WF_EmployeeView AS ee ON ee.ID = a.Granter
                       UNION ALL
                       SELECT     b.BillID AS BillCode, m.Code, a.Granter AS EmpID, e.DepartmentName AS DispSignatory, t.ReceiverID AS surrogate, e.EmployeeName AS SurrogateName, 
                                             j.JobTemplateOID, j.DataIDArr, a.ActTemplateID, m.ActTempSerial, a.TransactSerial, a.Name, NULL AS Expr1, t.ProcessDateTime AS TranTime, NULL 
                                             AS Expr2, t.ProcessContent AS Opinion, p.DepartmentName
                       FROM         dbo.WF_Distribution AS t INNER JOIN
                                             dbo.WF_Activity AS a ON t.ActID = a.ID INNER JOIN
                                             dbo.WF_Job AS j ON a.JobID = j.ID INNER JOIN
                                             dbo.WF_ActTemplate AS m ON m.ID = a.ActTemplateID INNER JOIN
                                             dbo.WF_BuInterface AS b ON b.ID = j.BuInterfaceID LEFT OUTER JOIN
                                             dbo.WF_EmployeeView AS e ON e.ID = t.ReceiverID LEFT OUTER JOIN
                                             dbo.WF_DepartmentView AS p ON p.ID = e.DepartmentID LEFT OUTER JOIN
                                             dbo.WF_EmployeeView AS ee ON ee.ID = a.Granter) AS t_1
WHERE     (TranTime IS NOT NULL)
ORDER BY ActTempSerial, TranTime
GO
