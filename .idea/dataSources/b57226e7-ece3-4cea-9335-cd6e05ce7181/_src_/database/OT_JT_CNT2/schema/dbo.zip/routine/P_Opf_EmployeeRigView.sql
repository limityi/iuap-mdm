


----2013.10.8
----创建存储过程:用户的角色及权限查看，将每个角色下的权限都显示处理
CREATE PROCEDURE [dbo].[P_Opf_EmployeeRigView](@ownerId Varchar(36))
AS
BEGIN
---人员的功能权限
with functions as
(
	
	select f.ID,f.Func_Name,f.PID,f.System_ID,f.Func_Serial
	from OPF_SYS_Functions f
		inner join OPF_Rig_OPPermission o on f.ID=o.Module_Id 
	where o.Owner_Type=0 and f.status=1
		and o.Owner_Id=@ownerId
	UNION ALL
	select l.ID,l.Func_Name,l.PID,l.System_ID,l.Func_Serial
	from OPF_SYS_Functions l
	inner hash join functions c on l.ID=c.PID
	where l.status=1
)
--select * from functions
SELECT id,parentId,name
FROM (
---角色都增加前缀角色Id
---角色
Select CAST(r.ID AS VARCHAR(36)) as id
	,NULL AS parentId
	,r.Role_Name as name
	,0 as Serial
from OPF_Rig_User_Role ur
inner join OPF_Rig_Role r on r.ID=ur.Role_ID
where r.status =1 and ur.Emp_ID=@ownerId
UNION 
---角色下下子系统
select CAST(o.Owner_Id AS VARCHAR(36))+CAST(p.ID AS VARCHAR(36))
	,CAST(o.Owner_Id AS VARCHAR(36))
	,p.Name
	,p.Serial
from OPF_Rig_OPPermission o
inner join OPF_SYS_PlatForm p on p.ID=o.Module_Id
inner join OPF_Rig_User_Role ur on o.Owner_Id=ur.Role_ID
where p.Status=1 and ur.Emp_ID=@ownerId and o.Owner_Type=1--角色
UNION 
---子系统下功能菜单
select CAST(o.Owner_Id AS VARCHAR(36))+CAST(f.ID AS VARCHAR(36))
	,CAST(o.Owner_Id AS VARCHAR(36))+CAST(ISNULL(f.PID,f.System_ID) AS VARCHAR(36))
	,f.Func_Name
	,f.Func_Serial
from OPF_SYS_Functions f
inner join OPF_Rig_OPPermission o on f.ID=o.Module_Id 
inner join OPF_Rig_User_Role ur on o.Owner_Id=ur.Role_ID
where f.status=1 and ur.Emp_ID=@ownerId and o.Owner_Type=1--角色
UNION ALL
---用户的功能
----个人权限根节点
select 'employeeIds',NULL,'个人权限',299
---子系统
UNION 
select CAST(p.ID AS VARCHAR(36)),'employeeIds',p.Name,p.Serial
from OPF_SYS_PlatForm p
WHERE p.Status=1 and EXISTS(SELECT ID FROM functions WHERE System_ID=p.ID)
---功能权限
UNION 
select CAST(f.ID AS VARCHAR(36))
	,CAST(ISNULL(f.PID,f.System_ID) AS VARCHAR(36))
	,f.Func_Name
	,f.Func_Serial
from functions f
) A
ORDER BY A.parentId,A.Serial
END

GO
