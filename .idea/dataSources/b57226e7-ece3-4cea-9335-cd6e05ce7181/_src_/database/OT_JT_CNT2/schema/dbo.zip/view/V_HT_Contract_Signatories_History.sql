create view V_HT_Contract_Signatories_History
as 
select * from HT_Contract_Signatories where Is_Active=0

GO
