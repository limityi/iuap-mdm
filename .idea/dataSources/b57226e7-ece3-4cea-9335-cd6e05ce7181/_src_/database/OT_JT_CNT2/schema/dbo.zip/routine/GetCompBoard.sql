CREATE function [dbo].[GetCompBoard] 
( 
@CompId uniqueidentifier
) 
returns @TABLE table 
( 
[Value] nvarchar(256) 
) 
as 
begin 
 declare @xx nvarchar (50) 
 select top 1 @xx=a.board from HT_Organization2Board  a inner join OPF_Org_Company b on a.organizationcode=b.Comp_Code
 where b.Id=@CompId
if(@xx='' or @xx is null) set @xx='0'
insert into  @TABLE  
select [Value]   from [dbo].[SplitString](@xx, ',', 1) 
return
end

GO
