CREATE proc [dbo].[sp_SaveHT_ReceivingVoucherRegister]
    @Id uniqueidentifier,
	@Contract_Id uniqueidentifier,
	@Serial int,
	@Gathering_Day datetime,
	@Gathering_Item nvarchar(8),
	 @GatheringAmount decimal(20,6),
	@Gathering_Content nvarchar(1024),
	@Voucher nvarchar(256),
	@Currency nvarchar(8),
	@Exchange_Rate numeric(18, 6),
	@PayTargetName nvarchar(256),
	@Is_Invoice nvarchar(256),
	@Registration_Time datetime,
	@Registration_Person nvarchar(36),
	@Registration_Person_Name nvarchar(256),
	@Remark nvarchar(1024),
	@Is_Active bit
as
IF(not EXISTS(SELECT *	from HT_ReceivingVoucherRegister where Id = @Id )) 
       insert into HT_ReceivingVoucherRegister (Id,Contract_Id,Serial,Gathering_Day,Gathering_Item,Gathering_Content,Voucher,Currency,Exchange_Rate,Is_Invoice,Registration_Time,Registration_Person,Registration_Person_Name,Remark,Is_Active,GatheringAmount,PayTargetName) values(@Id,@Contract_Id,@Serial,@Gathering_Day,@Gathering_Item,@Gathering_Content,@Voucher,@Currency,@Exchange_Rate,@Is_Invoice,@Registration_Time,@Registration_Person,@Registration_Person_Name,@Remark,@Is_Active,@GatheringAmount,@PayTargetName)
else
       update HT_ReceivingVoucherRegister set Contract_Id=@Contract_Id,Serial=@Serial,Gathering_Day=@Gathering_Day,Gathering_Item=@Gathering_Item,Gathering_Content=@Gathering_Content,Voucher=@Voucher,Currency=@Currency,Exchange_Rate=@Exchange_Rate,Is_Invoice=@Is_Invoice,Registration_Time=@Registration_Time,Registration_Person=@Registration_Person,Registration_Person_Name=@Registration_Person_Name,Remark=@Remark,Is_Active=@Is_Active,GatheringAmount=@GatheringAmount,PayTargetName=@PayTargetName where Id=@Id


GO
