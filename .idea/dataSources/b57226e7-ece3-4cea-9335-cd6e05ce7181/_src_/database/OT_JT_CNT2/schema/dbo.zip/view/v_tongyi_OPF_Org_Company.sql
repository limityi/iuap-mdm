create view [dbo].[v_tongyi_OPF_Org_Company] as 
select * from OPF_Org_Company
GO
