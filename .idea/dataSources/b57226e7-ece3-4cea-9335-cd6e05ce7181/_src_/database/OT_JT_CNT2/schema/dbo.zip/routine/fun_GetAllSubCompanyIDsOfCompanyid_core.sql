/*
	取得公司的所有子公司ID（含当前所在的公司ID）,
	本方法是核心由fun_GetAllSubCompanyIDsOfCompanyid调用，是由原fun_GetAllSubCompanyIDsOfCompanyid改名而来
	，改名原因是此函数最大量共用，但此此函数效率不高，改用查询后用临时表Org_GetAllSubCompanyIDsOfCompanyid存储
	2014.3.6 weiyj
*/
CREATE function [dbo].[fun_GetAllSubCompanyIDsOfCompanyid_core]( @companyid varchar(max)) --(传入WF_CompanyView 的ID）
returns  @companyids table(CompCode varchar(300))
as
begin  	
    declare @topcompanycode varchar(300)
	select top 1 @topcompanycode=CompanyCode from WF_CompanyView where id=@companyid
	if(@topcompanycode='N000001') 
	begin
		insert @companyids
			select distinct CompanyCode from WF_CompanyView 	where companyName<>'直属公司'
	end
	else
	begin
		declare  @companyids_temp table(orgid varchar(300),companycode varchar(300),companyName  varchar(300))
		insert @companyids_temp
			select ID,CompanyCode,companyName from WF_CompanyView where ID in (select * from dbo.Func_GetSplitStringTable2(@companyid ))
		declare @i int ,@CurrenttabRowCount int,@oldtabRowCount int
		set @i=0
		set @oldtabRowCount=0		
		while  @i<10
		begin
		 	insert @companyids_temp
			select ID,CompanyCode,companyName from WF_CompanyView where ParentID in (select orgid from @companyids_temp)
			 and id not in (select orgid from @companyids_temp)
			select @CurrenttabRowCount= count(*) from @companyids_temp
			if(@oldtabRowCount<>@CurrenttabRowCount)
			begin
			    set @oldtabRowCount=@CurrenttabRowCount
				set @i=1+@i
		    end
		    else
		      set @i=10
		       
		end		
	   insert 	@companyids select distinct CompanyCode from @companyids_temp where companyName<>'直属公司'
	end  
   return 
end

GO
