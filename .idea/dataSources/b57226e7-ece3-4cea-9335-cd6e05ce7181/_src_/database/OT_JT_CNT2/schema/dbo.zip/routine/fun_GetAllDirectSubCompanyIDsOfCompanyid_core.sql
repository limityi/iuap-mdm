 
 /*
	只取公司( 可以是多个ID串)的所有直属子公司ID（含当前所在的公司ID）
	本方法是核心由[fun_GetAllDirectSubCompanyIDsOfCompanyid]调用，是由原[fun_GetAllDirectSubCompanyIDsOfCompanyid]改名而来
	，改名原因是此函数最大量共用，但此此函数效率不高，改用查询后用临时表Org_GetAllSubCompanyIDsOfCompanyid存储
	2014.3.6 weiyj
*/
CREATE function [dbo].[fun_GetAllDirectSubCompanyIDsOfCompanyid_core]( @pcompanyids varchar(max)) ---(传入WF_CompanyView 的ID）
returns  @companyids table(CompCode varchar(300))
as
begin  
	declare @orgid_temp varchar(40)
	declare mycursorxf cursor for select * from dbo.Func_GetSplitStringTable2(@pcompanyids)
	open mycursorxf
	fetch next from mycursorxf into @orgid_temp
	while @@fetch_status=0
	begin  
		if(exists(select 1 from WF_CompanyView where ParentID=@orgid_temp and CompanyName='直属公司'))
		begin
		  insert @companyids
			select CompanyCode from WF_CompanyView where id= @orgid_temp
			union
			select CompanyCode from WF_CompanyView where ParentID=@orgid_temp and CompanyName<>'直属公司'
			union 
			select CompanyCode from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID=@orgid_temp and CompanyName='直属公司' )
		end
		else
		begin
		  insert @companyids
			select CompanyCode from WF_CompanyView where id= @orgid_temp
			union
			select CompanyCode from WF_CompanyView where ParentID=@orgid_temp 
		end		
		fetch next from mycursorxf into @orgid_temp
	end
    return 
end


 GO
