CREATE VIEW [dbo].[WF_DepPositionView]
AS
SELECT 
ID, 
Department_ID as DepartmentID, 
ID as PositionID,
case when Status=1 then '1100102' else '1100101' end as Status,
 Posi_Name as PosiName
FROM OPF_Org_Dep_Position
GO
