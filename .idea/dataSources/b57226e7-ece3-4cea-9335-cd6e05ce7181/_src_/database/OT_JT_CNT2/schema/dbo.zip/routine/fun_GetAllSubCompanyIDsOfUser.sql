/* 
	取得用户的所有子公司ID（含用户所在的公司ID）
	2010-9
*/
CREATE function [dbo].[fun_GetAllSubCompanyIDsOfUser]( @Emplyeeid varchar(300))
returns  @companyids table(Compid varchar(300))
as
begin  
	declare @companyid varchar(300)
	select @companyid=CompID from  Org_Employee where ID=@Emplyeeid
	if(@companyid='N000001') 
	begin
		insert @companyids
			select ID from WF_CompanyView 		
	end
	else
		insert @companyids
			select @companyid
			union
			select ID from WF_CompanyView where ParentID=@companyid  
			union 
			select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID=@companyid )
			union 
			select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID=@companyid ) )
			union 
			select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID=@companyid ) ) )
			union
			select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID in ( select ID from WF_CompanyView where ParentID=@companyid)  ) ) )
	return 
end


GO
