 




/*
	根据提供源、目标角色，进行数据权限COPY，方式将已经COPY好的源角色的权限COPY目标角色上
	黙认不删除原来的目标角色的权限
	要求源、目标角色均不可以为空,且不能相同,
*/
create proc [dbo].[Sys_CopyDataPermission_RolesbetweenCopy] 
	@soruceRoleID varchar(300) --源角色ID
	,@airmRoleID varchar(300)  --目标角色ID
    ,@isDelAirmRoleDataPermission bit=0 --是否删原来的目标角色的权限,黙认不删除
as
if(@soruceRoleID<>'' and @airmRoleID<>'' and @soruceRoleID<>@airmRoleID)
begin
	if(@isDelAirmRoleDataPermission=1)
		Delete Sys_DataPermission where RoleID=@airmRoleID
	 
	declare @BUDataID varchar(300)		
	declare myx cursor for select PermBUDataID from Sys_DataPermission where [RoleID]=@soruceRoleID
	set @BUDataID=''		 
	open myx 
	fetch next from myx into @BUDataID
	while @@fetch_status=0
	begin
		if(not exists(select * from Sys_DataPermission where RoleID=@airmRoleID and PermBUDataID=@BUDataID))
			INSERT INTO Sys_DataPermission ([ID], [PermBUDataID], [RoleID], [EmployeeID], [PermMode], [PermType])	
		 select   newid(),[PermBUDataID],@airmRoleID,NULL,[PermMode], [PermType] from Sys_DataPermission where  [RoleID]=@soruceRoleID  and PermBUDataID=@BUDataID
		fetch next from myx into @BUDataID
	end
	close myx
	deallocate myx 
end


GO
