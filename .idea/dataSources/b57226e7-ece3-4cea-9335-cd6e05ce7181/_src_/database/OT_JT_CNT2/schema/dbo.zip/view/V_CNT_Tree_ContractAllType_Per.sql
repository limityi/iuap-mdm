---合同类型数据权限树 
create view [dbo].[V_CNT_Tree_ContractAllType_Per] as
select * FROM V_CNT_Tree_ContractTypeSelect
union all
select * FROM V_CNT_Tree_ContractBussinessTypeSelect
union all 
select '0',null,'公用板块','',1,1,3,'',0,null
union all 
select 'z0','0','合同种类分类','',1,1,3,'',0,null
union all
select 'y0','0','合同业务分类','',1,1,3,'',0,null
union all 
select '1',null,'建设板块','',1,1,3,'',1,null
union all 
select 'z1','1','合同种类分类','',1,1,3,'',1,null
union all
select 'y1','1','合同业务分类','',1,1,3,'',1,null
union all 
select '2',null,'营运板块','',1,1,3,'',2,null
union all 
select 'z2','2','合同种类分类','',1,1,3,'',2,null
union all
select 'y2','2','合同业务分类','',1,1,3,'',2,null
union all 
select '3',null,'汽运板块','',1,1,3,'',3,null
union all 
select 'z3','3','合同种类分类','',1,1,3,'',3,null
union all
select 'y3','3','合同业务分类','',1,1,3,'',3,null
union all 
select '4',null,'物流板块','',1,1,3,'',4,null
union all 
select 'z4','4','合同种类分类','',1,1,3,'',4,null
union all
select 'y4','4','合同业务分类','',1,1,3,'',4,null

GO
