CREATE VIEW [dbo].[V_Workflow_Tree_Group]
AS
SELECT ID,Name,
'ROOT' as ParentId
,SortSerial as Serial
,2 as nodeType
,0 AS HasChild
FROM WF_TaskGroup b
UNION 
SELECT 'ROOT','任务栏分组',NULL,0,1
,CASE WHEN EXISTS
      (SELECT *
        FROM  WF_TaskGroup) THEN 1 ELSE 0 END


GO
