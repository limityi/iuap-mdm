 




/*
	根据提供源、目标角色，进行功能权限COPY，方式将已经COPY好的源角色的权限COPY目标角色上
	黙认不删除原来的目标角色的权限
	要求源、目标角色均不可以为空,且不能相同
*/
create proc [dbo].[Sys_CopyFunPermission_RolesbetweenCopy] 
	@soruceRoleID varchar(300) --源角色ID
	,@airmRoleID varchar(300)  --目标角色ID
    ,@isDelAirmRoleFunPermission bit=0 --是否删原来的目标角色的权限,黙认不删除
as
if(@soruceRoleID<>'' and @airmRoleID<>'' and @soruceRoleID<>@airmRoleID)
begin
	if(@isDelAirmRoleFunPermission=1)	 
		Delete from  Sys_FunPermission where RoleID=@airmRoleID  
	 
	declare @FunID varchar(300)		
	declare myx cursor for select [FunctionID] from Sys_FunPermission where [RoleID]=@soruceRoleID
	set @FunID=''		 
	open myx 
	fetch next from myx into @FunID
	while @@fetch_status=0
	begin
		if(not exists(select * from Sys_FunPermission where RoleID=@airmRoleID and [FunctionID]=@FunID))
			INSERT INTO Sys_FunPermission ([ID], [FunctionID], [EmployeeID], [RoleID], [PermMode], [PermType])	
		 select   newid(),[FunctionID],NULL,@airmRoleID,[PermMode], [PermType] from Sys_FunPermission where  [RoleID]=@soruceRoleID  and [FunctionID]=@FunID
		fetch next from myx into @FunID
	end
	close myx
	deallocate myx 
end


GO
