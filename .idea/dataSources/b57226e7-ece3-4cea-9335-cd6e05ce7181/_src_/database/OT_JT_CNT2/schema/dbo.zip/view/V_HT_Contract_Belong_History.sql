create view V_HT_Contract_Belong_History
as 
select * from HT_Contract_Belong where Is_Active=0

GO
