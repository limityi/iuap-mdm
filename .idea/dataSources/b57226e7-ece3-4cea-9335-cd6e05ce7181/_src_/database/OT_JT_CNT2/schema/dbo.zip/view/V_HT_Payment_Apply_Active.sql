



CREATE view [dbo].[V_HT_Payment_Apply_Active]
as 
select * from HT_Payment_Apply where Is_Active=1


GO
