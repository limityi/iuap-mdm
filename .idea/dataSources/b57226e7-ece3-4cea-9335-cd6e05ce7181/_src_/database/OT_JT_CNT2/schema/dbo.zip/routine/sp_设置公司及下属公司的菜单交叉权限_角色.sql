 /*
sp_设置公司及下属公司的菜单交叉权限_角色 使用场景：
菜单是支持交叉时，可以为指定公司或公司及其下属公司分别授各自公司的角色权限。
当然可以指定限定需要受权的角色名称(可以是全称或是仅前缀)，若不指定则分别使用指定组织下所有角色，当然要排除@RemoveRoleName中指定的角色
例如：
1 为菜单：合同风险事件库（ID为T201105031441125910000275）授交叉权限，组织(只读)，对集团下各单位授所有角色权限，不指定角色，排除角色'法律案件初审人员,流程审核人员,手机短信接收人员,法律案件再审人员' 时
sp_设置公司及下属公司的菜单交叉权限_角色 'T201105031441125910000275','组织(只读)','广东省交通集团有限公司',1,'','法律案件初审人员,流程审核人员,手机短信接收人员,法律案件再审人员',1

2为菜单：法律顾问库（ID为T201105031441125910000275）授交叉权限，组织，对集团本单位授角色权限，指定角色名前缀'法律事务管理员-%'，排除角色'' 时
sp_设置公司及下属公司的菜单交叉权限_角色 'T201105031441125910000275','组织','广东省交通集团有限公司',0,'法律事务管理员-%','',0

2013.12.6
韦永军
*/

 CREATE proc [dbo].[sp_设置公司及下属公司的菜单交叉权限_角色]
	 @menuid varchar(300)--菜单项ID (ID为空则表示所有支持交叉的菜单)
	,@powerOrgtype varchar(300)--业务组织类型:组织,组织(只读)	
	,@companyname varchar(300)--公司名称	
	,@NeedSetPowerCompany int=1 --设置权限范围，0仅本公司（@companyname），1所有下属公司，2仅直属公司	
	,@onlyRoleName varchar(3000)=''--仅需要受权的角色名称(可以是全称或是仅前缀或后缀，仅前缀或后缀时要分别再名称后或前加%)，若不指定则分别使用指定组织下所有角色，当然要排除@RemoveRoleName中指定的角色
	,@RemoveRoleName varchar(3000)=''--不需要受权的角色名称 
	,@IsParentCompanyRoleApp2SubCompany int =0 --上级公司角色是否应用到下级公司上，1是0否
 as 
  
  declare @pcode varchar(300)
  select @pcode= id from  Org_Company  where  CompName= @companyname or CompShortName=@companyname
 
  --取得要授权的公司范围 
  declare @dtNeedSetpowerCompany table(id varchar(300))
  if(@NeedSetPowerCompany=0)
	insert @dtNeedSetpowerCompany select @pcode
  else 
  if(@NeedSetPowerCompany=1)
	insert @dtNeedSetpowerCompany select * from dbo.fun_GetAllSubCompanyIDsOfCompanyid(@pcode)
  else
   if(@NeedSetPowerCompany=2)
	insert @dtNeedSetpowerCompany select * from dbo.fun_GetAllDirectSubCompanyIDsOfCompanyid(@pcode)
 --开始授权	
   declare mycursor cursor for select * from @dtNeedSetpowerCompany
   declare @code varchar(300) 
   open mycursor
   fetch next from mycursor into @code
   while @@fetch_status=0
   begin 
      declare @SYS_PermBUData_id varchar(40),@CompName varchar(400),@pid varchar(300),@budatatypeid varchar(300)
	  select @CompName= CompName,@pid=pid from  Org_Company  where  ID=@code 	 
	
	  select @budatatypeid=id from dbo.SYS_BUDataType where BuName=@powerOrgtype 
	  if(not exists(select * from SYS_PermBUData where budataid=@code and budatatypeid=@budatatypeid))
	     insert SYS_PermBUData(id,budatatypeid,budataid,budatacode,budataname,selflinkvalue) select newid(),@budatatypeid,@code,@code,@CompName,@pid
	   
	  select @SYS_PermBUData_id=id from SYS_PermBUData where budataid=@code and budatatypeid=@budatatypeid
	 if(not exists(select * from [Sys_DataFun] where FunID=@menuid and [DataID]=@SYS_PermBUData_id))
		 INSERT INTO [Sys_DataFun] ([ID], [FunID], [DataID]) select  newid(),@menuid,@SYS_PermBUData_id
	declare @Sys_DataFunID varchar(300)
	select @Sys_DataFunID=id from [Sys_DataFun] where FunID=@menuid and [DataID]=@SYS_PermBUData_id

     --取得角色表信息
	 declare @tx table(id varchar(300)) 
	 delete @tx
	 insert @tx
	  select   id from sys_role where
	  RoleName=@onlyRoleName
	  or 
	  (
		(
		    (@IsParentCompanyRoleApp2SubCompany=0 and companyid=@code ) 
		 or (@IsParentCompanyRoleApp2SubCompany=1 and (companyid=@code or companyid in (select * from dbo.fun_GetAllParentCompanyID(@code,@pcode))))
		 )
		and (@onlyRoleName='' or (@onlyRoleName<>'' and RoleName like @onlyRoleName+'%'))
		and(@RemoveRoleName ='' or ( @RemoveRoleName<>'' and RoleName not in  (select * from dbo.Func_GetSplitStringTable2(@RemoveRoleName))))
	  )
 
	 INSERT INTO [Sys_DataFunPermission] ([ID], [DataFunID], [RoleID], [PermMode], [PermType])
	 select  newid(),@Sys_DataFunID,id,'1101201','1101701' from @tx where id not in (select [RoleID] from [Sys_DataFunPermission] where   [DataFunID]=@Sys_DataFunID )
	 
	 fetch next from mycursor into @code	
 end 
 close mycursor
 deallocate mycursor
 --结束授权

 GO
