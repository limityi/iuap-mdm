 
/*
   保存支付申请表信息，包括支付明细项
   只要是调用了保存方法@Is_Active应为活动
*/
CREATE proc  [dbo].[sp_SaveHT_PaymentApply]
 @Id uniqueidentifier,
 @Apply_Type int,
 @Contract_Id uniqueidentifier,
 @Project_Id uniqueidentifier,
 @Title varchar(256),
 @Code nvarchar(32),
 @ApplyDate datetime,
 @Payment_Currency nvarchar(8),
 @Payment_Exchange_Rate numeric(18,6),
 @Serial int,
 @Payment_Content nvarchar(1024),
 @Deduct_Amount decimal(20,6),
 @Pay_Amount decimal(20,6),
 @FactAmount decimal(20,6),
 @Payment_Method nvarchar(8),
 @Reason nvarchar(2048),
 @Target_Unit nvarchar(64),
 @Target_Unit_Name nvarchar(256),
 @AccountName nvarchar(64),
 @Bank_Code nvarchar(256),
 @Opening_Account nvarchar(256),
 @Remark nvarchar(2048),
 @CompletedAmount decimal(20,6),
 @Registration_Person varchar(36),
 @Registration_Person_Name nvarchar(256),
 @Registration_Time datetime,
 @Is_Confirmed bit,
 @Is_approval bit,
 @Workflow_Status smallint,
 @Is_Active bit,
 @OrgId varchar(36),
 @payItems xml=null, --支付项信息
 @Progress_Amount decimal(20,6), 
 --2016-11-08新增发票类型、本期发票金额、累计发票金额、印花税字段
 @TypeOfInvoice varchar(8), 
 @CurrentInvoiceValue decimal(20,6),
 @CumulativeInvoiceValue decimal(20,6),
 @StampDuty decimal(20,6)
as

--1保存支付明细项目信息 ， @payItems xml格式为：<PayItems><PayItem Id="" Payment_ID="" Item_Model_Id="" Item_Name="" Amount="" Total_Amount="" Is_Active=""></PayItem></PayItems>
declare @tablepayItems table ([Id] varchar(36),[Payment_ID] varchar(512),[Item_Model_Id] varchar(36),PayType nvarchar(8) ,[Item_Name] nvarchar(256),[Amount] decimal(20,6),[Total_Amount] decimal(20,6),[Is_Active] bit,[Code] nvarchar(256))

if(@payItems is not null)
begin 
	insert  @tablepayItems([Id],[Payment_ID],[Item_Model_Id],PayType,[Item_Name],[Amount],[Total_Amount],[Is_Active],[Code])
		SELECT T.c.value('@Id','varchar(36)'), 
				T.c.value('@Payment_ID','nvarchar(512)'),  
				T.c.value('@Item_Model_Id','varchar(36)'),  
				T.c.value('@PayType','nvarchar(8)'),  
				T.c.value('@Item_Name','nvarchar(256)'),  
				T.c.value('@Amount','decimal(20,6)'),  
				T.c.value('@Total_Amount','decimal(20,6)'), 
				T.c.value('@Is_Active','bit'),
				T.c.value('@Code','nvarchar(256)')  
		FROM @payItems.nodes('/PayItems/PayItem') AS T(c)
end
--2保存支付申请表基础信息
if(exists(select 1 from HT_Payment_Apply where  Id=@Id))
begin
	update HT_Payment_Apply set  
		Apply_Type=@Apply_Type,Contract_Id=@Contract_Id,Project_Id=@Project_Id,Title=@Title,Code=@Code,
		ApplyDate=@ApplyDate,Payment_Currency=@Payment_Currency,Payment_Exchange_Rate=@Payment_Exchange_Rate,
		Serial=@Serial,Payment_Content=@Payment_Content,Deduct_Amount=@Deduct_Amount,Pay_Amount=@Pay_Amount,
		FactAmount=@FactAmount,Payment_Method=@Payment_Method,Reason=@Reason,Target_Unit=@Target_Unit,Target_Unit_Name=@Target_Unit_Name,
		AccountName=@AccountName,Bank_Code=@Bank_Code,Opening_Account=@Opening_Account,Remark=@Remark,CompletedAmount=@CompletedAmount,Registration_Person=@Registration_Person,
		Registration_Person_Name=@Registration_Person_Name,Registration_Time=@Registration_Time,
		Is_approval=@Is_approval,Is_Active=@Is_Active,OrgId=@OrgId,Progress_Amount=@Progress_Amount,
		TypeOfInvoice=@TypeOfInvoice,CurrentInvoiceValue=@CurrentInvoiceValue,CumulativeInvoiceValue=@CumulativeInvoiceValue,StampDuty=@StampDuty
		where  Id=@Id
		--先删除旧的
		delete from HT_Payment_Item where  Payment_ID=@Id
		--插入
		insert  HT_Payment_Item([Id],[Payment_ID],[Item_Model_Id] ,PayType,[Item_Name],[Amount],[Total_Amount],[Is_Active],[Code])
		select [Id],[Payment_ID],[Item_Model_Id] ,PayType,[Item_Name],[Amount],[Total_Amount],[Is_Active],[Code]  from  @tablepayItems 
	--update pitem set  pitem.Item_Name=x.Item_Name,pitem.Amount=x.Amount,pitem.Total_Amount=x.Total_Amount
	--      ,pitem.Item_Model_Id=x.Item_Model_Id,pitem.PayType=x.PayType,pitem.Is_Active=x.Is_Active
	--	from  @tablepayItems x join HT_Payment_Item pitem on x.id=pitem.id and  x.Payment_ID=pitem.Payment_ID 
end
else
begin
	insert HT_Payment_Apply
	   (
		Id,Apply_Type,Contract_Id,Project_Id,Title,Code,ApplyDate,
		Payment_Currency,Payment_Exchange_Rate,Serial,
		Payment_Content,Deduct_Amount,Pay_Amount,FactAmount,Payment_Method,
		Reason,Target_Unit,Target_Unit_Name,AccountName,Bank_Code,Opening_Account,
		Remark,CompletedAmount,Registration_Person,Registration_Person_Name,
		Registration_Time,Is_Confirmed,Is_approval,Workflow_Status,Is_Active,OrgId,Progress_Amount,
		TypeOfInvoice,CurrentInvoiceValue,CumulativeInvoiceValue,StampDuty
		)
	 values 
	 (
		@Id,@Apply_Type,@Contract_Id,@Project_Id,@Title,@Code,@ApplyDate,
		@Payment_Currency,@Payment_Exchange_Rate,@Serial,
		@Payment_Content,@Deduct_Amount,@Pay_Amount,@FactAmount,@Payment_Method,
		@Reason,@Target_Unit,@Target_Unit_Name,@AccountName,@Bank_Code,@Opening_Account,
		@Remark,@CompletedAmount,@Registration_Person,@Registration_Person_Name,
		@Registration_Time,@Is_Confirmed,@Is_approval,@Workflow_Status,@Is_Active,@OrgId,@Progress_Amount,
		@TypeOfInvoice,@CurrentInvoiceValue,@CumulativeInvoiceValue,@StampDuty
	 ) 
	insert  HT_Payment_Item([Id],[Payment_ID],[Item_Model_Id] ,PayType,[Item_Name],[Amount],[Total_Amount],[Is_Active],[Code])
	 select [Id],[Payment_ID],[Item_Model_Id] ,PayType,[Item_Name],[Amount],[Total_Amount],[Is_Active],[Code]  from  @tablepayItems 
end
GO
