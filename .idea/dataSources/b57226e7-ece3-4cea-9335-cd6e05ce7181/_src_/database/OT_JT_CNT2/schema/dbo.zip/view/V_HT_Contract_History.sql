


CREATE view [dbo].[V_HT_Contract_History]
as 
select * from HT_Contract where Is_Active=0


GO
