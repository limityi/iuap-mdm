/*
批量新增角色
weiyj
2013.12.10
*/

CREATE proc sp_批量新增角色
@RoleName varchar(300)
,@pRemark  varchar(300)
,@companyname varchar(300)--公司名称	
,@NeedSetPowerCompany int=1 --设置权限范围，0仅本公司（@companyname），1所有下属公司，2仅直属公司	
,@RoleNameAppendcompanyName int=1--角色名称是否增加公司名 
as
  declare @pcode varchar(300)
  select @pcode= id from  Org_Company  where  CompName= @companyname or CompShortName=@companyname
 
  --取得要授权的公司范围 
  declare @dtNeedSetpowerCompany table(id varchar(300))
  if(@NeedSetPowerCompany=0)
	insert @dtNeedSetpowerCompany select @pcode
  else 
  if(@NeedSetPowerCompany=1)
	insert @dtNeedSetpowerCompany select * from dbo.fun_GetAllSubCompanyIDsOfCompanyid(@pcode)
  else
   if(@NeedSetPowerCompany=2)
	insert @dtNeedSetpowerCompany select * from dbo.fun_GetAllDirectSubCompanyIDsOfCompanyid(@pcode)
 --开始授权	
   declare mycursor cursor for select * from @dtNeedSetpowerCompany
   declare @companycode varchar(300),@CompShortName varchar(300) ,@CompName varchar(300) 
   open mycursor
   fetch next from mycursor into @companycode
   while @@fetch_status=0
   begin 
	    select @CompShortName= CompShortName,@CompName=CompName  from  Org_Company  where  ID=@companycode 	
	    declare @newroleName varchar(500)
	    if(@RoleNameAppendcompanyName=1)
	    begin
			if(@CompShortName='')
			  set @CompShortName=@CompName
			set @newroleName= @RoleName+'-'+@CompShortName	
		end	 
		else
			set @newroleName= @RoleName
		if(not exists(select * from [Sys_Role] where [RoleName]=@newroleName and [CompanyID]=@companycode))
			INSERT INTO [Sys_Role]([ID],[RoleName],[Remark],[CompanyID],[Status] )
			VALUES(newid(),@newroleName,@pRemark,@companycode,'1100102')
 	   fetch next from mycursor into @companycode	
 end 
 close mycursor
 deallocate mycursor
 --结束授权


GO
