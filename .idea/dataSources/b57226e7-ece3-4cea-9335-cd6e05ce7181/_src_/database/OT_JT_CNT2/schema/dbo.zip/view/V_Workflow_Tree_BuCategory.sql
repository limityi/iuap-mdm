

CREATE VIEW [dbo].[V_Workflow_Tree_BuCategory]
AS
SELECT ID,Name,
CASE WHEN ParentId IS NULL THEN 'ROOT' ELSE ParentId END as ParentId,[Level],Code
, CASE WHEN EXISTS
      (SELECT *
        FROM  WF_BuCategory
        WHERE ParentId = b.id)  THEN 1 ELSE 0 END AS HasChild
FROM WF_BuCategory b
UNION 
SELECT 'ROOT','业务单据分类',NULL,0,''
,CASE WHEN EXISTS
      (SELECT *
        FROM  WF_BuCategory
        WHERE ParentId IS NULL) THEN 1 ELSE 0 END


GO
