
---公司查看权限
CREATE view [dbo].[V_CNT_Tree_Company_Per]
AS
SELECT c.Comp_Code ID, c.Comp_Code AS OrgCode, c.Comp_Name AS OrgName, c.[Status], 1 AS OrgType, cc.Comp_Code AS ParentID, c.Comp_Serial AS Serial, 
                      c.Tree_Code AS TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id AND Status = 1)  THEN 1 ELSE 0 END AS HasChild
                            ,c.Comp_Code as CompId
FROM         OPF_Org_Company c left join OPF_Org_Company cc on c.pid=cc.id
WHERE     c.Status = 1


GO
