/*
	签约方扩展信息保存
*/

CREATE proc  [dbo].[sp_SaveHT_SignedObjectExInfo]
 @Id uniqueidentifier,
 @SignObjectID nvarchar(64),
 @Name nvarchar(256),
 @Type  smallint,
 @Code nvarchar(64),
 @Short_Name nvarchar(256),
 @Address nvarchar(256),
 @Business_Range nvarchar(1024),
 @Qualifications nvarchar(1024),
 @Legal nvarchar(512),
 @OrgID nvarchar(36),
 @OrgName nvarchar(256),
 @Note nvarchar(1024),
 @Status smallint
as

if(exists(select * from [HT_SignedObjectExInfo] where id=@Id))
begin 
    if(@Code<>'' and exists(select * from HT_SignedObject where SignObjectID=@SignObjectID and (Code is null or Code='')))
	    update [HT_SignedObject] set Code=@Code where SignObjectID=@SignObjectID
    update HT_SignedObjectExInfo 
	set SignObjectID=@SignObjectID,Code=@Code,Short_Name=@Short_Name,[Address]=@Address,
	   Business_Range=@Business_Range,Qualifications=@Qualifications,
		Legal=@Legal,OrgID=@OrgID,OrgName=@OrgName,Note=@Note,[Status]=@Status
	where Id=@Id

end
else
begin
	set @Status=1 --0：初始、1：启用、-1作废
    if(not exists(select * from HT_SignedObject where SignObjectID=@SignObjectID))
	    insert [HT_SignedObject](SignObjectID,Name,[Type],[Status],Code)values (@SignObjectID,@Name,@Type,@Status,@Code)

	insert HT_SignedObjectExInfo(Id,SignObjectID,Name,Code,Short_Name,[Address],Business_Range,Qualifications,Legal,OrgID,OrgName,Note,[Status])
	values(@Id,@SignObjectID,@Name,@Code,@Short_Name,@Address,@Business_Range,@Qualifications,@Legal,@OrgID,@OrgName,@Note,@Status)
end
GO
