create view V_HT_Changes_Item_Active
as 
select * from HT_Changes_Item where Is_Active=1

GO
