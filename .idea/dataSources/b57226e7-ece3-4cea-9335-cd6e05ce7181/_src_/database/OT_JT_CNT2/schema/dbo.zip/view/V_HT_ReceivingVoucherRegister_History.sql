create view V_HT_ReceivingVoucherRegister_History
as 
select * from HT_ReceivingVoucherRegister where Is_Active=0

GO
