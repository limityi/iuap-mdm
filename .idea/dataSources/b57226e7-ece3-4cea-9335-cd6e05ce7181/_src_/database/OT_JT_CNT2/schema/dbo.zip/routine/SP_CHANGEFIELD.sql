create procedure [dbo].[SP_CHANGEFIELD](@OLDTYPENAME VARCHAR(50), @NEWDTYPE VARCHAR(50))
as
begin

  exec('sp_addtype U_LOCALTYPE, ''' + @newdtype + '''')

  exec SP_rechangfieldtype @OLDTYPENAME, 'U_LOCALTYPE'

  EXEC sp_rebuildallview

  EXEC('sp_droptype ' + @OLDTYPENAME)

  EXEC('sp_addtype ' + @OLDTYPENAME + ', ''' + @newdtype + '''')

  exec SP_rechangfieldtype 'U_LOCALTYPE', @OLDTYPENAME

  EXEC sp_rebuildallview

  EXEC sp_droptype 'U_LOCALTYPE'

end
GO
