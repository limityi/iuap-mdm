
  /*取得流程类型代码*/
			  CREATE function [dbo].[fun_getFlowTypeCode](@DataIDArr varchar(40))
			  returns varchar(100)
			  as
			  begin
					
			     return(Select B.BillID  From WF_Job A Join WF_BuInterface B On A.BuInterfaceID=B.ID
					 Where  A.DataIDArr=@DataIDArr
					 union select B.BillID  From WF_ProcessInstance A Join WF_BuInterface B On A.BuInterfaceID=B.ID
					 Where  A.DataIDArr=@DataIDArr ) 
			  end


  GO
