CREATE VIEW [dbo].[WF_FullTodo]
AS
SELECT DISTINCT TOP (100) PERCENT T.DataIDArr, T.EmpId, E.EmployeeName
FROM         (SELECT DISTINCT j.DataIDArr, a.Granter AS EmpId
                       FROM          dbo.WF_Activity AS a INNER JOIN
                                              dbo.WF_Job AS j ON j.ID = a.JobID
                       WHERE      (a.Status = '101107') AND (j.Status = '100905')
                       UNION ALL
                       SELECT DISTINCT j.DataIDArr, a.Granter AS EmpId
                       FROM         dbo.WF_Activity AS a INNER JOIN
                                             dbo.WF_Job AS j ON j.ID = a.JobID INNER JOIN
                                             dbo.WF_Distribution AS d ON d.ActID = a.ID
                       WHERE     (a.Status = '101102') AND (j.Status = '100905')
                       UNION ALL
                       SELECT DISTINCT j.DataIDArr, a.Surrogate AS EmpId
                       FROM         dbo.WF_Activity AS a INNER JOIN
                                             dbo.WF_Job AS j ON j.ID = a.JobID
                       WHERE     (a.Surrogate IS NOT NULL) AND (a.Status = '101107') AND (j.Status = '100905')
                       UNION ALL
                       SELECT DISTINCT j.DataIDArr, d.ReceiverID AS EmpId
                       FROM         dbo.WF_Distribution AS d INNER JOIN
                                             dbo.WF_Activity AS a ON a.ID = d.ActID INNER JOIN
                                             dbo.WF_Job AS j ON j.ID = a.JobID
                       WHERE     (d.Status = '101302') AND (j.Status = '100905')
                       UNION ALL
                       SELECT DISTINCT j.DataIDArr, d.ReceiverID AS EmpId
                       FROM         dbo.WF_Distribution AS d INNER JOIN
                                             dbo.WF_Activity AS a ON a.ID = d.ActID INNER JOIN
                                             dbo.WF_Job AS j ON j.ID = a.JobID
                       WHERE     (a.Status = '101302') AND (j.Status = '100905')) AS T INNER JOIN
                      dbo.WF_EmployeeView AS E ON T.EmpId = E.ID
ORDER BY T.DataIDArr
GO
