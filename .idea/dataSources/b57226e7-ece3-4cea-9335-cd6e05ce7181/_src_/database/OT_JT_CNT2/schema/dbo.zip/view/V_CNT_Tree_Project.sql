CREATE VIEW dbo.V_CNT_Tree_Project
AS
SELECT     Id, PId, Name AS TreeName, 1 AS nodeType, 0 AS isChecked, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          HT_Project
                            WHERE      PId = A.Id) THEN 1 ELSE 0 END AS hasChild, OrgID, ProjectYear, LevelOrder, IsBudget
FROM         dbo.HT_Project AS A

GO
