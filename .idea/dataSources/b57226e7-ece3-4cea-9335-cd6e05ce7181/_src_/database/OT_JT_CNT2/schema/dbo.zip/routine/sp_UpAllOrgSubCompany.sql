create proc sp_UpAllOrgSubCompany
as
begin
delete Org_AllSubCompanyIDsOfCompanyid_Cache --所有下级
delete Org_AllDirectSubCompanyIDsOfCompanyid_Cache --直接下级
insert into Org_AllDirectSubCompanyIDsOfCompanyid_Cache  select a.Comp_Code,b.Comp_Code from dbo.OPF_Org_Company a inner join OPF_Org_Company b on b.pid=a.ID 	union all	select a.Comp_Code,a.Comp_Code from dbo.OPF_Org_Company a
insert into Org_AllSubCompanyIDsOfCompanyid_Cache select * from Org_AllDirectSubCompanyIDsOfCompanyid_Cache
while (exists(select a.pid,b.DirectSubCompanyID from Org_AllSubCompanyIDsOfCompanyid_Cache a inner join Org_AllDirectSubCompanyIDsOfCompanyid_Cache b on a.SubCompanyID=b.pid where (a.pid+','+b.DirectSubCompanyID )not in( select a.pid+','+a.SubCompanyID from Org_AllSubCompanyIDsOfCompanyid_Cache a)))
begin
insert into Org_AllSubCompanyIDsOfCompanyid_Cache select a.pid,b.DirectSubCompanyID from Org_AllSubCompanyIDsOfCompanyid_Cache a inner join Org_AllDirectSubCompanyIDsOfCompanyid_Cache b on a.SubCompanyID=b.pid where (a.pid+','+b.DirectSubCompanyID )not in( select a.pid+','+a.SubCompanyID from Org_AllSubCompanyIDsOfCompanyid_Cache a)
end
end
GO
