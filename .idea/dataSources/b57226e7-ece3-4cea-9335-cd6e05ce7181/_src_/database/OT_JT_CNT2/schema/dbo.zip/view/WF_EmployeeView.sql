----Empl_Code => User_Code
CREATE VIEW [dbo].[WF_EmployeeView]
AS
SELECT  e.Emp_Id as ID,
 e.User_Code as EmployeeCode, 
 e.[Empl_Name] AS EmployeeName,
d.Company_ID as CompanyID,
d.ID as DepartmentID,
'' Notes,e.[Mobile],r.Serial,

case when e.Status=1 then '1100102' else '1100101' end as Status ,
 e.eMail,e.PassWord,'' as KeyCode
 ,d.Depa_Code as DepartmentCode, 
d.Depa_Name as DepartmentName
FROM         OPF_Org_Employee e left JOIN
                      OPF_Org_Dep_Posi_Empl r 
             ON r.Employee_ID = e.Emp_Id 
             and r.Dep_Position_ID IS NULL
            and r.Is_Primary=1 
                      left JOIN   OPF_Org_Department d ON r.Dep_ID = d .ID

GO
