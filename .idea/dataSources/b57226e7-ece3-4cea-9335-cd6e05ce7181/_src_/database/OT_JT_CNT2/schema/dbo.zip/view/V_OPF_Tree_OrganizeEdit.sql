
/*==============================================================*/
/* View: V_OPF_Tree_OrganizeEdit                                */
/*==============================================================*/
CREATE view [dbo].[V_OPF_Tree_OrganizeEdit] as
/*公司*/ 
SELECT ID
, Comp_Code AS OrgCode
, Comp_Short_Name AS OrgName
, [Status]
, 1 AS OrgType
, pid AS ParentID
--,CASE WHEN pid IS NULL THEN '00000000-0000-0000-0000-000000000000' ELSE pid END AS ParentId
, Comp_Serial AS Serial, 
                      Tree_Code AS TreeCode, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Company
                            WHERE      PID = c.id) OR
                      EXISTS
                          (SELECT     *
                            FROM          OPF_Org_Department
                            WHERE      Company_ID = c.id) THEN 1 ELSE 0 END AS HasChild,
NULL as CompanyId, 
NULL AS CompanyName
FROM         OPF_Org_Company c
UNION ALL
/*部门*/ 
SELECT d.ID, d.Depa_Code, d.Depa_Name, d.[Status], 2
, ISNULL(d.pid, d.Company_ID)
, d.Depa_Serial
, c.Tree_Code+d.Tree_Code
, CASE WHEN EXISTS
  (SELECT     *
    FROM OPF_Org_Department d2
    WHERE      d2.PID = d .id) THEN 1 ELSE 0 END
,c.id
,c.Comp_Name
FROM  OPF_Org_Department d
INNER JOIN OPF_Org_Company c ON c.id=d.Company_ID


GO
