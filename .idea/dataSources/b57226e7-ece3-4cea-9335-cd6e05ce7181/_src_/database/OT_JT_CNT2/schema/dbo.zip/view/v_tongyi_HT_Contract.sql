create view [dbo].[v_tongyi_HT_Contract] as 
select * from OT_JT_CNT2.DBO.HT_CONTRACT 
where subordinate_company in (select CompanyCode from ot_jt_cnt2.dbo.WF_Companyview where companycode='N000128'
or parentid='906F0E6B-F865-4518-985F-A50613B7FBA0')

GO
