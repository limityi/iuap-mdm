CREATE VIEW [dbo].[V_OPF_Tree_FuncRig]
AS
SELECT     ID, CASE WHEN PID IS NULL THEN System_ID ELSE PID END AS PID, Func_Name, Func_Type, Func_Serial, URI, HasChild, Status
FROM         OPF_SYS_Functions f
WHERE     Status = '1'
UNION ALL
SELECT p.ID, NULL PID, p.Name Func_Name, NULL Func_Type, p.Serial Func_Serial, '' URI,
CASE WHEN EXISTS
 (SELECT * FROM OPF_SYS_Functions A where A.System_ID = P.ID)
  THEN 1 ELSE 0 END AS HasChild,Status
FROM OPF_SYS_PlatForm p
GO
