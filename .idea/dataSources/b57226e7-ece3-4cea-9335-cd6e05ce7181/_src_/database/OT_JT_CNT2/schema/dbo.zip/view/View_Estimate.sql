CREATE VIEW dbo.View_Estimate
AS
SELECT     Id, Pid, Name AS TreeName, 1 AS NodeType, 0 AS IsChecked, CASE WHEN EXISTS
                          (SELECT     *
                            FROM          HT_Estimate
                            WHERE      PId = A.Id) THEN 1 ELSE 0 END AS HasChild, OrgID
FROM         dbo.HT_Estimate AS A
GO
