
CREATE VIEW [dbo].[V_Org_Employee]
AS
SELECT dbo.OPF_Org_Employee.Empl_Code AS userid, 
      dbo.OPF_Org_Employee.Empl_Name AS EmplName, 
      dbo.OPF_Org_Department.Depa_Name AS DepaName, 
      dbo.OPF_Org_Department.Depa_Code AS DepaCode, 
      dbo.OPF_Org_Company.Comp_Code AS compid, 
      dbo.OPF_Org_Company.Comp_Short_Name AS compName, 
      dbo.OPF_Org_Dep_Posi_Empl.Dep_ID, dbo.OPF_Org_Employee.Emp_ID, 
      dbo.OPF_Org_Department.Company_ID, 
      dbo.OPF_Org_Company.Comp_Name AS compLongName
FROM dbo.OPF_Org_Company INNER JOIN
      dbo.OPF_Org_Department ON 
      dbo.OPF_Org_Company.ID = dbo.OPF_Org_Department.Company_ID INNER JOIN
      dbo.OPF_Org_Dep_Posi_Empl ON 
      dbo.OPF_Org_Department.ID = dbo.OPF_Org_Dep_Posi_Empl.Dep_ID INNER JOIN
      dbo.OPF_Org_Employee ON 
      dbo.OPF_Org_Dep_Posi_Empl.Employee_ID = dbo.OPF_Org_Employee.Emp_ID

GO
