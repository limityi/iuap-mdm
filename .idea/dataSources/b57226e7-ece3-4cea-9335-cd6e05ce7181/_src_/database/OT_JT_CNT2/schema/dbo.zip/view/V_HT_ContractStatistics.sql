
CREATE VIEW [dbo].[V_HT_ContractStatistics]
AS
SELECT dbo.HT_Contract.Id, dbo.HT_Contract.Board, dbo.HT_Contract.Contract_Amount, 
      dbo.HT_Contract.Contract_Type, dbo.HT_Contract.Receive_Or_Payment, 
      dbo.HT_Contract.Responsible_Department, dbo.HT_Contract.Responsible_Person, 
      dbo.HT_Contract.Signing_Time, dbo.HT_Contract.Status, dbo.HT_Contract.OrgID, 
      dbo.HT_ContractType.LevelCode, dbo.HT_Contract.Settlement_Amount, 
      dbo.HT_Contract.Change_Amount, dbo.HT_Contract.Complete_Amount, 
      dbo.HT_Contract_Project.Project_Id
FROM dbo.HT_Contract INNER JOIN
      dbo.HT_ContractType ON 
      dbo.HT_Contract.Contract_Type = dbo.HT_ContractType.ID LEFT OUTER JOIN
      dbo.HT_Contract_Project ON 
      dbo.HT_Contract.Id = dbo.HT_Contract_Project.Contract_Id
WHERE (dbo.HT_Contract.Status = 1056303) OR
      (dbo.HT_Contract.Status = 1056304) OR
      (dbo.HT_Contract.Status = 1056305)

GO
