 
create PROCEDURE [dbo].[Common_WarnignCopyWarningSettingModel]
@ids varchar(max)
AS
BEGIN
 
	SET NOCOUNT ON;

   insert into dbo.Common_WarningSettingModel(WarningSettingModelID, WarningType, WarningName, Copy_year, [Year], ModuleCode, OrgID, LinkFileID, LinkFileName, PeriodDefined, ChildOrgID, ChildOrgNames, jsManIDs, jsManNames, PeriodDefinedValue, Type_NumInPeriod, NumInPeriod, Title, [Content], Period, Setting, SettingDescription, WarningModel, Receiver, [Status], isAutoInvaild, isComputedAfterModify, CreateMan, CreateDate)
   select NEWID(), WarningType,WarningName+ '_复制' as WarningName, Copy_year, [Year], ModuleCode, OrgID, LinkFileID, LinkFileName, PeriodDefined, ChildOrgID, ChildOrgNames, jsManIDs, jsManNames, PeriodDefinedValue, Type_NumInPeriod, NumInPeriod, Title, [Content], Period, Setting, SettingDescription, WarningModel, Receiver, [Status], isAutoInvaild, isComputedAfterModify, CreateMan, GETDATE() as CreateDate 
   from Common_WarningSettingModel 
   where WarningSettingModelID 
   in (select * from dbo.Func_GetSplitStringTable2(@ids))

END


GO
