create view [dbo].[v_tongyi_HT_SignedObjectBankAccountInfo] as 
select * from HT_SignedObjectBankAccountInfo
GO
