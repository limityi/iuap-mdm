
/*取得指定合同的签约方名称字串*/
CREATE FUNCTION [dbo].[funGetHT_Contract_SignatorieNames](@id varchar(36))
 RETURNS varchar(8000) 
AS 
begin
	declare @ret varchar(8000);
	set @ret = '';
	select  @ret = @ret+'，'+rtrim(Belong_Enterprise_Name) 
	   from (select distinct Belong_Enterprise_Name from  HT_Contract_Signatories where Contract_Id=@id) x; 
	set @ret = case when len(@ret)>0 then stuff(@ret,1,1,'') else @ret end
	return @ret
end

GO
