CREATE VIEW dbo.V_WarningUser
AS
SELECT     dbo.OPF_Rig_User_Role.ID, dbo.OPF_Rig_User_Role.Emp_ID, dbo.OPF_Rig_Role.Comp_Name, dbo.OPF_Rig_Role.Comp_ID, dbo.OPF_Rig_Role.Role_Name, 
                      dbo.OPF_Rig_Role.Status, dbo.OPF_Org_Company.ID AS Expr3, dbo.OPF_Org_Company.Comp_Code, dbo.OPF_Rig_User_Role.Role_ID, 
                      dbo.OPF_Rig_Role.ID AS Expr1, dbo.OPF_Org_Employee.Empl_Code
FROM         dbo.OPF_Org_Employee INNER JOIN
                      dbo.OPF_Rig_User_Role ON dbo.OPF_Org_Employee.Emp_ID = dbo.OPF_Rig_User_Role.Emp_ID INNER JOIN
                      dbo.OPF_Rig_Role INNER JOIN
                      dbo.OPF_Org_Company ON dbo.OPF_Rig_Role.Comp_ID = dbo.OPF_Org_Company.ID ON dbo.OPF_Rig_User_Role.Role_ID = dbo.OPF_Rig_Role.ID
WHERE     (dbo.OPF_Rig_Role.Status = 1)
GO
