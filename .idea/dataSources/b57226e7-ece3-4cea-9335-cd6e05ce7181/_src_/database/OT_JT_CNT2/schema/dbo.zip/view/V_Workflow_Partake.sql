

CREATE VIEW [dbo].[V_Workflow_Partake]
AS
SELECT     a.DataIdArr AS BuDataId, b.BillID AS BuCode, a.CreatorId AS EmpId
         FROM          WF_ProcessInstance AS a INNER JOIN
                                WF_BuInterface AS b ON a.BuInterfaceId = b.ID
UNION
SELECT     BuDataId, BillCode, ReceiverId
FROM    V_Workflow_Task

GO
