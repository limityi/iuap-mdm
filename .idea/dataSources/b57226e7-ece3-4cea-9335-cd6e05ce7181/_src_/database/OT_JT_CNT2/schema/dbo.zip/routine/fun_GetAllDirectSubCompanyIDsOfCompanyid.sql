 
 /*
	只取公司( 可以是多个ID串)的所有直属子公司ID（含当前所在的公司ID）
	本方法是代替fun_GetAllDirectSubCompanyIDsOfCompanyid_core调用
	，fun_GetAllDirectSubCompanyIDsOfCompanyid_core函数效率不高，改用查询后用临时表Org_AllDirectSubCompanyIDsOfCompanyid存储
	2014.3.6 weiyj
*/
CREATE function [dbo].[fun_GetAllDirectSubCompanyIDsOfCompanyid]( @pcompanyCodes varchar(max))
returns  @companyids table(CompCode varchar(300))
as
begin  
	insert @companyids select * from dbo.Func_GetSplitStringTable2(@pcompanyCodes)
	insert @companyids select DirectSubCompanyID from Org_AllDirectSubCompanyIDsOfCompanyid_Cache where pid in (select * from @companyids)
	 return 
end


 GO
