
---历史数据视图
CREATE view [dbo].[V_HT_Changes_History]
as 
select * from HT_Changes where Is_Active=0


GO
