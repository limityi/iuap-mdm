---2014/11/14
---工作流意见列表,增加是否打印配置，任务类型
CREATE VIEW [dbo].[V_Workflow_Comment]
AS 

SELECT p.DataIdArr AS BuDataId, 
--p.Title,
a.ID AS ActTemplateId,
i.Name AS ActivityName, 
f.BillID AS BillCode, 
--b.Name AS BillName, 
w.Status, 
w.TaskType,
r.HandlerName,
r.TranTime as HandleTime,
r.Comment,
i.OperateStatus,
a.IsPrint,
a.IsPrintEmptyComment,
a.IsNoPrintWhenEmptyComment
FROM WF_Bill b INNER JOIN
WF_ProcessInstance p INNER JOIN
WF_ActivityInstance i ON p.Id = i.ProcessInstanceId INNER JOIN
WF_WorkItems w  ON i.Id = w.ActId INNER JOIN
WF_BuInterface f ON p.BuInterfaceId = f.ID INNER JOIN
WF_ActTemplate a ON i.ActTemplateId = a.ID ON b.ID = f.BillID INNER JOIN
WF_ActionRecord r on r.ActId=i.Id and r.TaskId=w.Id

WHERE   w.Status = '1' 
and r.TranTime=(select MAX(TranTime) 
from WF_ActionRecord 
where w.Id=TaskId
group by TaskId)

GO
