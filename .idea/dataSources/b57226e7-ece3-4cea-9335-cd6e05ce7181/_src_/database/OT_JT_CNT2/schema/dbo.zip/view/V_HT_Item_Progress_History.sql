create view V_HT_Item_Progress_History
as 
select * from HT_Item_Progress where Is_Active=0

GO
