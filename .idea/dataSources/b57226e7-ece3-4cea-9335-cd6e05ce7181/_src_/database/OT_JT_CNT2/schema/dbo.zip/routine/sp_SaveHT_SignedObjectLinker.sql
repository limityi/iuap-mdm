/*
	签约方的联系人信息保存
*/

CREATE proc  [dbo].[sp_SaveHT_SignedObjectLinker]
 @Id uniqueidentifier,
 @SignedObjectExInfoID uniqueidentifier,
 @Linker nvarchar(256),
 @Deption nvarchar(128),
 @Postion nvarchar(128),
 @LinkedPhone nvarchar(256),
 @createdDeptId nvarchar(50)
as
if(exists(select * from HT_SignedObjectLinker where Id=@Id ))                    
	update HT_SignedObjectLinker set Linker=@Linker,Deption=@Deption,Postion=@Postion,LinkedPhone=@LinkedPhone
	where Id=@Id
else
    insert HT_SignedObjectLinker(Id,SignedObjectExInfoID,Linker,Deption,Postion,LinkedPhone,createdDeptId)
    values(@Id,@SignedObjectExInfoID,@Linker,@Deption,@Postion,@LinkedPhone,@createdDeptId)
GO
