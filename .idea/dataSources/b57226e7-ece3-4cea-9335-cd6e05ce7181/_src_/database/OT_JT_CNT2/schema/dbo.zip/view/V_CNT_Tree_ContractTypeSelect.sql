
CREATE VIEW [dbo].[V_CNT_Tree_ContractTypeSelect]
AS
SELECT 'z0_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('z0_' + cast(PID AS nvarchar(36)), 'z0')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 3 ELSE 1 END AS nodeType, OrgID, 
      '0' board, ID AS RID,status
FROM HT_ContractType a
WHERE isnull(board, '0') LIKE '%0%'
UNION ALL
SELECT 'z1_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('z1_' + cast(PID AS nvarchar(36)), 'z1')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 3 ELSE 1 END AS nodeType, OrgID, 
      '1' board, ID AS RID,status
FROM HT_ContractType a
WHERE isnull(board, '0') LIKE '%1%'
UNION ALL
SELECT 'z2_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('z2_' + cast(PID AS nvarchar(36)), 'z2')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 3 ELSE 1 END AS nodeType, OrgID, 
      '2' board, ID AS RID,status
FROM HT_ContractType a
WHERE isnull(board, '0') LIKE '%2%'
UNION ALL
SELECT 'z3_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('z3_' + cast(PID AS nvarchar(36)), 'z3')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 3 ELSE 1 END AS nodeType, OrgID, 
      '3' board, ID AS RID,status
FROM HT_ContractType a
WHERE isnull(board, '0') LIKE '%3%'
UNION ALL
SELECT 'z4_' + lower(cast(ID AS nvarchar(36))) ID, 
      lower(isnull('z4_' + cast(PID AS nvarchar(36)), 'z4')) PID, Name, Code, Serial, 
      1 AS HasChild, CASE WHEN orgid = '' THEN 3 ELSE 1 END AS nodeType, OrgID, 
      '4' board, ID AS RID,status
FROM HT_ContractType a
WHERE isnull(board, '0') LIKE '%4%'

GO
