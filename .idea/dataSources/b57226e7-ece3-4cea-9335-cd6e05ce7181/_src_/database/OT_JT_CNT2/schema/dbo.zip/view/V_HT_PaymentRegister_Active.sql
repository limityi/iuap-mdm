CREATE view [dbo].[V_HT_PaymentRegister_Active]
as 
select * from HT_PaymentRegister where Is_Active=1
GO
