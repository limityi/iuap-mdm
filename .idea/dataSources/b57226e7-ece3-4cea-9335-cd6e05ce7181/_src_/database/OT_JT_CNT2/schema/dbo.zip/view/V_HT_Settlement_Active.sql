create view V_HT_Settlement_Active
as 
select * from HT_Settlement where Is_Active=1

GO
