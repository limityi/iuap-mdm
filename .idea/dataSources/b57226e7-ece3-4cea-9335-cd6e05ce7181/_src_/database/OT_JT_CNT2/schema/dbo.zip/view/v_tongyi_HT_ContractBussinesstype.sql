create view [dbo].[v_tongyi_HT_ContractBussinesstype] as 
select * from HT_ContractBussinesstype
GO
