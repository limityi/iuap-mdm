
CREATE VIEW [dbo].[V_Workflow_Task_All]
AS
SELECT  k.[ID], k.[TaskType], k.[Title], k.[BuDataId], k.[ActTemplateId], k.[ActivityName], k.[ActivityCreatedTime], k.[IsPress], 
                   k.[UrgentLevel], k.[AlarmTime], k.[OverTime], k.[BillCode], k.[BillName], k.IsMobile, k.[Status], k.[SendTime], 
                   k.[CompletedTime], k.[ProcessInstanceStatus], k.[SenderId], k.[SenderName], k.[ReceiverId], k.[ReceiverName], 
                   k.[ReceiverDeptId], k.[ReceiverDeptName], k.ActivityId, k.TaskLevel, k.ParentId, k.CompanyId, k.RawBudataId, 
                   k.CreatorId,k.CreateName, k.CreatedTime, k.DeptName
FROM      V_Workflow_Task k
UNION ALL
SELECT  k.[ID], k.[TaskType], k.[Title], k.[BuDataId], k.[ActTemplateId], k.[ActivityName], k.[ActivityCreatedTime], k.[IsPress], 
                   k.[UrgentLevel], k.[AlarmTime], k.[OverTime], k.[BillCode], k.[BillName], k.IsMobile, k.[Status], k.[SendTime], 
                   k.[CompletedTime], k.[ProcessInstanceStatus], k.[SenderId], k.[SenderName], Cast(e.id AS varchar(36)) AS [ReceiverId], 
                   e.EmployeeName + '(' + k.ReceiverName + '委托)' AS [ReceiverName], Cast(e.DepartmentID AS varchar(36)) 
                   AS [ReceiverDeptId], e.DepartmentName AS [ReceiverDeptName], k.ActivityId, k.TaskLevel, k.ParentId, k.CompanyId, 
                   k.RawBudataId,k.CreatorId, k.CreateName, k.CreatedTime, k.DeptName
FROM      V_Workflow_Task k INNER JOIN
                   WF_TaskSurrogateView s ON k.BillCode = s.BillCode AND k.ReceiverId = s.ReceiverId INNER JOIN
                   WF_EmployeeView e ON s.Surrogate = e.ID
WHERE   k.Status IN ('0', '6', '8') /*-待办*/ OR
                   (k.Status = '1' AND EXISTS
                       (SELECT  id
                        FROM       WF_ActionRecord
                        WHERE    TaskId = k.Id AND HandlerId = s.Surrogate))

GO
