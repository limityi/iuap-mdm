CREATE view [dbo].[V_CNT_Tree_ContractTypebz] as

select cast(ID as nvarchar(36)) ID,PID  PID,Name,Code,Serial,
isnull((select top 1 1 from HT_ContractType   where  orgid ='' and pid=a.id),0)  as HasChild,3 nodeType ,OrgID
FROM HT_ContractType a where a.orgid =''

GO
