
CREATE VIEW [dbo].[V_Workflow_RoleEmployee]
AS
SELECT   
CAST( ur.ID as varchar(36)) as Id, 
CAST( r.ID as varchar(36)) as RoleId, 
r.Role_Name AS RoleName, 
CAST( ur.Emp_ID as varchar(36)) AS EmployeeId, 
e.EmplName AS EmployeeName,
CAST( e.DeptId as varchar(36)) as DeptId, 
 e.DeptName,
e.CompanyId,
e.Serial,
e.DepaSerial
FROM  OPF_Rig_Role r 
INNER JOIN OPF_Rig_User_Role ur ON r.ID = ur.Role_ID 
INNER JOIN  V_Workflow_Employee e ON ur.Emp_ID = e.EmplId and e.Is_Primary=1 and e.DeptId=e.ParentId
WHERE     (r.Status = 1)


GO
